const {Builder, By, Key, until} = require('selenium-webdriver')
const {expect} = require('chai');

(async function example() {
  let driver = await new Builder().forBrowser('phantomjs').build();   //try 'internet explorer' will got error NoSuchElementError: Unable to find element with css selector == *[name="q"]
  try {
    await driver.get('http://www.google.com/ncr');
    await driver.findElement(By.name('q')).sendKeys('webdriver', Key.RETURN);
    await driver.wait(until.titleIs('webdriver - Google Search'), 1000);
  } finally {
    await driver.quit();
  }
})()
