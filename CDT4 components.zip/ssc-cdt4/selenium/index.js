const {Builder, By, Key, until} = require('selenium-webdriver')
const {expect} = require('chai');

(async function dataGridTest() {
  let driver = await new Builder().forBrowser('internet explorer').build()
  try {
    await driver.get('http://localhost:8000/playbook/patterns/tables')
    await driver.findElements(By.className('design2DataGrid')).then((webEles)=>{
      const basicTable= webEles[0]
      const treeTable= webEles[1]
      
      //test data
      const titleBar= basicTable.findElement(By.className('tableTitleBar'))
      titleBar.findElement(By.className('tableTitle')).getText().then((v)=>{expect(v).equals("Basic Table")})
      driver.executeScript("document.querySelector('.design2DataGrid').scrollIntoView(false);")
      titleBar.findElement(By.className('DataGridOverflowMenu')).click()
      driver.findElement(By.className('dropdownMenuListBox'))

      //if the data are more than 20,do this loop about data.length/20 times to test the last piece of data
      for(let i=0;i<2;i++){
        basicTable.findElements(By.css('.dataGridFixed>.dataGridRowLevel-0')).then((divs)=>{
          driver.executeScript(`document.querySelector('.design2DataGrid').querySelectorAll('.dataGridFixed>.dataGridRowLevel-0')[${divs.length-1}].scrollIntoView(false);`)
        })
      }
      
      basicTable.findElements(By.css('.dataGridFixed>.dataGridRowLevel-0')).then((divs)=>{
        const lastRowFixed= divs[divs.length-1]
        lastRowFixed.findElement(By.css('.design2-checkbox'))
        lastRowFixed.findElement(By.css('svg')).getAttribute('fill').then((v)=>{expect(v).equals("#b91224")})  // chrome & firefox equals "#B91224"
      })
      basicTable.findElements(By.css('.dataGridColumnContainer:not(.dataGridFixed)>.dataGridRowLevel-0')).then((divs)=>{
        const lastRow= divs[divs.length-1]
        lastRow.getText().then((v)=>expect(v).equals("SAIC\nBuchanan\nFUND0\n757\n479.81\n363,213.62\n2017-10-18\n20171018 10:23:50\n6"))
      })
      

      //test group
      const fixedArraw= treeTable.findElement(By.css('.dataGridRowLevel-0>div'))
      fixedArraw.findElement(By.css('.dataGridCustomCellWrapper>div')).then((div)=>{
        div.getAttribute("class").then((v)=>{expect(v).equals("dataGridAccordionCellExpanded")})
      })
      treeTable.findElements(By.className('dataGridColumnContainer')).then((divs)=>{
        const firstChild= divs[1]
        firstChild.findElement(By.css('.dataGridRowLevel-1>div'))
        .getText().then((v)=>expect(v).equals("Another Child"))
      })

      driver.executeScript("document.querySelectorAll('.design2DataGrid')[1].scrollIntoView(false);")
      fixedArraw.click()

      fixedArraw.findElement(By.css('.dataGridCustomCellWrapper>div')).then((div)=>{
        div.getAttribute("class").then((v)=>{expect(v).equals("dataGridAccordionCell")})
      })
      treeTable.findElements(By.className('dataGridColumnContainer')).then((divs)=>{
        const firstChild= divs[1]
        firstChild.findElement(By.css('.dataGridRowLevel-1>div'))
        .getText().then((v)=>expect(v).equals("Cat two Child"))
      })
      
    
      //test checkBox
      const headerCheckBox= treeTable.findElement(By.css('.dataGridHeaderFixed .design2-checkbox'))
      headerCheckBox.click()
      treeTable.findElements(By.className("design2-checkbox")).then((checkBoxs)=>{
        for(let i= 0; i<checkBoxs.length; i++){
          checkBoxs[i].getAttribute("class").then((v)=>{expect(v).equals("design2-checkbox checked small-checkbox")})
        }
      })
      headerCheckBox.click()
      treeTable.findElements(By.className("design2-checkbox")).then((checkBoxs)=>{
        for(let i= 0; i<checkBoxs.length; i++){
          checkBoxs[i].getAttribute("class").then((v)=>{expect(v).equals("design2-checkbox small-checkbox")})
        }
      })

      headerCheckBox.click()
      treeTable.findElements(By.className("design2-checkbox")).then((checkBoxs)=>{
        checkBoxs[1].click()
        headerCheckBox.getAttribute("class").then((v)=>{expect(v).equals("design2-checkbox small-checkbox")})
        checkBoxs[1].click()
        headerCheckBox.getAttribute("class").then((v)=>{expect(v).equals("design2-checkbox checked small-checkbox")})
      })

      headerCheckBox.click()
      treeTable.findElements(By.css(".dataGridRowLevel-0 .design2-checkbox")).then((checkBoxs)=>{
        for(let i= 0; i<checkBoxs.length; i++){
          driver.executeScript(`document.querySelectorAll('.design2DataGrid')[1].querySelectorAll('.dataGridRowLevel-0 .design2-checkbox')[${i}].scrollIntoView(false);`)
          headerCheckBox.getAttribute("class").then((v)=>{expect(v).equals("design2-checkbox small-checkbox")})
          checkBoxs[i].click()
        }
        headerCheckBox.getAttribute("class").then((v)=>{expect(v).equals("design2-checkbox checked small-checkbox")})
      })
      
      //sort test
      let textArray=[]

      treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeader>.dataGridCell>.dataGridCellHeaderText")).then((divs)=>{
        divs[0].click()
      })
      driver.findElements(By.css(".dropdownMenuListBox>.scroll-box>div")).then((divs)=>{
        divs[0].click()
        treeTable.findElements(By.css(".dataGridColumnContainer")).then((divs)=>{
          divs[1].findElements(By.css(".dataGridRowLevel-0")).then((boxs)=>{
            for(let i=0;i<boxs.length;i++){
              boxs[i].findElements(By.css(".dataGridCellText")).then((texts)=>{
                texts[0].getText().then((v)=>{
                  textArray.push(v)
                  if(i>0){
                    expect(v>textArray[i-1]).to.be.ok
                  }
                })
              })
            }
          })
        })
      })
      treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeader>.dataGridCell>.dataGridCellHeaderText")).then((divs)=>{
        divs[0].click()
      })
      driver.findElements(By.css(".dropdownMenuListBox>.scroll-box>div")).then((divs)=>{
        divs[1].click()
        textArray=[]
        treeTable.findElements(By.css(".dataGridColumnContainer")).then((divs)=>{
          divs[1].findElements(By.css(".dataGridRowLevel-0")).then((boxs)=>{
            for(let i=0;i<boxs.length;i++){
              boxs[i].findElements(By.css(".dataGridCellText")).then((texts)=>{
                texts[0].getText().then((v)=>{
                  textArray.push(v)
                  if(i>0){
                    expect(v<=textArray[i-1]).to.be.ok
                  }
                })
              })
            }
          })
        })
      })

      //test freeze
      treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeaderFixed>.dataGridCell")).then((divs)=>{
        expect(divs).to.have.lengthOf(3)
      })
      treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeader>.dataGridCell>.dataGridCellHeaderText")).then((divs)=>{
        divs[0].click()
      })
      driver.findElements(By.css(".dropdownMenuListBox>.scroll-box>div")).then((divs)=>{
        divs[3].click()
        treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeaderFixed>.dataGridCell")).then((cc)=>{
          expect(cc).to.have.lengthOf(4)
        })
      })
      treeTable.findElements(By.css('.dataGridFixed>.dataGridRowLevel-0>div')).then((divs)=>{
        expect(divs).to.have.lengthOf(12)
        divs[3].getText().then((v)=>expect(v).equals("Top Category"))
      })

      treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeaderFixed>.dataGridCell")).then((divs)=>{
        divs[3].click()
      })
      driver.findElements(By.css(".dropdownMenuListBox>.scroll-box>div")).then((divs)=>{
        divs[3].click()
        treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeaderFixed>.dataGridCell")).then((cc)=>{
          expect(cc).to.have.lengthOf(3)
        })
      })
      treeTable.findElements(By.css('.dataGridFixed>.dataGridRowLevel-0>div')).then((divs)=>{
        expect(divs).to.have.lengthOf(9)
      })

      //test auto-resize
      let width= ""
      treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeader>.dataGridCell")).then((divs)=>{
        divs[0].getCssValue("width").then((v)=>width=v)
      })
      treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeader>.dataGridCell>.dataGridCellHeaderText")).then((divs)=>{
        divs[0].click()
      })
      driver.findElements(By.css(".dropdownMenuListBox>.scroll-box>div")).then((divs)=>{
        divs[4].click()
      })
      treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeader>.dataGridCell")).then((divs)=>{
        divs[0].getCssValue("width").then((v)=>expect(v).to.not.equal(width))
      })
      
      //test columns
      let selectedItem=""
      treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeader>.dataGridCell>.dataGridCellHeaderText")).then((divs)=>{
        divs[0].click()
      })
      driver.findElements(By.css(".dropdownMenuListBox>.scroll-box>div")).then((divs)=>{
        divs[6].click()
        divs[6].findElements(By.css(".MenuItem:not(.selectedItem)")).then((lis)=>{
          lis[0].getText().then((v)=>selectedItem=v)
          lis[0].click()
          treeTable.findElements(By.css(".dataGridHeaderContainer>.dataGridHeader>.dataGridCell>.dataGridCellHeaderText")).then((headers)=>{
            headers[headers.length-1].getText().then((v)=>expect(v).equals(selectedItem))
          })
        })
      })

    })
  } finally {
    await driver.quit()
  }
})()
