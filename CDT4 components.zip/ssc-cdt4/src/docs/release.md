## Release Notes ssc-cdt3/design2 v 1.1.4-beta

### New Components

- [Form](https://design.statestr.com/playbook/patterns/forms)
- [Error](https://design.statestr.com/playbook/patterns/errors)
- [Tag](https://design.statestr.com/playbook/patterns/tags)
- [Alert Banner](https://design.statestr.com/playbook/patterns/alert-banners)
- [Grid Layout](https://design.statestr.com/playbook/learn-the-basics/grid)
- [Overlay](https://design.statestr.com/playbook/patterns/overlays)
- [Tile](https://design.statestr.com/playbook/patterns/tiles)

## Release Notes ssc-cdt3/design2 v 1.1.3-beta

### New Components

- [Button](https://design.statestr.com/playbook/patterns/buttons)
- Tooltip
- [Tab](https://design.statestr.com/playbook/patterns/tabs)
- [Secondary Navigation](https://design.statestr.com/playbook/patterns/secondary-navigation)

## Release Notes ssc-cdt3/design2 v 1.1.2-beta

### New Components

- [Icon](https://design.statestr.com/playbook/learn-the-basics/iconography)
- [Logo](https://design.statestr.com/playbook/learn-the-basics/logo)
- [Global Navigation](https://design.statestr.com/playbook/patterns/global-navigation)
- [Accordion](https://design.statestr.com/playbook/patterns/accordions)
- [Menu](https://design.statestr.com/playbook/patterns/menus)
- [Filter](https://design.statestr.com/playbook/patterns/filters)