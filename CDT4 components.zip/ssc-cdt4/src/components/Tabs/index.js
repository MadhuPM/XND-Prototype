import Tabs from './Tabs'
import Tab from './Tab'

export {Tab}

export default Tabs
