import Accordion from './Accordion'
import Panel from './Panel'

export { Panel}

export default Accordion