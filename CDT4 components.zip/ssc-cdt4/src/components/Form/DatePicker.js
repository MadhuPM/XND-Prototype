import React from 'react'
import {DatePicker} from '../DatePicker'

const Component = (props) =>{
    return (
        <DatePicker controlled {...props} />
    )
}
export default Component