import React from 'react'
import track from 'react-tracking'
import {CDTTrackingEventDispatcher} from './index'


export function CDTTrackApp(trackingInfo, options) {
    return function decorator(...toDecorate) {
        options = options? options: {};
        options.dispatch = options.dispatch? options.dispatch : CDTTrackingEventDispatcher;
        return track(trackingInfo,options)(
            ...toDecorate
        );
    };
}

export function CDTTrackMount(trackingInfo, options) {
    return function decorator(...toDecorate) {
        options = options? options: {};
        options.dispatchOnMount =  true;
        return track(trackingInfo,options)(
            ...toDecorate
        );
    };
}

export function CDTTrack(trackingInfo, options) {
    return function decorator(...toDecorate) {
        return track(trackingInfo,options)(
            ...toDecorate
        );
    };
}



