/*
    TrackingData is used to store tracking data. It is implemented as a queue i.e. Add pushes data to the end. 
*/
class TrackingData{
    constructor() {
        window._cdt_analytics_data = window._cdt_analytics_data || [];
    }
    data(){
        return window._cdt_analytics_data;
    }
    add(record) {
        this.data().unshift(record);
    }
    remove(removeItemCount) {
        removeItemCount = removeItemCount ? removeItemCount:1
        return this.data().splice(0,removeItemCount)
    }
    size(){
        return this.data().length;
    }
}

const trackingData = new TrackingData();
export default trackingData;  