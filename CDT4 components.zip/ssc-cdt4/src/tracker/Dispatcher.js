import {getConfig} from './DefaultAnalyticsSettings'
import throttle from 'lodash.throttle'
import moment from 'moment'
import trackingData from './TrackingData'

class EventDispatcher {

    addMetaData(data){
        const timestamp = moment().format(getConfig().tsFormat);
        let payloadHeader = {
            senderHost: window.location.hostname,
            headerTemplate: getConfig().headerTemplate,
            payloadData: {},
            senderDateTimeStamp: timestamp
        };
        let payload = Object.assign({}, { // add metadata
            appcode: data.appcode || getConfig().appcode,
            subappcode: data.subappcode ||  getConfig().subappcode,
            cdt_library_version: getConfig().version,
            timestamp: data.timestamp || moment().format(getConfig().tsFormat),
            useragent: data.useragent || navigator.userAgent
        }, data);
        return Object.assign({}, payloadHeader, {
            payloadData: payload
        });
    }
    preparePayload() {
        let payloads = ''
        if (trackingData.size() > 0) {
            //process a batch of events 
            const batchOfData = trackingData.remove(getConfig().maxBatchSize)
            const that = this;
            batchOfData.forEach(function (eventdata) {
                payloads = payloads.concat(JSON.stringify(that.addMetaData(eventdata)) + "|");
            });
            payloads = payloads.slice(0, payloads.length-1) // remove the last pipe
            return payloads;
        }
        return;
    }


    dispatch() {
        const payload = this.preparePayload();
        if (payload) {
            this.postData(getConfig().url, payload);                
            if (trackingData.size() > 0) {
                eventDispatcher.dispatchEvents();
            }
        }
    }
    /*
    Method to post data
    */
    postData(url, data) {
        return fetch(url, {
            body: data,
            cache: 'no-cache',
            method: 'POST',
            mode: 'no-cors'
        })
    }

    /*sendLibraryTrackingData(data){
        this.postData(getConfig().url, this.addMetaData(data));
    }*/
}

const eventDispatcher = new EventDispatcher();
eventDispatcher.dispatch = eventDispatcher.dispatch.bind(eventDispatcher);
eventDispatcher.dispatchEvents = throttle(eventDispatcher.dispatch, getConfig().throttle_frequency);
//const sendLibraryTrackingData = eventDispatcher.sendLibraryTrackingData.bind(eventDispatcher);

export default eventDispatcher;
//export {sendLibraryTrackingData}; 