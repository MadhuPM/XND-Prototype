import {version} from '../version' //This file is generated during build by genversion


class Settings{
    constructor(){
        //Update analytics settings if set in env
        if (process.env && process.env.analytics) {
            this.setConfig(process.env.analytics)
        } 
    }
    analyticsSettings = {
        maxBatchSize:100, // the maximum number of events to send in one batch
        frequency: 60000, // how often to send data to web service in milliseconds
        maxLogDataSize: 10000, // if there is a failure sending data to analytics web service, data will continue to pileup until it reaches this limit. After this limit, the oldest data will be deleted. 
       // headerTemplate: 'ama_webanalyticsdata_dev_clickstreamstats_tpl', // default template
        version: version,
        throttle_frequency: 5000,
        tsFormat: 'YYYY-MM-DDTHH:mm:ss.SSSSZZ', //Default timestamp format required by Doppler
        analyticsEnabled: false //by default analytics is disabled.
       // url:'http://ama-ds-dev.statestr.com:8080/AMADataService/data/asyncPostAppBulkService.action'
    }

    setConfig(customSettings){
        this.analyticsSettings = Object.assign({}, { ...this.analyticsSettings},{ ...customSettings})
        this.analyticsSettings.subappcode = this.analyticsSettings.subappcode ? this.analyticsSettings.subappcode : this.analyticsSettings.appcode   
    }
    getConfig(){
        return this.analyticsSettings;
    }
    
}
const settings = new Settings();
const setConfig = settings.setConfig.bind(settings);
const getConfig = settings.getConfig.bind(settings);

export {setConfig, getConfig}