import moment from 'moment'
import {getConfig, setConfig} from './DefaultAnalyticsSettings'
import trackingData from './TrackingData'
import eventDispatcher from './Dispatcher'
import {CDTTrackApp,CDTTrackMount,CDTTrack} from './hocs'

class CdtTrackAnalytics {
    
    addData(payload) {
        if(trackingData.size() >= getConfig().maxLogDataSize ){
            trackingData.remove(1);  //free up spcae by removing old data. 
        }
        trackingData.add(payload);
        eventDispatcher.dispatchEvents();
    }
    
    dispatcher(data) {
        //verify configuration
        if(!getConfig().analyticsEnabled || !getConfig().headerTemplate || !getConfig().url ){
            setConfig({analyticsEnabled:false})
            console.warn("CDTAnalytics: analytics has been disabled. Please check configuration.")
            return;
        }
        this.addData(data);
    }
    
}

const cdtTrackAnalytics = new CdtTrackAnalytics();
const CDTTrackingEventDispatcher = cdtTrackAnalytics.dispatcher.bind(cdtTrackAnalytics);
const CDTTrackingConfig = setConfig;

export {
    CDTTrackingEventDispatcher,
    CDTTrackingConfig,
    CDTTrackApp,
    CDTTrackMount,
    CDTTrack
}