export function paginationParams(pageSize) {
  if (!pageSize) {
    return null;
  }

  return {
    limit: pageSize,
    __rid: new Date().getTime(),
    start: 0
  };
}
