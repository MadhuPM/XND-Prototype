import {parseIDFData, getFormUrlencodedParams} from './formatters.js';
import {LOADLIST, REFRESH, LOADONCE} from './IdfActionConstants';
import {getPagingParams} from './idfDataReducer';
import {paginationParams} from './paginationParams';
import AlertBanner from '../components/AlertBanner';

export const CLOUD_SERVICE = Symbol('CLOUD_SERVICE');

function getError(data) {
  if (data && data.length > 0) {
    const {__errorMsg} = data[0];
    if (__errorMsg) {
      try {
        const errorObj = JSON.parse(__errorMsg);
        if (errorObj.success) {
          return null;
        }
        return errorObj.errors.reduce((acc, err) => {
          if (err.id === '__errorMsg') {
            acc._error = err.msg;
          } else {
            acc[err.id] = err.msg;
          }
          return acc;
        }, {});
      } catch (parseError) {
        // console.error(__errorMsg);
        return {_error: 'Error executing service.'};
      }
    }
  }
  return null;
}


// TODO: add support for request timeout
export function callCloudService(params, url, dateFields, dateTimeFields, bigDecimalFields, next) {
  return fetch(url,
  {method: 'post',
    headers: {
      'Accept': 'application/json',
      'Content-type': 'application/x-www-form-urlencoded; charset=UTF-8'},
    body: params,
    credentials: 'include',
    mode: 'cors'
    })
    .then(response => {
      const contentType = response.headers.get('content-type')
      if (contentType.includes('application/json')) {
        return response.json().then(json => {
          if (!response.ok) {
            return Promise.reject(json);
          }
          const xdata = json.xdata;
          const {total_count, start_index, app, tran, created_at} = xdata;
          const metadata = {total_count, start_index, app, tran, created_at};
          const data = parseIDFData(xdata.rows, dateFields, dateTimeFields, bigDecimalFields);
          let err = xdata.error ? {_error: xdata.error.message} : null;
          err = err || getError(data);
          if (err) {
            return Promise.reject(err);
          }
          return {data, metadata};
        });
      }

      if (contentType && contentType.startsWith('text/html')) {
         response.text().then(html => {
         if (html.includes('SiteMinder') || html.includes('<TITLE>State Street Login</TITLE>')) {
           window.location.reload(true)
         }
       })
     }

      const type = 'warning'
      AlertBanner.show(
        type,
        response.statusText
      )
      return Promise.reject({_error: response.statusText});
    });
}

const  cloudServiceMiddleWare = (context="") => {
  return store => next => action => {
    const {meta = {}, type} = action;
    const cloudServiceCall = meta[CLOUD_SERVICE];
    if (action.type.startsWith('REST_COMPONENT_DATA')) {
      return next(action);
    }
    if (typeof cloudServiceCall === 'undefined') {
      return next(action);
    }
  
    const state = store.getState();
    const {idfAction, params = []} = cloudServiceCall;
    const timestamp = new Date().getTime();
  
    let {metadata} = cloudServiceCall;

    const contextWithSlash = context.startsWith('/') ? context : `/${context}` 
    window.context = contextWithSlash

    const {idfNumber, idfData, keyField, pageSize, url = `${contextWithSlash}/json`} = metadata;
    const {dateFields, dateTimeFields, bigDecimalFields} = idfData;
  
    let paramArray = params;
    if (!Array.isArray(paramArray)) {
      paramArray = [paramArray];
    }
  
    let actionNumber = idfAction === REFRESH ? LOADLIST : idfAction;
    if (idfAction === LOADONCE && type.indexOf('::' > 0)) {
      // check state to see if data exists
      const path = type.split('::');
      const registry = state[path[0]] || {};
      const component = registry[path[1]];
      if (component && component.data) { // already called once
        return null;
      }
      // otherwise use normal loadlist
      actionNumber = LOADLIST;
    }
  
    let pagingParams = {};
    if (pageSize) {
      pagingParams = getPagingParams(paramArray);
      if ((idfAction === LOADLIST && !pagingParams['__rid']) ||
        idfAction === REFRESH) {
        pagingParams = paginationParams(pageSize);
      }
    }
  
    paramArray[0] = {...paramArray[0], __request: idfNumber, __action: actionNumber, ...pagingParams};
  
    const requestAction = {
      type,
      payload: paramArray,
      meta: {sequence: 'start', id: timestamp, idfAction, keyField}
    };
  
    next(requestAction);
  
    const timeTaken = () => {
      const now = new Date().getTime();
      const responseTime = (now - timestamp) / 1000;
      const props = {id: timestamp, responseTime};
      return props;
    };
  
    const urlEncodedParams = paramArray.map(
      paramObj => getFormUrlencodedParams(paramObj,
        dateFields, dateTimeFields, bigDecimalFields)).join('&');
  
    return callCloudService(urlEncodedParams, url, dateFields, dateTimeFields, bigDecimalFields, next).then(
      response => next({
        type,
        payload: response,
        meta: {sequence: 'complete', ...timeTaken(), idfAction, keyField}
      }),
      error => next({
        type,
        error: true,
        payload: error,
        meta: {sequence: 'complete', ...timeTaken(), idfAction, keyField}
      })
    );
  };
} 

export default cloudServiceMiddleWare