import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { REST_SERVICE } from './restMiddleware'
import {
  LOAD, UPDATE, ADD, DELETE, LOADONCE,
  LIST, CLEAR, REFRESH, REST_REDUCER_KEY
} from './restConstants'
const initData = { data: [] }

export default function (restServiceMapping, columns, keyField, url, componentId = restServiceMapping) {
  let dateFields = []
  let dateTimeFields = []
  let dateTimeFormats = []
  let bigDecimalFields = []
  let keyColumns = []

  if (columns && columns.length > 0) {
    dateFields = columns.filter(col => col.dataType === 'date').map(col => col.dataKey)
    dateTimeFields = columns.filter(col => col.dataType === 'datetime').map(col => col.dataKey)
    dateTimeFormats = columns.filter(col => col.dataType === 'datetime').map(col => col.format ? col.format : '')
    bigDecimalFields = columns
      .filter(col => col.dataType === 'bigdecimal')
      .map(col => col.dataKey)
    keyColumns = columns.filter(col => col.isKey)
  }

  let uniqueKeyField = keyField
  if (!uniqueKeyField && keyColumns.length > 0) {
    uniqueKeyField = keyColumns[0].dataKey
  }

  const dateAndBigDecimalFields = { dateFields, dateTimeFields, dateTimeFormats, bigDecimalFields }
  const metadata = {restServiceMapping, keyField: uniqueKeyField, dateAndBigDecimalFields, url }


  const actionCreators = {
    load: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${LOAD}`,
        meta: {
          params: paramArray,
          ...metadata
        }
      }
    },

    update: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${UPDATE}`,
        meta: {
          params: paramArray,
          ...metadata
        }
      }
    },

    delete: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${DELETE}`,
        meta: {
          params: paramArray,
          ...metadata
        }
      }
    },

    add: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${ADD}`,
        meta: {
          params: paramArray,
          ...metadata
        }
      }
    },

    refresh: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${REFRESH}`,
        meta: {
          params: paramArray,
          ...metadata
        }
      }
    },

    list: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${LIST}`,
        meta: {
          params: paramArray,
          ...metadata
        }
      }
    },

    loadOnce: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${LOADONCE}`,
        meta: {
          params: paramArray,
          ...metadata
        }
      }
    },

    clear: () => {
      return {
        type: `${componentId}::${CLEAR}`,
        payload: { data: [] },
        meta: { sequence: 'complete', keyField: uniqueKeyField }
      }
    },

    localAdd: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${ADD}`,
        payload: { data: paramArray },
        meta: { sequence: 'complete', keyField: uniqueKeyField }
      }
    },

    localDelete: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${DELETE}`,
        payload: { data: paramArray },
        meta: { sequence: 'complete', keyField: uniqueKeyField }
      }
    },

    localUpdate: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${UPDATE}`,
        payload: { data: paramArray },
        meta: { sequence: 'complete', keyField: uniqueKeyField }
      }
    },

    localList: (params = {}) => {
      const paramArray = { ...params }
      return {
        type: `${componentId}::${LIST}`,
        payload: { data: paramArray },
        meta: { sequence: 'complete', keyField: uniqueKeyField }
      }
    }

  }

  const componentIdActions = `${componentId}Actions`


  const mapStateToProps = (state) => {
    return {
      [componentId]: state[REST_REDUCER_KEY][componentId] || initData
    }
  }

  const mapDispatchToProps = (dispatch) => {
    return { [componentIdActions]: bindActionCreators(actionCreators, dispatch), dispatch }
  }

  return function connectComp(ConnectedComponent) {
    return connect(mapStateToProps, mapDispatchToProps)(ConnectedComponent)
  }
}

