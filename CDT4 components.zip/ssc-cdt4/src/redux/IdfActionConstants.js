export const LOAD = 0;
export const DATACHANGED = 1;
export const UPDATE = 2;
export const ADDNEW = 3;
export const DELETE = 4;
export const LOADLIST = 5;
export const CLEAR = 6;
export const REFRESH = 7;
export const LOADONCE = 8;

