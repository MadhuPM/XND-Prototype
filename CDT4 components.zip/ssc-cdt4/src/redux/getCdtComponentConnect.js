import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {CLOUD_SERVICE} from './CloudServiceAPI';
import {LOAD, UPDATE, ADDNEW, DELETE,
  LOADLIST, CLEAR, REFRESH} from './IdfActionConstants';

export function getCdtComponentConnect(registryName) {
  return (componentId, idfNumber, columns, keyField, url, pageSize) => {
    const mapStateToProps = (state) => {
      return {
        [componentId]: state[registryName][componentId] || {data: []}
      };
    };

    let dateFields = [];
    let dateTimeFields = [];
    let bigDecimalFields = [];
    let keyColumns = [];

    if (columns && columns.length > 0) {
      dateFields = columns.filter(col => col.dataType === 'date').map(col => col.dataKey);
      dateTimeFields = columns.filter(col => col.dataType === 'datetime').map(col => col.dataKey);
      bigDecimalFields = columns.filter(col => col.dataType === 'bigdecimal').map(col => col.dataKey);
      keyColumns = columns.filter(col => col.isKey);
    }

    let uniqueKeyField = keyField;
    if (!uniqueKeyField && keyColumns.length > 0) {
      uniqueKeyField = keyColumns[0].dataKey;
    }

    const idfData = { dateFields, dateTimeFields, bigDecimalFields };
    const metadata = { idfNumber, pageSize, keyField: uniqueKeyField, idfData, url };
    const action = `${registryName}::${componentId}`;

    const actionCreators = {

      load: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          meta: {
            [CLOUD_SERVICE]: {
              idfAction: LOAD,
              params: paramArray,
              metadata
            }
          }
        };
      },

      update: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          meta: {
            [CLOUD_SERVICE]: {
              idfAction: UPDATE,
              params: paramArray,
              metadata
            }
          }
        };
      },

      delete: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          meta: {
            [CLOUD_SERVICE]: {
              idfAction: DELETE,
              params: paramArray,
              metadata
            }
          }
        };
      },

      addNew: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          meta: {
            [CLOUD_SERVICE]: {
              idfAction: ADDNEW,
              params: paramArray,
              metadata
            }
          }
        };
      },

      refresh: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          meta: {
            [CLOUD_SERVICE]: {
              idfAction: REFRESH,
              params: paramArray,
              metadata
            }
          }
        };
      },

      loadList: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          meta: {
            [CLOUD_SERVICE]: {
              idfAction: LOADLIST,
              params: paramArray,
              metadata
            }
          }
        };
      },

      clear: () => {
        return {
          type: action,
          payload: { data: []},
          meta: { sequence: 'complete', idfAction: CLEAR, keyField: uniqueKeyField }
        };
      },

      localAddNew: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          payload: { data: paramArray },
          meta: { sequence: 'complete', idfAction: ADDNEW, keyField: uniqueKeyField }
        };
      },

      localDelete: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          payload: { data: paramArray },
          meta: { sequence: 'complete', idfAction: DELETE, keyField: uniqueKeyField }
        };
      },

      localUpdate: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          payload: { data: paramArray },
          meta: { sequence: 'complete', idfAction: UPDATE, keyField: uniqueKeyField }
        };
      },

      localLoadList: (params = []) => {
        const paramArray = (Array.isArray(params) ? params : [params]).slice();
        return {
          type: action,
          payload: { data: paramArray},
          meta: { sequence: 'complete', idfAction: LOADLIST, keyField: uniqueKeyField }
        };
      }
    };

    const componentIdActions = `${componentId}Actions`;

    const mapDispatchToProps = (dispatch) => {
      return { [componentIdActions]: bindActionCreators(actionCreators, dispatch), dispatch };
    };

    return function connectComp(ConnectedComponent) {
      return connect(mapStateToProps, mapDispatchToProps)(ConnectedComponent);
    };
  };
}

