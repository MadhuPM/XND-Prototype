import {
  UPDATE, ADD, DELETE, LOAD,REFRESH
} from './restConstants'

/**
 * 
 * @param {*} state 
 * below is the sample data of the global state in the store,
 * and the value of key 'restReducer' will passed to this reducer
 
 {
  restReducer: {
    employee: {
      data: [],
      ...
    },
    department: {
      data: [],
      ...
    }
  }
  ,
  otherReducer:{
  }
}


 * @param {*} action 
 */
export function restReducer(state = {}, action) {
  const {meta = {}, type=''} = action
  if (type.split('::').length === 2 && meta.keyField) {
    const stateSliceName = type.split('::')[0]
    const stateSlice = state[stateSliceName] || initialState
    const {error, payload } = action
    const { sequence, id, keyField } = meta
    const restAction = type.split('::')[1]

    if (error) {
      return {
        ...state, [stateSliceName]: {
          ...stateSlice, error: payload, loading: false
        }
      }
    }

    if (sequence === 'start') {
      return {
        ...state, [stateSliceName]: {
          ...stateSlice, ...meta
        }
      }
    }

    const { data: oldData = [] } = stateSlice
    let newData = payload.data
    // user can return object or array to ui for ADD, LOAD, UPDATE, DELETE
    if (!Array.isArray(newData)) {
      newData = [newData]
    }
    let updateMap
    let deletedKeys
    if (keyField) {
      switch (restAction) {
        case ADD:
          newData = [...newData, ...oldData]
          break
        case LOAD:
          updateMap = newData.reduce((map, item) => {
            map[item[keyField]] = item
            return map
          }, {})
          newData = oldData.map(item => {
            const key = item[keyField]
            const newVal = updateMap[key]
            if (newVal) {
              delete (updateMap[key])
              return newVal
            }
            return item
          })
          Object.keys(updateMap).forEach(key => {
            newData.push(updateMap[key])
          })
          break
        case UPDATE:
          updateMap = newData.reduce((map, item) => {
            map[item[keyField]] = item
            return map
          }, {})
          newData = oldData.map(item => {
            const key = item[keyField]
            return updateMap[key] || item
          })
          break
        case DELETE:
          deletedKeys = newData.map(item => item[keyField])
          newData = oldData.filter(item => deletedKeys.indexOf(item[keyField]) === -1)
          break
        default:
          break
      }
    }
    return { ...state, [stateSliceName]: { ...stateSlice, error: false, loading: false, data: newData, keyField } }
  }
  return state
}

const initialState = {
  data: [],
  params: {},
  loading: false,
  error: false
}