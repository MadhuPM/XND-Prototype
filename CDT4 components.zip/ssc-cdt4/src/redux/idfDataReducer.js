import {combineReducers} from 'redux';
import {UPDATE, ADDNEW, DELETE, LOAD,
  LOADLIST, REFRESH} from './IdfActionConstants';

export function getPagingParams(payload) {
  const paramObj = Array.isArray(payload) ? payload[0] || {} : payload;
  if (!paramObj.__rid) {
    return {};
  }
  return {
    __rid: paramObj.__rid,
    start: paramObj.start,
    limit: paramObj.limit,
    __sort_config: paramObj.__sort_config,
    __filter_config: paramObj.__filter_config
  };
}

export function idfDataReducer(state, action) {
  const {meta = {}, error, payload} = action;
  const {sequence, id, idfAction, keyField} = meta;

  if (error) {
    return {...state, error: payload, loading: false};
  }

  if (sequence === 'start') {
    const metadata = getPagingParams(payload);
    const newMetadata = {...state.metadata, ...metadata};
    return {...state, error: false, loading: true,
      params: payload, timestamp: id, metadata: newMetadata};
  }
  let newMetadata = state.metadata;
  if (LOADLIST === idfAction || REFRESH === idfAction) {
    newMetadata = {...newMetadata, ...payload.metadata};
  }

  const {data: oldData = []} = state;
  let newData = payload.data;
  let updateMap;
  let deletedKeys;
  if (keyField) {
    switch (idfAction) {
      case ADDNEW:
        newData = [...newData, ...oldData];
        break;
      case LOAD:
        updateMap = newData.reduce((map, item) => {
          map[item[keyField]] = item;
          return map;
        }, {});
        newData = oldData.map(item => {
          const key = item[keyField];
          const newVal = updateMap[key];
          if (newVal) {
            delete(updateMap[key]);
            return newVal;
          }
          return item;
        });
        Object.keys(updateMap).forEach(key => {
          newData.push(updateMap[key]);
        });
        break;
      case UPDATE:
        updateMap = newData.reduce((map, item) => {
          map[item[keyField]] = item;
          return map;
        }, {});
        newData = oldData.map(item => {
          const key = item[keyField];
          return updateMap[key] || item;
        });
        break;
      case DELETE:
        deletedKeys = newData.map(item => item[keyField]);
        newData = oldData.filter(item => deletedKeys.indexOf(item[keyField]) === -1);
        break;
      default:
        break;
    }
  }
  return {...state, error: false, loading: false, data: newData, keyField, metadata: newMetadata};
}

const initialState = {
  data: [],
  params: {},
  loading: false,
  error: false,
  timestamp: undefined
};


export function getRegistryDataReducer(registryName) {
  const key = `${registryName}::`;
  return (state = {}, action) => {
    const {type = '', payload = {}} = action;
    if (type.startsWith(key)) {
      const stateSliceName = type.split('::')[1];
      const stateSlice = state[stateSliceName] || initialState;
      const newStateSlice = idfDataReducer(stateSlice, action);
      return {...state, [stateSliceName]: newStateSlice};
    }
    else if(type === 'ADD_BREADCRUMB') {//Add breadcrumb by app, not router
      const {childPath = '', dropDown = null} = payload;
      return {...state, childPath, dropDown};
    }
    return state;
  };
}