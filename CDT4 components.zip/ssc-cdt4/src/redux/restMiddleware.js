import {parseData, getEncodedParams} from './restFormatters.js'
import {LIST, REFRESH, LOADONCE,
  LOAD, UPDATE, ADD, DELETE, REST_REDUCER_KEY
} from './restConstants'
import AlertBanner from '../components/AlertBanner'

export const REST_SERVICE = Symbol('REST_SERVICE')

function callCloudService(params, url, dateFields, dateTimeFields, dateTimeFormats, bigDecimalFields, next) {
  return fetch(url,
  {method: 'post',
    headers: {
      Accept: 'application/json',
      'Content-type': 'application/json; charset=UTF-8'
    },
    body: JSON.stringify(params),
    credentials: 'include',
    mode: 'cors'
    })
    .then(response => {
      const contentType = response.headers.get('content-type')
      if (contentType.includes('application/json')) {
        return response.json().then(json => {
          if (!response.ok) {
            return Promise.reject(json)
          }
          let data = []
          if (json) {
            data = parseData(json, dateFields, dateTimeFields, dateTimeFormats, bigDecimalFields)
          }
          const err = json.success === undefined ? null : {errorMsg: json.errorMsg}
          if (err) {
            return Promise.reject(err)
          }
          return {data}
        })
      }

      // if html response then reload because it's probably SiteMinder session timeout
      // may need to add more sophisticated check
      if (contentType && contentType.startsWith('text/html')) {
        response.text().then(html => {
         if (html.includes('SiteMinder') || html.includes('<TITLE>State Street Login</TITLE>')) {
           window.location.reload(true)
         }
       })
     }

      AlertBanner.show(
        'warning',
        response.statusText
      )

      return Promise.reject({errorMsg: response.statusText})
    })
}

 

const  restMiddleware = (context="") => {
  return store => next => action => {
    const {meta = {}, type={}} = action
    const {restServiceMapping, dateAndBigDecimalFields, keyField,params={} } = meta

    // when meta does not have 'restServiceMapping', the action will not be processed in this middlware
    if (!restServiceMapping) {
      return next(action)
    }

    const state = store.getState()
  
    let restAction = type.split("::")[1]

    const contextWithSlash = context.startsWith('/') ? context : `/${context}` 
    let { url = `${contextWithSlash}/api/${restServiceMapping}` } = meta
  
    const {dateFields, dateTimeFields, dateTimeFormats, bigDecimalFields} = dateAndBigDecimalFields
  
    restAction = restAction === REFRESH ? LIST : restAction
    if (restAction === LOADONCE && type.indexOf('::' > 0)) {
      // check state to see if data exists
      const path = type.split('::')
      const sliceData = state[REST_REDUCER_KEY] || {}
      const component = sliceData[path[0]]
      if (component && component.data && component.data.length > 0) { // already called once
        return Promise.resolve(component)
          .then(response => next({
            type,
            payload: {data: response.data},
            meta: {...meta, sequence: 'complete',
              responseTime: 0
            }
          }))
      }
      // otherwise use normal list
      restAction = LIST
    }
    const requestAction = {
      type,
      meta: {...meta, sequence: 'start', error: false, loading: true}
    }
  
    next(requestAction)
  
    switch (restAction) {
      case LIST: url += '/list' 
      break
      case LOAD: url += '/load' 
      break
      case ADD: url += '/add' 
      break
      case DELETE: url += '/delete' 
      break
      case UPDATE: url += '/update' 
      break
      default: url += '/list'
    }
  
    const encodedParams = getEncodedParams(params, dateFields, dateTimeFields, dateTimeFormats, bigDecimalFields)
  
    return callCloudService(encodedParams, url, dateFields, dateTimeFields, dateTimeFormats, bigDecimalFields, next)
      .then(
        response => next({
          type,
          payload: response,
          meta: {...meta, sequence: 'complete'}
        }),
        errorMsg => next({
          type,
          error: true,
          payload: errorMsg,
          meta: {...meta, sequence: 'complete'}
        })
      )
  }
} 
export default restMiddleware

