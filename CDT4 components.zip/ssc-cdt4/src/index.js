
import GlobalNavigation_ from './components/GlobalNavigation'
import Icon_, {ICONS} from './components/Icon'
import Button_, {CardButton as CardButton_} from './components/Button'
import Tag_ from './components/Tag'
import AlertBanner_ from './components/AlertBanner'
import Menu_,{SubMenu as SubMenu_, MenuItem as MenuItem_} from './components/Menu'
import Accordion_, {Panel as Panel_} from './components/Accordion'
import Filter_ from './components/Filter'
import DataGrid_ from './components/DataGrid/DataGrid'
import TimePicker_ from './components/TimePicker'
import Toggle_ from './components/Toggle'
import Tabs_, {Tab as Tab_} from './components/Tabs'
import SecondaryNavigation_, {Breadcrumbs as Breadcrumbs_} from './components/SecondaryNavigation'
import Form_, {Select as Select_, Checkbox as Checkbox_, CheckboxGroup as CheckboxGroup_, Radio as Radio_, Textarea as Textarea_, TextInput as TextInput_} from './components/Form'
import Tooltip_ from './components/Tooltip'
import Tile_ from './components/Tile'
import Launchpad_, {MiniLaunchpad as MiniLaunchpad_} from './components/Launchpad'
import Overlay_ from './components/Overlay'
import Grid_, {Row as Row_, Col as Col_, Clearfix as Clearfix_} from './components/Grid'
import { CDTTrackingEventDispatcher, CDTTrackingConfig, CDTTrackApp, CDTTrackMount, CDTTrack } from './tracker'
import {
	DonutChart as DonutChart_,
	BarChart as BarChart_,
	LineChart as LineChart_,
	StackedBarChart as StackedBarChart_,
	ColumnPercentageChart as ColumnPercentageChart_,
	WhiskerChart as WhiskerChart_,
	HeatMapChart as HeatMapChart_,
	HeatBarChart as HeatBarChart_,
	BubbleChart as BubbleChart_,
	FloatingBarChart as FloatingBarChart_,
	GroupBarChart as GroupBarChart_,
	LineSliderChart as LineSliderChart_,
	Label as ChartLabel_
} from './components/Chart'
import Search_ from './components/Search'
import {DatePicker as DatePicker_, RangePicker as RangePicker_} from './components/DatePicker'
import Card_, {CardsLayout as CardsLayout_} from './components/Card'
import GlobalSearch_ from './components/GlobalNavigation/GlobalSearch'
import Modal_ from './components/Modal'
import Footer_ from './components/Footer'
import ProgressIndicator_ from './components/ProgressIndicator'
import UserProfile_ from './components/UserProfile'
import AlertCenter_ from './components/AlertCenter'
import Sorting_ from './components/Sorting'
import Loading_ from './components/Loading'
import StatusMonitor_ from './components/StatusMonitor'
import {FlexPanel as FlexPanel_, FixedPanel as FixedPanel_,
	HorizontalLayout as HorizontalLayout_, VerticalLayout as VerticalLayout_} from './components/Layout'
import ListBuilder_ from './components/ListBuilder/ListBuilder'
//import DraggableCell_ from './components/DataGrid/DraggableCell'

import '../style/design2.less'

// // HOC
import {CDTBaseHOC} from "cdt-core";

let Button = CDTBaseHOC(Button_)
let Overlay = CDTBaseHOC(Overlay_)
let GlobalNavigation = (GlobalNavigation_)
let Icon = CDTBaseHOC(Icon_)
let CardButton = CDTBaseHOC(CardButton_)
let Tag = CDTBaseHOC(Tag_)
let AlertBanner = CDTBaseHOC(AlertBanner_)
let Menu = CDTBaseHOC(Menu_)
let SubMenu = CDTBaseHOC(SubMenu_)
let MenuItem = CDTBaseHOC(MenuItem_)
let Accordion = CDTBaseHOC(Accordion_)
let Panel = CDTBaseHOC(Panel_)
let Filter = CDTBaseHOC(Filter_)
let DataGrid = CDTBaseHOC(DataGrid_)
let TimePicker = CDTBaseHOC(TimePicker_)
//let DraggableCell = CDTBaseHOC(DraggableCell_)
let Grid = CDTBaseHOC(Grid_)
let Row = CDTBaseHOC(Row_)
let Col = CDTBaseHOC(Col_)
let Clearfix = CDTBaseHOC(Clearfix_)
let Form = CDTBaseHOC(Form_)
let Select = CDTBaseHOC(Select_)
let Checkbox = CDTBaseHOC(Checkbox_)
let CheckboxGroup = CDTBaseHOC(CheckboxGroup_)
let Textarea = CDTBaseHOC(Textarea_)
let TextInput = CDTBaseHOC(TextInput_)
let Radio = CDTBaseHOC(Radio_)
let Toggle = CDTBaseHOC(Toggle_)
let Tabs = CDTBaseHOC(Tabs_)
let Tab = CDTBaseHOC(Tab_)
let Card = CDTBaseHOC(Card_)
let CardsLayout = CDTBaseHOC(CardsLayout_)
let SecondaryNavigation = SecondaryNavigation_
let Breadcrumbs = Breadcrumbs_
let Tooltip = CDTBaseHOC(Tooltip_)
let Tile = CDTBaseHOC(Tile_)
let Search = CDTBaseHOC(Search_)
let DatePicker = CDTBaseHOC(DatePicker_)
let RangePicker = CDTBaseHOC(RangePicker_)
let GlobalSearch = CDTBaseHOC(GlobalSearch_)
let Modal = CDTBaseHOC(Modal_)
let ProgressIndicator = CDTBaseHOC(ProgressIndicator_)
let UserProfile = CDTBaseHOC(UserProfile_)
let AlertCenter = CDTBaseHOC(AlertCenter_)
let Sorting = CDTBaseHOC(Sorting_)
let Launchpad = CDTBaseHOC(Launchpad_)
let MiniLaunchpad = CDTBaseHOC(MiniLaunchpad_)
let DonutChart = CDTBaseHOC(DonutChart_)
let BarChart = CDTBaseHOC(BarChart_)
let LineChart = CDTBaseHOC(LineChart_)
let StackedBarChart = CDTBaseHOC(StackedBarChart_)
let ColumnPercentageChart = CDTBaseHOC(ColumnPercentageChart_)
let WhiskerChart = CDTBaseHOC(WhiskerChart_)
let HeatMapChart = CDTBaseHOC(HeatMapChart_)
let HeatBarChart = CDTBaseHOC(HeatBarChart_)
let BubbleChart = CDTBaseHOC(BubbleChart_)
let FloatingBarChart = CDTBaseHOC(FloatingBarChart_)
let GroupBarChart = CDTBaseHOC(GroupBarChart_)
let LineSliderChart = CDTBaseHOC(LineSliderChart_)
let ChartLabel = CDTBaseHOC(ChartLabel_)

let Footer = CDTBaseHOC(Footer_)
let Loading = CDTBaseHOC(Loading_)
let StatusMonitor = CDTBaseHOC(StatusMonitor_)

let FlexPanel = CDTBaseHOC(FlexPanel_)
let FixedPanel = CDTBaseHOC(FixedPanel_)
let HorizontalLayout = CDTBaseHOC(HorizontalLayout_)
let VerticalLayout = CDTBaseHOC(VerticalLayout_)

let ListBuilder = CDTBaseHOC(ListBuilder_)



import { getCdtComponentConnect } from './redux/getCdtComponentConnect'
const connectCdtDataComponent = getCdtComponentConnect('CDT_COMPONENT_DATA')
const connectIdf = connectCdtDataComponent

import CloudServiceAPI  from './redux/CloudServiceAPI'
import {getRegistryDataReducer } from './redux/idfDataReducer'
//const idfReducer = getRegistryDataReducer('idfReducer')
import {cloudExportExcel, cloudExportCsv} from './components/DataGrid/CloudServiceExport'



import connectRest from './redux/restComponentConnect'
import restMiddleware from './redux/restMiddleware'
import { restReducer } from './redux/restReducer'





export {
	GlobalNavigation,
	Icon,
	ICONS,
	Button,
	CardsLayout,
	Card,
	CardButton,
	Tag,
	AlertBanner,
	Menu,
	SubMenu,
	MenuItem,
	Accordion,
	Panel,
	Filter,
	DataGrid,
	TimePicker,
	Tabs,
	Tab,
	Toggle,
	SecondaryNavigation,
	Breadcrumbs,
	Form,
	Tooltip,
	Tile,
	Launchpad,
	Overlay,
	Grid,
	Row,
	Col,
	Clearfix,
	DonutChart,
	BarChart,
	LineChart,
	StackedBarChart,
	ColumnPercentageChart,
	WhiskerChart,
	HeatMapChart,

	HeatBarChart,
	BubbleChart,
	FloatingBarChart,
	GroupBarChart,
	LineSliderChart,
	ChartLabel,

	Select,
	Search,
	MiniLaunchpad,
	GlobalSearch,
	Checkbox,
	CheckboxGroup,
	Radio,
	Textarea,
	TextInput,
	Modal,
	Footer,
	ProgressIndicator,
	UserProfile,
	AlertCenter,
	Sorting,
	Loading,
	StatusMonitor,
	RangePicker,
	FlexPanel,
	FixedPanel,
	HorizontalLayout,
	VerticalLayout,
	DatePicker,
	ListBuilder,

	//IDF CloudService Components
	CloudServiceAPI,
	connectCdtDataComponent,
	getRegistryDataReducer,
	// idfReducer,
	connectIdf,
	cloudExportExcel,
	cloudExportCsv

	//Rest Components
	,restMiddleware,
	connectRest,
	restReducer,
	CDTTrackingEventDispatcher, 
	CDTTrackingConfig, 
	CDTTrackApp, 
	CDTTrackMount, 
	CDTTrack 
}