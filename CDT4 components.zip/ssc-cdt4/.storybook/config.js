import { configure , addDecorator} from '@storybook/react'
import { setOptions } from '@storybook/addon-options';

const req = require.context('../stories', true , /\.stories\.js$/)

function loadStories(){
    req.keys().forEach(filename => req(filename));
}

//setOptions({ name: 'Storybook for sscdt3-design2',url: '#',addonPanelInRight: true})
configure(loadStories, module)

