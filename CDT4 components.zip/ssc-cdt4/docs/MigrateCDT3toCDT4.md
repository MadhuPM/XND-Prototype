# Migrate CDT 3 UI to CDT 4 UI

## Introduction  
CDT 4 UI framework is a new re-written library and based on [State Street Design](https://design.statestr.com) which is the standard look and feel in State Street.

This doc will analyse the same and different points between CDT 3 and CDT 4 and provide a best way for migration.

## Same Points  
CDT 4 UI framework copied lots of code from CDT 3 UI framework so they share most features and APIs
- Environment setup
- Build and Deployment
- React JS technology stacks include redux/ES6/Babel/Webpack/React-Router
- Same DataGrid implementation except some small features like filter/tree column
- Same API to call IDF backend web service 
- Most CDT 4 components are based on React-Bootstrap/React-Virtualized/React-Formal which are widely used in CDT3

## Different Points  
- Look and Feels
- React JS versions break change: CDT 4 UI is based on React 16 while CDT 3 UI is based on React 15. It is a break change
- Different webpack configurations since CDT 4 UI upgraded to latest webpack
- Different 3rd party libraries like React-Router/React-Bootstrap so the configurations must be changed
- Currently no DataGrid filters/inline editors/trees in CDT 4 UI
- Currently no Date Time Picker in CDT 4 UI
- Components' APIs are different. CDT 4 components are wraps of React-Bootstrap/React-Virtualized which are widely used in CDT 3. They are similiar with those in CDT 3 but still there are small changes
- CDT 4 UI added restful web service backend support
- CDT 4 UI added charts support which is based on D3
- CDT 4 provided a tool to generate a template project
- Application should create and own redux store in CDT 4 while in CDT 3 framework creates and owns redux store
- CDT 4 uses Maven to manage Java Backend Project but this is optional. App team can change it freely
- CDT 4 has better design and documents support
- CDT 4 removed the index servlet. The index page is a pure HTML file
- CDT 4 removed some layout components as all layouts can be achieved by pure CSS styles

## Comparison Summary

|       | CDT 3 | CDT 4 | Is Compatible |
|-------|----------|---------|----------|
| Look & Feel | No Components Design | Special Design | No |
| React  | v15 | v16 | No |
| Webpack | v1 | v3 | No |
| React-Router | v2 | v4 | No |
| Components | React-Bootstrap / React-Virtualized | Wrap of React-Bootstrap / React-Virtualized | Most Compatible |
| Form | React-Formal / Redux-Form | Wrap of React-Formal | Most Compatible |
| IDF Webservice | Yes | Yes | Yes |
| Restful Webservice | No | Yes | No |
| DataGrid Filter | Yes | Design not ready | No |
| Date Picker | Yes | Design not ready | No |
| Charts | React-Victory | Wrap of D3 | No |
| Project Generating Tool | No | Yes | No |
| Create and own redux store | Framework | Application | No |

## Migration Guide

### Project Skeleton and Configuration  
CDT 4 introduced new Webpack, new React-Router, Maven, moved out the redux-store from framework and removed the usage of index servlet, so it is better to create a new project by using the project generating tool. Please read doc [Create Project using create‐cdt4‐app generator](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/Create-Project-using-create%E2%80%90cdt4%E2%80%90app-generator) to generate a new project skeleton. Read doc [How to start running a project](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/How-to-start-running-a-project) to run up the generated project. Read doc [Anatomy of CDT4 application](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/Anatomy-of-CDT4-application) to familiar with project structure. Read doc [How to use redux in cdt4](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/How-to-use-redux-in-cdt4) to familiar with backend web service calling.

### Router Change  
It is recommended to upgrade to react-router v4. Please read doc [How to upgrade to react 16](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/How-to-upgrade-to-react-16) to familiar with react-router migration. We have not tested the compatibility of old react-router (v2 or v3) with ssc-cdt4. You can test it by yourself to see if you can still use the old react-router.

### DataGrid Change  
The usage of DataGrid in CDT 4 is almost same as which in CDT 3. Some features like filter and editor are still in design. Please read doc [How to use CDT4 datagrid table with a cloud service](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/How-to-use-CDT4-datagrid-table-with-a-cloud-service) for reference of DataGrid usage. More examples and APIs can be found in [State Street Design Playbook](https://cloud-dev1.statestr.com/playbook/patterns/tables)

### Components Change  
There are small differences in the components usage between CDT 3 and CDT 4. Please read doc [Hello World Button with SSC-CDT4](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/How-to-use-CDT4-components-in-your-application#hello-world-button-with-ssc-cdt4) to familiar with the component usage. Please look at [State Street Design Playbook](https://cloud-dev1.statestr.com/playbook/) for each component example and API references.

Some components like Dropdown List need backend data bound. The usage of those components are almost same except some parameters change. Plese read doc [How to use redux in cdt4](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/How-to-use-redux-in-cdt4) to know how to bind data from backend.

### Layout Change  
If your application uses pure CSS layout then no change is required, otherwise if it uses layout components from CDT 3 then you must change those layout components to DIV/CSS layout. Please use google for more info about CSS layout.

### Backend JAVA Migration  
First no JAVA code change is required. The old IDF web service is 100% compatible with new CDT 4.
Second the JAVA project structure change is on your decision. Our suggestion is to migrate to Maven which provides better library orgnization.

## Summary  
CDT 4 UI is not 100% compatible with CDT 3 UI. A rewrite migration is required but the efforts are acceptable compared to the benefits.

More documents: [GIT Wiki](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki)  
Code repository: [GIT Code](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/tree/Develop)  
Submit Issues/Questions/Suggestions: [GIT Issues](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/issues)  
Mail Group: [cdt3-ui-evangelists](mailto:cdt3-ui-evangelists@StateStreet.com)