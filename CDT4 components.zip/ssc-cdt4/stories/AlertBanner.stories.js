import React from 'react'
import { storiesOf } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import { withKnobs, text, boolean, number, array, object ,select } from '@storybook/addon-knobs/react'
import AlertBanner from '../src/components/AlertBanner'
const stories = storiesOf('AlertBanner', module)
stories.addDecorator(withKnobs)


  stories.add('with dynamic variables', () => {
        const titleHidden = boolean('titleHidden', false)
        const animation= text('animation','fade-in')
        const inline= boolean('titleHidden', false)
        const alertOffsetTop = text('alertOffsetTop', '10px')
        const label = text('label', 'Label')
        const type = select('type', {confirmation: 'confirmation', attention: 'attention',warning: 'warning'}, 'confirmation');
        const rootClose= boolean('rootClose', false)
        
        return (
        <AlertBanner 
            titleHidden = {titleHidden} 
            animation={animation}
            inline = {inline}
            alertOffsetTop={alertOffsetTop}
            label = {label}
            type = {type}
            rootClose = {rootClose}
            onSelect={action(' Acordion selected')}
        />)
    })
    
