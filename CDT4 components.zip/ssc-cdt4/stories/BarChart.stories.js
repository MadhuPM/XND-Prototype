import React from 'react'
import { storiesOf } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import { withKnobs, text, boolean, number, array,object } from '@storybook/addon-knobs/react'
import BarChart from '../src/components/Chart/BarChart'

const stories = storiesOf('Chart :: BarChart', module)
stories.addDecorator(withKnobs)

const donutData= [
    { 'fund': 'U.S. Equity', 'score': 1 }, { 'fund': 'U.S Equity', 'score': 2 }, { 'fund': 'Alternatives', 'score': 3 },
    { 'fund': 'Fixed Income', 'score': 4 }, { 'fund': 'Cash Equivalent', 'score': 2 }, { 'fund': 'U.S. Equity', 'score': 6 }
  ]

  stories.add('without data', () => (
        <BarChart width={250} height={220} xAxisName={'fund'} x={'fund'} y={'score'} yAxisName={'score'} />
    ))
    .add('with data', () => (
        <BarChart data = {donutData} width={250} height={220} xAxisName={'fund'} x={'fund'} y={'score'} yAxisName={'score'} />
    ))
    .add('with bar onclick', () => (
        <BarChart data = {donutData} width={250} height={220} onBarClick={action(' I was clicked')}
            xAxisName={'fund'} x={'fund'} y={'score'} yAxisName={'score'} 
            />
    ))
    .add('with dynamic variables', () => {
        const data = object('data', donutData)
        const width= number('width',250)
        const height= number('height',220)
        const xAxisName = text('xAxisName', 'fund')
        const yAxisName = text('yAxisName', 'score')
        const x = text('x', 'fund') 
        const y = text('y', 'score')

        return (<BarChart data = {data} width={width} height={height} 
            xAxisName={xAxisName} x={x} y={y} yAxisName={yAxisName} 
            />)
    })
