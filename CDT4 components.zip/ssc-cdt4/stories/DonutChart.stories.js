import React from 'react'
import { storiesOf } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import { withKnobs, text, boolean, number, array,object } from '@storybook/addon-knobs/react'
import DonutChart from '../src/components/Chart/DonutChart'

const stories = storiesOf('Chart :: Donut', module)
stories.addDecorator(withKnobs)

const donutData= [
    { 'fund': 'U.S. Equity', 'score': 1 }, { 'fund': 'U.S Equity', 'score': 2 }, { 'fund': 'Alternatives', 'score': 3 },
    { 'fund': 'Fixed Income', 'score': 4 }, { 'fund': 'Cash Equivalent', 'score': 2 }, { 'fund': 'U.S. Equity', 'score': 6 }
  ]

  stories.add('without data', () => (
        <DonutChart width={250} height={220}  x={'fund'} y={'score'} />
    ))
    .add('with data', () => (
        <DonutChart data = {donutData} width={250} height={220}  x={'fund'} y={'score'} />
    ))
    .add('with dynamic variables', () => {
        const data = object('data', donutData)
        const width= number('width',250)
        const height= number('height',220)
        const legendX = number('legendX', 200)
        const legendY = number('legendY', 300)
        const legendTitle = text('legendTitle', 'Total')
        const x = text('x', 'fund')
        const y = text('y', 'score')
        const innerRadius = number('innerRadius', 60)
        return (<DonutChart data = {data} width={width} height={height} 
            legendX={legendX} legendTitle = {legendTitle} x={x} y={y} legendY={legendY} innerRadius={innerRadius}
            />)
    })
