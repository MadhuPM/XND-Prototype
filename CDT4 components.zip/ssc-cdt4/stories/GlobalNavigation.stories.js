import React from "react";
import { storiesOf } from "@storybook/react";
import { action } from "@storybook/addon-actions";

import { BrowserRouter as Router, Route } from "react-router-dom";

import GlobalNavigation from "../src/components/GlobalNavigation";

storiesOf("GlobalNavigation", module)
  .add("GlobalNavigation inside Router", () => (
    <Router>
      <GlobalNavigation productName="Story" />
    </Router>
  ))
  .add("GlobalNavigation outside of Router", () => (
    <GlobalNavigation productName="No Router" logoLink={<a href="#" />} />
  ));
