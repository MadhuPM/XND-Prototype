import React from "react";
import { storiesOf } from "@storybook/react";
import { action } from "@storybook/addon-actions";

import { BrowserRouter as Router, Route } from "react-router-dom";

import Logo from "../src/components/Logo";
import "../style/design2.less";

const outerStyles = { background: "#092e5d", height: 50 };

storiesOf("Logo", module)
  .add("Logo with logoLink string", () => (
    <Router>
      <div style={outerStyles}>
        <Logo productName="Product Name" logoLink="http://google.com" />
      </div>
    </Router>
  ))
  .add("Logo with logoLink element", () => (
    <div style={outerStyles}>
      <Logo productName="Product Name" logoLink={<a href="#" />} />
    </div>
  ))
  .add("Logo with logoLink component", () => (
    <div style={outerStyles}>
      <Logo
        productName="Product Name"
        logoLink={props => <a href="#" {...props} />}
      />
    </div>
  ));
