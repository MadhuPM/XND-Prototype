import React from 'react'
import { storiesOf } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import { withKnobs, text, boolean, number, array, object, select } from '@storybook/addon-knobs/react'
import Accordion from '../src/components/Accordion'
import Panel from '../src/components/Accordion/Panel'
import style from '../style/design2.less'

const stories = storiesOf('Accordion', module)
stories.addDecorator(withKnobs)
stories.add('with dynamic variables', () => {
    const bsClass = text('bsClass', 'panel-group')
    const accordion = boolean('accordion', false)
    const activeKey = number('activeKey', 2)
    const defaultActiveKey = number('defaultActiveKey', 1)
    return (
        <Accordion
          onSelect={action(' Accordian Header Selected')}
        >
        <Panel header={<span className="heading">Accordion Title</span>} eventKey="1">
          <br />
          <br />Content 1
          <br />
          <br />
        </Panel>
        <Panel header="Accordion Title" eventKey="2">
          <br />
          <br />Content 2
          <br />
          <br />
        </Panel>
        <Panel header="Accordion Title" eventKey="3">
          <br />
          <br />Content 3
          <br />
          <br />
        </Panel>
      </Accordion>
      )
})

