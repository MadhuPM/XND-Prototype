import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import moment from 'moment'
import {IntlProvider} from 'react-intl'
import zhCN from '../src/components/DatePicker/locale/zh-CN.js'
import en from '../src/components/DatePicker/locale/en.js'
import {DatePicker, RangePicker} from '../src/components/DatePicker'
import DatePickerBase from '../src/components/DatePicker/DatePicker'

const now = moment()
/*global Feature, Scenario, Given, When, Then*/
Feature('DatePicker Component', function() {
  Scenario('DatePicker Component Actions', function() {
    Given('Test For Each DatePicker Action', function() {
    }) 
    When('Component Should Mount', function() {
      this.wrapper1 = mount(
        <IntlProvider locale="en">
          <DatePicker/>
        </IntlProvider>
      )      
    })
    Then('Check default DatePicker type in intl "en"', function() {
      expect(this.wrapper1.find("input").at(0).hasClass('design2-datepicker design2-input')).to.equal(true)
    })
  })
  Scenario('DatePicker Component props', function() {
    Given('Test For Each DatePicker Action', function() {
    }) 
    When('Component Should Mount locale "zh-CN"', function() {
      this.onChange = sinon.spy()
      this.wrapper2 = mount(
        <IntlProvider locale="en">
          <DatePicker onChange={this.onChange} locale={zhCN} defaultValue={now}/>
        </IntlProvider>
      )      
    })
    Then('input value equals defaultValue', function() {
      let format = en.dateFormat
      expect(this.wrapper2.find("input").get(0).props.value).equal(now.format(format))
    })
    Then('Check input click, show popup calendar', function() {
      this.wrapper2.find("input").simulate('click')
      expect(this.wrapper2.find('.rc-calendar-selected-day>div.rc-calendar-date').get(0))
    })
    Then('select calendar date, call onchange function', function() {
      this.wrapper2.find('.rc-calendar-selected-day>div.rc-calendar-date').simulate('click')
      expect(this.onChange.calledOnce).to.equal(true)
    })
  })

  Scenario('DatePicker Component user input', function() {
    Given('Test For Each DatePicker Action', function() {
    }) 
    When('Component Should Mount', function() {
      this.wrapper3 = mount(
        <IntlProvider locale="en">
          <DatePicker locale={zhCN} value={now}/>
        </IntlProvider>
      )      
    })
    Then('DatePicker input change', function() {
      // let format = "YYYY年M月D日"
      let input = this.wrapper3.find("input.design2-input").at(0)
      input.simulate('change', {target: {value: '2011年1月1日'}})
      // expect(this.wrapper2.find("input").get(0).props.value).equal(now.format(format))
    })
  })

  Scenario('DatePicker Component click outside hidden', function() {
    Given('Test For Each DatePicker Action', function() {
    }) 
    When('Component Should Mount', function() {
      this.wrapper4 = mount(
        <IntlProvider locale="en">
          <DatePicker/>
        </IntlProvider>
      )      
    })
    Then('DatePicker click outside', function() {
      let icon = this.wrapper4.find('.design2-input-icon-right')
      icon.simulate('click')
      expect(this.wrapper4.find('.rc-calendar-selected-day>div.rc-calendar-date').get(0))
      icon.simulate('click')
      expect(this.wrapper4.find('.rc-calendar-selected-day>div.rc-calendar-date').length).equal(0)
    })
  })

  Scenario('DatePicker Component setState', function() {
    Given('Test For Each DatePicker Action', function() {
    }) 
    When('Component Should Mount', function() {
      this.wrapper5 = mount(
          <DatePickerBase locale={zhCN} value={now}/>
      )      
    })
    Then('DatePicker set null', function() {
      this.wrapper5.setState({ value: null });
      expect(this.wrapper5.find("input").get(0).props.value).equal('')
    })
  })
})
