import React, { Component } from 'react'
import chai, { expect, assert } from 'chai'
import sinon from 'sinon'
import { render, shallow, mount } from 'enzyme'
import TestUtils from 'react-dom/test-utils'
import ReactDOM from 'react-dom'
import { IntlProvider } from 'react-intl'
import DataGrid from '../src/components/DataGrid/DataGrid'
import Header from '../src/components/DataGrid/Header'
import Scrollbars from 'react-custom-scrollbars'
import { MenuItem, SubMenu } from '../src/components/Menu'
import DraggableHeaderCell from '../src/components/DataGrid/DraggableHeaderCell'
import ReactIntlBaseFormats from './ReactIntlBaseFormats'
import { DragDropContext } from 'react-dnd'
// import { wrapInTestContext } from './intl-test'

import TestBackend from 'react-dnd-test-backend'

// function wrapInTestContext(DecoratedComponent) {
//     @DragDropContext(TestBackend)
//     class TestContextContainer extends Component {
//       render() {
//         return (<IntlProvider locale="en" formats={ReactIntlBaseFormats}>
//                     <DecoratedComponent {...this.props} />
//                 </IntlProvider>)
//       }
//     }

//     return TestContextContainer
// }
// import "./searchInput.test.js"
const IntlDragDropWrapper = DragDropContext(TestBackend)(IntlProvider)

const fundColConfig = [
    {
        dataKey: 'ASSET',
        label: 'Asset',
        width: 180,
        dataType: 'string',
        locked: true,
        toolTip: 'Is the UBO a PEP? If yes,'
    }, {
        dataKey: 'MANAGER',
        label: 'Manager',
        width: 140,
        dataType: 'string',
        group: true
    }, {
        dataKey: 'FUND',
        label: 'Fund',
        width: 80,
        dataType: 'string',
        group: true
    }, {
        dataKey: 'UNITS',
        label: 'Units',
        width: 80,
        dataType: 'number',
        align: 'right'
    }, {
        dataKey: 'PRICE',
        label: 'Price',
        width: 100,
        dataType: 'number',
        numberFormat: 'currency',
        align: 'right'
    }, {
        dataKey: 'COST',
        label: 'Total Market Value',
        width: 180,
        dataType: 'number',
        numberFormat: 'currency',
        align: 'right'
    }, {
        dataKey: 'DATE',
        label: 'Date',
        width: 100,
        dataType: 'date',
        dateFormat: 'YYYY-MM-DD',
        align: 'left'
    }, {
        dataKey: 'DATE_TIME',
        label: 'Date + Time',
        width: 180,
        dataType: 'datetime',
        dateFormat: 'YYYYMMDD HH:mm:ss',
        align: 'left'
    }, {
        dataKey: 'ID',
        label: 'ID',
        width: 60,
        dataType: 'number',
        numberFormat: 'id'
    }
]
const data = [
    { "priorityType": "none", "ID": 1, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "CLGX", "UNITS": 537.0, "PRICE": 292.0762272250006, "COST": 156844.9340198253, "DATE": new Date('2017-10-10'), "DATE_TIME": new Date("2017-10-18T10:23:50"), "HAS_CHILDREN": 1 },
    { "priorityType": "high", "ID": 2, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "KE", "UNITS": 521.0, "PRICE": 307.18662394261725, "COST": 160044.2310741036, "DATE": new Date('2017-10-11'), "DATE_TIME": new Date("2017-10-18T10:23:50"), "HAS_CHILDREN": 1 },
    { "priorityType": "medium", "ID": 3, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "AIXG", "UNITS": 296.0, "PRICE": 164.20752344196708, "COST": 48605.42693882226, "DATE": new Date('2017-10-12'), "DATE_TIME": new Date("2017-10-18T10:23:50"), "HAS_CHILDREN": 1 },
    { "priorityType": "high", "ID": 4, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "AFOP", "UNITS": 53.0, "PRICE": 351.6374260235813, "COST": 18636.78357924981, "DATE": new Date('2017-10-13'), "DATE_TIME": new Date("2017-10-18T10:23:50"), "HAS_CHILDREN": 1 },
    { "priorityType": "medium", "ID": 5, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "CHKP", "UNITS": 363.0, "PRICE": 395.92090457520794, "COST": 143719.28836080048, "DATE": new Date('2017-10-14'), "DATE_TIME": new Date("2017-10-18T10:23:50"), "HAS_CHILDREN": 1 },
    { "priorityType": "high", "ID": 6, "FUND": "FUND0", "MANAGER": "Buchanan", "ASSET": "SAIC", "UNITS": 757.0, "PRICE": 479.8066271555781, "COST": 363213.6167567726, "DATE": new Date('2017-10-15'), "DATE_TIME": new Date("2017-10-18T10:23:50"), "HAS_CHILDREN": 1 }
]
const editTreeCols = [
    {
        dataKey: 'id',
        label: 'Id',
        width: 70,
        dataType: 'number',
        hidden: true
    },
    {
        dataKey: 'parentId',
        label: 'Parentid',
        width: 70,
        dataType: 'number',
        hidden: true
    },
    {
        dataKey: 'itemType',
        label: 'Itemtype',
        width: 70,
        dataType: 'number',
        hidden: true
    },
    {
        dataKey: 'name',
        label: 'Name',
        width: 200,
        dataType: 'string',
        edit: true
    },
    {
        dataKey: 'description',
        label: 'Description',
        width: 200,
        dataType: 'string',
        edit: true
    },
    {
        dataKey: 'inception',
        label: 'Inception Date',
        width: "*",
        dataType: 'date',
        edit: true
    }]

const treeData = [
    { "priorityType": "high", "id": 1, "appcode": "CLOTRG00259", "active": 1, "itemType": 0, "name": "Fund Category One", "description": "A category", "inception": "20161018", "__errorMsg": "{\"errors\":[],\"success\":true}" },
    { "priorityType": "none", "id": 4, "parentId": 1, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Another Child", "description": "More descriptions", "inception": "20161011" },
    { "priorityType": "medium", "id": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 0, "name": "Fund Category Two", "description": "Here is description", "inception": "20161018" },
    { "priorityType": "high", "id": 12, "parentId": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Cat two Child", "description": "description", "inception": "20161011" },
    { "priorityType": "medium", "id": 14, "parentId": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Category two third child", "description": "Now a description", "inception": "20161123" },
    { "priorityType": "medium", "id": 15, "parentId": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Child to Fund", "description": "ddd", "inception": "20161209" },
    { "priorityType": "none", "id": 16, "appcode": "CLOTRG00259", "active": 1, "itemType": 0, "name": "Top Category", "description": "Long description", "inception": "20161215" },
    { "priorityType": "none", "id": 17, "parentId": 16, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Child of top category", "description": "again a description", "inception": "20161215" },
    { "priorityType": "none", "id": 18, "parentId": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "cdcd", "description": "cdcd", "inception": "20171025" }
]
let should = chai.should()
/*global Feature, Scenario, Given, When, Then*/
Feature('Data Grid Component', function () {
    Scenario('Datagrid element presents ', function () {
        Given('DataGrid config is set', function () {

            this.menu = [
                <MenuItem key="1">Parent 1</MenuItem>,
                <MenuItem key="333" divider />,
                (<SubMenu key='2' title="Parent 2" >
                    <MenuItem key='3'>Child 1</MenuItem>
                    <MenuItem key='4'>Child 2</MenuItem>
                    <SubMenu key='5' title="Child 3">
                        <MenuItem key='6'>GrandChild 1</MenuItem>
                    </SubMenu>
                </SubMenu>)
            ]
            this.onSortFilter = function () { }
            this.onClickedChange = function () { }
            this.onStateChange = function () { }
            this.onCheckedChange = function () { }
            this.onRowDoubleClick = function () { }
            this.onDragDrop = function () { }
            this.onRowExpand = function () { }
            this.rowHeight = function (row) {
                if (row.ID == 1) return 100
                if (row.ID == 2) return 100
                return 50
            }
            // this.filter =[{ value: '', dataKey: "ASSET", operator: 'CONTAINS' }]
        })

        When('Data Grid is mounted ', function () {

            this.wrapperDatagrid = mount(
                <div>
                    <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                        <DataGrid
                            rowHeight={this.rowHeight}
                            keyFieldName="ID"
                            data={data}
                            columns={fundColConfig}
                            hasCheckbox
                            hasPriority
                            hasOverflowMenu
                            overflowMenu={this.menu}
                            title="datagrid"
                        />
                    </IntlDragDropWrapper>
                </div>
            )

        })

        Then('Check the DataGrid title bar and data', function () {
            expect(this.wrapperDatagrid.find('.tableTitle').text()).to.equals('datagrid')

            expect(this.wrapperDatagrid.find('.dataGridHeader').text()).to.equals('Asset Manager Fund Units Price Total Market Value Date Date + Time ID ')

            expect(this.wrapperDatagrid.find('.DataGridOverflowMenu').length).to.equals(1)
            //test last row data
            expect(this.wrapperDatagrid.find('.dataGridColumnContainer').not('.dataGridFixed').children()
                .last().text()).equals('SAICBuchananFUND0757479.81363,213.622017-10-1520171018 18:23:506')

        })
        Then('Check click the header sort', function () {


            this.wrapperDatagrid.find('.dataGridHeader').childAt(0).find('.dataGridCellHeaderText').simulate('click')
            expect(this.wrapperDatagrid.find('.dropdownMenuListBox').length).to.equals(1)

            let overlayItem = this.wrapperDatagrid.find(MenuItem)
            let sortAsc = overlayItem.at(0)
            let sortDec = overlayItem.at(1)
            expect(sortDec.text()).to.equals('Sort Column Z to A')
            //if simulate(key) not available, using prop(key)()
            sortDec.prop('onSelect')()

            expect(this.wrapperDatagrid.find('.dataGridColumnContainer').not('.dataGridFixed').children()
                .last().text()).equals('AFOPAlvarezFUND053351.6418,636.782017-10-1320171018 18:23:504')

            sortAsc.prop('onSelect')()
            expect(this.wrapperDatagrid.find('.dataGridColumnContainer').not('.dataGridFixed').children()
                .last().text()).equals('SAICBuchananFUND0757479.81363,213.622017-10-1520171018 18:23:506')
        })
        Then('Check click the header freeze', function () {

            let overlayItem = this.wrapperDatagrid.find(MenuItem)
            let freeze = overlayItem.at(3)
            expect(freeze.text()).to.equals('Freeze')

            freeze.prop('onSelect')()
            // console.log(this.wrapperDatagrid.find('.dataGridHeaderFixed').text())
            // console.log(this.wrapperDatagrid.find('.dataGridHeaderFixed').html())

            // expect(freeze.text()).to.equals('Unfreeze')
            expect(this.wrapperDatagrid.find('.dataGridHeaderFixed').text()).to.equals('Asset ')

            this.wrapperDatagrid.find('.dataGridHeader').childAt(0).find('.dataGridCellHeaderText').simulate('click')
            this.wrapperDatagrid.find(MenuItem).at(3).prop('onSelect')()
            expect(this.wrapperDatagrid.find('.dataGridHeaderFixed').text()).to.equals('Asset Manager ')
        })
        Then('Check click the header Auto-resize Column', function () {

            let overlayItem = this.wrapperDatagrid.find(MenuItem)
            let autoResizeMenu = overlayItem.at(4)
            expect(autoResizeMenu.text()).to.equals("Auto-resize Column")

            autoResizeMenu.prop('onSelect')()
            // console.log(this.wrapperDatagrid.find(Header).at(2).prop('col').width)
        })
        Then('Check click the header Columns', function () {

            let overlayItem = this.wrapperDatagrid.find(SubMenu)
            let columns = overlayItem.at(0)
            // expect(columns.find(MenuItem).length).to.equals(10)

            // columns.prop('onSelect')()
            // console.log(columns.html())
        })
        Then('Check tree table', function () {
            const wrapperDatagrid = mount(
                <div>
                    <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                        <DataGrid
                            keyFieldName="id"
                            parentFieldName="parentId"
                            data={treeData}
                            columns={editTreeCols}
                            defaultExpansionLevel={10}
                        />
                    </IntlDragDropWrapper>
                </div>
            )
            let parent = wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-0')
            let child = wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-1')
            expect(child.length).to.equals(6)

            // close
            wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-0').at(0).find('.dataGridCustomCellWrapper').simulate('click')
            expect(wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-1').length).to.equals(5)
            wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-0').at(1).find('.dataGridCustomCellWrapper').simulate('click')
            expect(wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-1').length).to.equals(1)

            //open
            wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-0').at(0).find('.dataGridCustomCellWrapper').simulate('click')
            expect(wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-1').length).to.equals(2)
            wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-0').at(1).find('.dataGridCustomCellWrapper').simulate('click')
            expect(wrapperDatagrid.find('.dataGridColumnContainer').at(0).find('.dataGridRowLevel-1').length).to.equals(6)
        })

        Then('Check scroll', function () {
            // this.wrapperDatagrid.find(Scrollbars).setProps({ type: 'uniform' })
            this.wrapperDatagrid.find(Scrollbars).prop('onScroll')()
            // expect(this.wrapperDatagrid.find('.track-vertical').childAt(0).props().height).to.equals(1)
        })
        Then('Check click row', function () {
            this.wrapperDatagrid.find('.dataGridColumnContainer').at(1).childAt(0).simulate('mouseEnter')
            this.wrapperDatagrid.find('.dataGridColumnContainer').at(1).childAt(0).simulate('mouseLeave')
            this.wrapperDatagrid.find('.dataGridColumnContainer').at(1).childAt(0).simulate('click')
            // expect(this.wrapperDatagrid.find('.track-vertical').childAt(0).props().height).to.equals(1)
        })
        Then('Check filter', function () {
            const wrapperDatagrid2 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 'AIX', dataKey: 'ASSET', operator: 'CONTAINS' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid2.find('.dataGridColumnContainer').at(1).children().length).to.equals(1)
            expect(wrapperDatagrid2.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('AIXG')

            const wrapperDatagrid3 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 'CLGX', dataKey: 'ASSET', operator: 'EQUAL_TO' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid3.find('.dataGridColumnContainer').at(1).children().length).to.equals(1)
            expect(wrapperDatagrid3.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('CLGX')

            const wrapperDatagrid4 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 'CLGX', dataKey: 'ASSET', operator: 'NOT_EQUAL_TO' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid4.find('.dataGridColumnContainer').at(1).children().length).to.equals(5)
            expect(wrapperDatagrid4.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('KE')

            const wrapperDatagrid5 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 'CLG', dataKey: 'ASSET', operator: 'STARTS_WITH' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid5.find('.dataGridColumnContainer').at(1).children().length).to.equals(1)
            expect(wrapperDatagrid5.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('CLGX')

            const wrapperDatagrid6 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 'GX', dataKey: 'ASSET', operator: 'ENDS_WITH' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid6.find('.dataGridColumnContainer').at(1).children().length).to.equals(1)
            expect(wrapperDatagrid6.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('CLGX')

            const wrapperDatagrid7 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 5, dataKey: 'ID', operator: 'GREATER_THAN' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid7.find('.dataGridColumnContainer').at(1).children().length).to.equals(1)
            expect(wrapperDatagrid7.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('SAIC')

            const wrapperDatagrid8 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 5, dataKey: 'ID', operator: 'GREATER_THAN_OR_EQUAL_TO' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid8.find('.dataGridColumnContainer').at(1).children().length).to.equals(2)
            expect(wrapperDatagrid8.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('CHKP')

            const wrapperDatagrid9 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 2, dataKey: 'ID', operator: 'LESS_THAN' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid9.find('.dataGridColumnContainer').at(1).children().length).to.equals(1)
            expect(wrapperDatagrid9.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('CLGX')

            const wrapperDatagrid10 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 2, dataKey: 'ID', operator: 'LESS_THAN_OR_EQUAL_TO' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid10.find('.dataGridColumnContainer').at(1).children().length).to.equals(2)
            expect(wrapperDatagrid10.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('CLGX')

            const wrapperDatagrid11 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: 1,betweenValue:3, dataKey: 'ID', operator: 'BETWEEN' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid11.find('.dataGridColumnContainer').at(1).children().length).to.equals(3)
            expect(wrapperDatagrid11.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('CLGX')
            expect(wrapperDatagrid11.find('.dataGridColumnContainer').at(1).childAt(1).childAt(0).text()).to.equals('KE')
            expect(wrapperDatagrid11.find('.dataGridColumnContainer').at(1).childAt(2).childAt(0).text()).to.equals('AIXG')

            const wrapperDatagrid12 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: '', dataKey: 'ID', operator: 'EQUAL_TO_NULL' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid12.find('.dataGridColumnContainer').at(1).children().length).to.equals(0)

            const wrapperDatagrid13 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: '', dataKey: 'ID', operator: 'NOT_EQUAL_TO_NULL' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid13.find('.dataGridColumnContainer').at(1).children().length).to.equals(6)

            const wrapperDatagrid14 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: new Date("2017-10-10"), dataKey: 'DATE', operator: 'EQUAL_TO' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid14.find('.dataGridColumnContainer').at(1).children().length).to.equals(1)
            expect(wrapperDatagrid14.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('CLGX')

            const wrapperDatagrid15 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: new Date("2017-10-10"), dataKey: 'DATE', operator: 'NOT_EQUAL_TO' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid15.find('.dataGridColumnContainer').at(1).children().length).to.equals(5)
            // expect(wrapperDatagrid15.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('CLGX')

            const wrapperDatagrid16 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: new Date("2017-10-14"), dataKey: 'DATE', operator: 'GREATER_THAN' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid16.find('.dataGridColumnContainer').at(1).children().length).to.equals(1)
            expect(wrapperDatagrid16.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('SAIC')

            const wrapperDatagrid17 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: new Date("2017-10-14"), dataKey: 'DATE', operator: 'GREATER_THAN_OR_EQUAL_TO' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid17.find('.dataGridColumnContainer').at(1).children().length).to.equals(2)
            // expect(wrapperDatagrid17.find('.dataGridColumnContainer').at(1).childAt(0).childAt(0).text()).to.equals('SAIC')

            const wrapperDatagrid18 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: new Date("2017-10-11"), dataKey: 'DATE', operator: 'LESS_THAN' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid18.find('.dataGridColumnContainer').at(1).children().length).to.equals(1)

            const wrapperDatagrid19 = mount(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                        filter={[{ value: new Date("2017-10-11"), dataKey: 'DATE', operator: 'LESS_THAN_OR_EQUAL_TO' }]}
                    />
                </IntlDragDropWrapper>
            )
            expect(wrapperDatagrid19.find('.dataGridColumnContainer').at(1).children().length).to.equals(2)
        })
        Then('Check drag and drop', function () {
            const root = TestUtils.renderIntoDocument(
                <IntlDragDropWrapper locale="en" formats={ReactIntlBaseFormats}>
                    <DataGrid
                        keyFieldName="id"
                        data={data}
                        columns={fundColConfig}
                    />
                </IntlDragDropWrapper>
            )
            const backend = root.getManager().getBackend()
            const dragbox = TestUtils.scryRenderedComponentsWithType(root, DraggableHeaderCell)[2]
            // console.log(dragbox.getDecoratedComponentInstance())
            // backend.simulateBeginDrag([dragbox.getHandlerId()])

        })
    })
})
