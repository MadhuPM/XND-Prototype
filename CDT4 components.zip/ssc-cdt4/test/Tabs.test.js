import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Tabs,{Tab} from '../src/components/Tabs'
/*global Feature, Scenario, Given, When, Then*/
Feature('Tabs Component', function() {
  let instance
  Scenario('Tabs Component Actions', function() {
    Given('Test For Each Tabs Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    }) 
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Tabs defaultActiveKey="1" onSelect={this.onSelect} id="Tabtest">
            <Tab title={<span className="headering">Collapsible Group Item #1</span>} eventKey="1">123</Tab>
            <Tab title="Collapsible Group Item #2" eventKey="2">123</Tab>
            <Tab title="Collapsible Group Item #3" eventKey="3" disabled>123</Tab>
        </Tabs>
      )

      instance = this.wrapper.instance()
    })
    Then('Check defaultActiveKey item to be open', function() {
      expect(this.wrapper.find("a").at(0).prop('aria-selected')).to.equal(true)
    })
    
    Then('Check clicking an tab,change the selected tab', function() {
      this.wrapper.find('a').at(1).simulate('click')
      expect(this.wrapper.find("a").at(1).prop('aria-selected')).to.equal(true)
      expect(this.wrapper.find("a").at(0).prop('aria-selected')).to.equal(false)
      // disabled one 
      this.wrapper.find('a').at(2).simulate('click')
      expect(this.wrapper.find("a").at(2).prop('aria-selected')).to.equal(false)
    })
  })
})
