import React from 'react'
import { expect,assert} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Launchpad_, {MiniLaunchpad} from '../src/components/Launchpad'
import Tile from '../src/components/Tile'
import { DragDropContext } from 'react-dnd'
import HTML5Backend from 'react-dnd-test-backend'
const Launchpad = DragDropContext(HTML5Backend)(Launchpad_)

describe('Launchpad', () => {
  let launchpad;
  let minilaunchpad;
  beforeEach(() => {
    launchpad = mount(<Launchpad><Tile name={"test"}></Tile></Launchpad>);
    minilaunchpad = mount(<MiniLaunchpad>
      <Tile type={'mini'} name={"1"}></Tile>
      <Tile type={'mini'} name={"2"}></Tile>
      <Tile type={'mini'} name={"3"}></Tile>
      <Tile type={'mini'} name={"4"}></Tile>
      <Tile type={'mini'} name={"5"}></Tile>
      <Tile type={'mini'} name={"6"}></Tile>
      <Tile type={'mini'} name={"7"}></Tile>
    </MiniLaunchpad>);
  });

  it('works', () => {
    expect(launchpad.find('.row').children().length).to.equal(1)
  });
  
  it('launchpad have a My File Tile and a All Service Tile', () => {
    it("apply the ux Guidelines in application ",()=>{})
  });
  
  it('mini launchpad takes 6 mini tiles', () => {    
    expect(minilaunchpad.find('.design2-tile-mini').length).to.equal(6)
  });
  
  it('mini launchpad takes only mini tiles', () => {    
    const errorFunc = sinon.spy()
    try {
      mount(<MiniLaunchpad>
              <Tile name={"1"}></Tile>
            </MiniLaunchpad>)
    } catch (error) {
      errorFunc()
    }
    expect(errorFunc.calledOnce).to.equal(true)
  })
});
