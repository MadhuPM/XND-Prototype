import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Accordion,{Panel} from '../src/components/Accordion'

/*global Feature, Scenario, Given, When, Then*/
Feature('Accordion Component', function() {
  let instance
  Scenario('Accordion Component Actions', function() {
    Given('Test For Each Accordion Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    }) 
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Accordion defaultActiveKey="3" onSelect={this.onSelect}>
            <Panel header={<span className="headering">Collapsible Group Item #1</span>} eventKey="1">123</Panel>
            <Panel header="Collapsible Group Item #2" eventKey="2">123</Panel>
            <Panel header="Collapsible Group Item #3" eventKey="3">123</Panel>
        </Accordion>
      )

      instance = this.wrapper.instance()
    })
    Then('Check defaultActiveKey item to be open', function() {
      expect(this.wrapper.find("a").at(2).prop('aria-expanded')).to.equal(true)
    })
    
    Then('Check clicking an item,opened item to be close', function() {
      // const onButtonClick = sinon.spy()
      // const wrapper2 = mount((
      //   <Icon         
      //     name={ICONS.ALERT}
      //     size="12"
      //     onClick={onButtonClick} />
      // ))
      // wrapper2.find('svg').simulate('click')
      // expect(onButtonClick.calledOnce).to.equal(true)

      this.wrapper.find('a').at(1).simulate('click')
      expect(this.wrapper.find("a").at(1).prop('aria-expanded')).to.equal(true)
      expect(this.wrapper.find("a").at(2).prop('aria-expanded')).to.equal(false)
    })
  })
})
