import React, {ReactDOMServer} from 'react'
import chai, {expect, assert} from 'chai'
import sinon from 'sinon'
import {mount} from 'enzyme'
import GlobalNavigation from '../src/components/GlobalNavigation'
import {MiniLaunchpad} from '../src/components/Launchpad'
import {BrowserRouter as Router } from 'react-router-dom'
import Tile from '../src/components/Tile'
import AlertCenter from '../src/components/AlertCenter'
import GlobalSearch from '../src/components/GlobalNavigation/GlobalSearch'
/*global Feature, Scenario, Given, When, Then*/
Feature('Global Navigation Component', function () {
  Scenario('Global Navigation Component ', function () {
    let profileMenu = new Array
    // let logo = new Object
    function onClickMore() {
      console.log("More clicked")
    }
    function onSelect(eventKey, event) {
      event.preventDefault()
      console.log(eventKey)
    }
    function alertCenterChange(alerts, notifications) {
      event.preventDefault()
      console.log(alerts)
    }
    const alerts=[
      {title:'Alerts title1',time: 1514264860677,isRead: false,id: 1},
      {title:'Alerts title2',time: 1514363860677,isRead: true,id: 2},
      {title:'Alerts title3',time: 1514341960677,isRead: true,id: 3},
      {title:'Alerts title4',time: 1514264860677,isRead: false,id: 12},
      {title:'Alerts title5',time: 1514363860677,isRead: true,id: 13},
      {title:'Alerts title6',time: 1514341960677,isRead: true,id: 14},
      {title:'Alerts title7',time: 1514264860677,isRead: false,id: 15},
      {title:'Alerts title8',time: 1514363860677,isRead: true,id: 16}]
    const notifications=[
      {title:'notifies title1',time: 1514364860677,isRead: false,id: 4},
      {title:'notifies title2',time: 1514364860676,isRead: false,id: 5},
      {title:'notifies title3',time: 1514364860675,isRead: false,id: 6},
      {title:'notifies title4',time: 1514364860674,isRead: true,id: 7},
      {title:'notifies title5',time: 1514364860673,isRead: false,id: 8},
      {title:'notifies title6',time: 1514364860672,isRead: false,id: 9},
      {title:'notifies title7',time: 1514364860671,isRead: false,id: 10},
      {title:'notifies title8',time: 1514364860670,isRead: true,id: 11}]
    const searchData = [
      {
        label: '123',
        value: 'a'
      }, {
        label: '234',
        value: 'b'
      }, {
        label: '456',
        value: 'c'
      }, {
        label: '567',
        value: 'd'
      }, {
        label: '456r',
        value: 'c'
      }, {
        label: '567',
        value: 'e'
      }, {
        label: '456h',
        value: 'c'
      }, {
        label: '567d',
        value: 'f'
      }, {
        label: '456a',
        value: 'g'
      }, {
        label: '567s',
        value: 'h'
      }
    ]
    Given('required props for Header to be loaded', function () {

      profileMenu = [
        {
          id: 0,
          label: 'My Account'
        }, {
          id: 1,
          label: 'Settings'
        }, {
          id: 2,
          label: 'Help'
        }, {
          id: 3,
          label: 'Client View'
        }, {
          id: 4,
          label: 'Log Out'
        }
      ]
      let launchpad = [ < Tile name = "Product Name1" key = {
          1
        }
        type = "mini" />, < Tile name = "Product Name2" key = {
          2
        }
        type = "mini" />, < Tile name = "Product Name3" key = {
          3
        }
        type = "mini" />, < Tile name = "Product Name4" key = {
          4
        }
        type = "mini" />, < Tile name = "Product Name5" key = {
          5
        }
        type = "mini" />, < Tile name = "Product Name6" key = {
          6
        }
        type = "mini" />
      ]
      const data = [
        {
          name: "userName",
          type: "string",
          defaultValue: "",
          desc: "the name of user"
        }, {
          name: "productName",
          type: "string",
          defaultValue: "",
          desc: "the product name"
        }, {
          name: "profileMenu",
          type: "array",
          defaultValue: "",
          desc: "an array to set Profile Menu"
        }, {
          name: "onSelect",
          type: "function(label:any,event:object)",
          defaultValue: "",
          desc: "callback when select a item of Profile Menu"
        }
      ];
      const data1 = [
        {
          name: "label",
          type: "string",
          defaultValue: "",
          desc: "the name of link"
        }, {
          name: "link",
          type: "string",
          defaultValue: "",
          desc: "the link to turn"
        }
      ];
    })

    When('the Component is Mounted on the Virtual DOM', function () {
      this.wrapper = mount(
        <Router>
        <GlobalNavigation
          profileMenu={profileMenu}
          userName="State Street"
          productName="Product Name"
          position='relative'
          onSelect={onSelect}
        >
          <MiniLaunchpad onClick={onClickMore}>
            <Tile name="Product Name1" key={1} type="mini"/>
            <Tile name="Product Name2" key={2} type="mini"/>
            <Tile name="Product Name3" key={3} type="mini"/>
            <Tile name="Product Name4" key={4} type="mini"/>
            <Tile name="Product Name5" key={5} type="mini"/>
            <Tile name="Fund Administration" key={6} type="mini"/>
          </MiniLaunchpad>
          <GlobalSearch data={searchData}/>
          <AlertCenter
            alerts={alerts}
            notifications={notifications}
            onChange={alertCenterChange}/>
        </GlobalNavigation>
        </Router>
      )
    })

    Then('Check For profileMenu', function () {
      expect(this.wrapper.find('GlobalNavigation').props().profileMenu).to.be.a('array')
      expect(this.wrapper.find('GlobalNavigation').props().profileMenu).to.be.deep.equal(profileMenu)
    })
    Then('Check For userName', function () {
      expect(this.wrapper.find('GlobalNavigation').props().userName).to.be.a('string')
      expect(this.wrapper.find('GlobalNavigation').props().userName)
        .to
        .equal('State Street')
    })
    Then('Check For productName', function () {
      expect(this.wrapper.find('GlobalNavigation').props().productName).to.be.a('string')
      expect(this.wrapper.find('GlobalNavigation').props().productName)
        .to
        .equal('Product Name')
    })
    Then('Check For logo Image', function () {
      expect(this.wrapper.find('GlobalNavigation').props().logo).to.not.equal(null)
    })
    Then('check for onToggleLink and  resetActive', function () {
      this.wrapper.find('GlobalNavigation').find('.searchLink').simulate('click')
      // expect(this.wrapper.find('GlobalNavigation').state().activeLink).to.equal('search') 
      this.wrapper.find('.profileMenu').at(0).simulate('click')
      this.wrapper.find('.dropdown-menu a').at(0).simulate('click')
      // expect(this.wrapper.state().activeLink).to.equal('launchpad')
      // this.wrapper.find('.alertLink').simulate('click')
      // expect(this.wrapper.state().activeLink).to.equal('alert')
      this
        .wrapper
        .find('#profileMenu').at(0)
        .simulate('click')
      // expect(this.wrapper.find('GlobalNavigation').state().activeLink).to.equal('')
    })
    Then('Check For greeting word', function () {
      let time = new Date()
      time.setHours(14)
      let clock = sinon.useFakeTimers(time.getTime())
      let greetingWrapper = mount(<Router><GlobalNavigation
        profileMenu={profileMenu}
        userName="State Street"
        productName="Product Name"/></Router>)
      // expect(greetingWrapper.find('GlobalNavigation').state().greeting).to.equal('Good afternoon')
      time.setHours(20)
      clock = sinon.useFakeTimers(time.getTime())
      let greetingWrapper1 = mount(<Router><GlobalNavigation
        profileMenu={profileMenu}
        userName="State Street"
        productName="Product Name"/></Router>)
      // expect(greetingWrapper1.find('GlobalNavigation').state().greeting).to.equal('Good evening')
    })
  })
})
