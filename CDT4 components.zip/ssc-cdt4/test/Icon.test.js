import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Icon,{ICONS} from '../src/components/Icon'

/*global Feature, Scenario, Given, When, Then*/
Feature('Icon Component', function() {
  Scenario('Icon Component Actions', function() {
    Given('Test For Each Icon Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    }) 
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Icon         
          name={ICONS.ALERT}
          size="12"
          onClick={this.handleClick} />
      )

    })
    Then('Check name to be a string', function() {
      expect(this.wrapper.props().name).to.be.a('String')
			expect(this.wrapper.props().name).to.equal("alert")
    })
    Then('Check size to be a string', function() {
      expect(this.wrapper.props().size).to.be.a('String')
			expect(this.wrapper.props().size).to.equal("12")
    })
    Then('Check onClick to be a function', function() {
      expect(this.wrapper.props().onClick).to.be.a('function')
			expect(this.wrapper.props().onClick).to.equal(this.handleClick)
    })
    Then('Check clicking an Icon', function() {
      const onButtonClick = sinon.spy()
      const wrapper2 = mount((
        <Icon         
          name={ICONS.ALERT}
          size="12"
          onClick={onButtonClick} />
      ))
      wrapper2.find('svg').simulate('click')
      expect(onButtonClick.calledOnce).to.equal(true)
    })
  })
})
