import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Loading from '../src/components/Loading'

describe('Loading', () => {
  let loading
  let loading1
  beforeEach(() => {
    loading = mount(<Loading />)
    loading1 = mount(<Loading loaded/>)
  })

  it('works', () => {
    expect(loading.find('.loading-animation').length).to.equal(1)
  })
  it('loading with prop loaded will return null', () => {
    expect(loading1.find('.loading-animation').length).to.equal(0)
  })
})
