import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Button,{CardButton} from '../src/components/Button'
import Icon,{ICONS} from '../src/components/Icon'

/*global Feature, Scenario, Given, When, Then*/
Feature('Button Component', function() {
 
  Scenario('Button Component Actions', function() {
    Given('Test For Each Button Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    }) 
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Button onClick={this.handleClick}>Create</Button>
      )
      this.wrapper1 = mount(
        <Button bsStyle="primary" disabled onClick={this.handleClick}>Create</Button>
      )
      this.wrapper2 = mount(
        <CardButton onClick={this.handleClick}>
            <Icon name={ICONS.ALERT_CIRCLE}  size="30" color="#fff" />
            Create
        </CardButton>
      )
      
    })
    Then('Check default button type', function() {
      expect(this.wrapper.find("button").at(0).hasClass('design2-button-default')).to.equal(true)
    })
    Then('Check primary button type and disabled', function() {
      expect(this.wrapper1.find("button").at(0).hasClass('design2-button-primary')).to.equal(true)
      expect(this.wrapper1.find("button").at(0).prop('disabled')).to.equal(true)
    })
    Then('Check click a button', function() {
      const onButtonClick = sinon.spy()
      const wrapper3 = mount((
        <Button onClick={onButtonClick}>Create</Button>
      ))
      wrapper3.find('button').at(0).simulate('click')
      expect(onButtonClick.calledOnce).to.equal(true)
    })
    Then('Check card-button', function() {
      expect(this.wrapper2.find("button").at(0).hasClass('card-button')).to.equal(true)
      expect(this.wrapper2.find("svg")).to.have.length(1)
    })
  })
})
