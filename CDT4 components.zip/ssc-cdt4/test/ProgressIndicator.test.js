import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import ProgressIndicator from '../src/components/ProgressIndicator'
/*global Feature, Scenario, Given, When, Then*/
Feature('Progress Indicator Component', function() {
  let instance
  Scenario('Progress Indicator Component Actions', function() {
    Given('Test For Each Tabs Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
      this.list = ['Progress Title 1', 'Progress Title 2', 'Progress Title 3', 'Progress Title 4', 'Progress Title 5']
          }) 
    When('Component Should Mount', function() {
      this.wrapper = mount(
    <ProgressIndicator list={this.list} step={1}></ProgressIndicator>
      )

      instance = this.wrapper.instance()
    })
    Then('Check defaultActiveKey item to be open', function() {
      expect(this.wrapper.find(".design2-indicator span").at(0).hasClass('finished-step')).to.equal(true)
    })

  })
})
