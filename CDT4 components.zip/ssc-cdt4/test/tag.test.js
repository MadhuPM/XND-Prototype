import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Tag,{InputTag} from '../src/components/Tag'

/*global Feature, Scenario, Given, When, Then*/
Feature('Tag Component', function() {
 
  Scenario('Tag Component Actions', function() {
    Given('Test For Each Tag Action', function() {
      this.onAdd = (i) => {
        // callback goes here
      }
      this.onDelete = (i) => {
        // callback goes here
      }
    })
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Tag label="High Priority" type="high" />
      )
      // this.wrapper1 = mount(
      //   <InputTag tags={["Fund Name", "Time"]} onDelete={this.onDelete} onAdd={this.onAdd} />
      // )
      
    })
    Then('Check default tag type', function() {
      expect(this.wrapper.find(".design2-tag").children()).to.have.length(2)
    })
    Then('Check click a close icon', function() {
      const onButtonClick = sinon.spy()
      const wrapper2 = mount((
        <Tag label="High Priority" type="high" onDelete={onButtonClick} />
      ))
      wrapper2.find('svg').at(0).simulate('click')
      expect(onButtonClick.calledOnce).to.equal(true)
    })
    // Then('Check InputTag to add a tag', function() {
    //     const onButtonClick = sinon.spy()
    //     const wrapper3 = mount((
    //         <InputTag tags={["Fund Name", "Time"]} onDelete={this.onDelete} onAdd={onButtonClick} />
    //     ))
    //   wrapper3.find('.design2-inputTag input').at(0).node.value='tag'
    //   wrapper3.find('.design2-inputTag input').at(0).simulate('keyPress',{key:'Enter',keyCode: 13, which: 13 })
    //   expect(onButtonClick.calledOnce).to.equal(true)
    //   expect(wrapper3.find(".design2-inputTag").children()).to.have.length(4)
    //   wrapper3.find('svg').at(0).simulate('click')
    //   expect(wrapper3.find(".design2-inputTag").children()).to.have.length(3)
    // })
  })
})
