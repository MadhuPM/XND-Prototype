import React, {ReactDOMServer} from 'react'
import chai, {expect,assert} from 'chai'
import sinon from 'sinon'
import {mount} from 'enzyme'
import {BrowserRouter as Router } from 'react-router-dom'
import SecondaryNavigation from '../src/components/SecondaryNavigation'
const navData = [
    {
		key: '1',
		title:'GrandParent1',
		children:[{
			key: '2',
			title:'Parent1',
			link:'x',
			children:[{
				key: '3',
				title:'Child1'
			}]
		},{
			key: '4',
			title:'Parent2',
			children:[{
				key: '5',
				title:'Child2'
			}]
		}]
    },{
		key: '6',
		title:'GrandParent2'
    },{
		key: '7',
		title:'GrandParent3'
    },{
		key: '8',
		title:'GrandParent4'
    }
]
function selectConsole(){

}
/*global Feature, Scenario, Given, When, Then*/
Feature('Secondary Navigation Component', function() {
  Scenario('Secondary Navigation Component ', function() {
    When('the Component is Mounted on the Virtual DOM', function() {
      this.wrapper = mount(
					<Router><SecondaryNavigation data={navData} defaultSelectedKey='3' autoLink={false} onSelect={selectConsole}>content</SecondaryNavigation></Router>   
      ) 
      this.wrapper1 = mount(
          <Router>
            <SecondaryNavigation data={navData}defaultSelectedKey='3'>content</SecondaryNavigation>
          </Router>    
      )  
      this.wrapper2 = mount(
        <Router>
					<SecondaryNavigation data={navData} defaultSelectedKey='3' sideNavMode="push">content</SecondaryNavigation>  
        </Router>   
      )                
    })
     Then('Check For open and close the side Nav', function() {
      this.wrapper.find('svg').simulate('click')
      expect(this.wrapper.find('.tree-nav-container').prop('style').width).to.equal('235px')
      expect(this.wrapper.find('.design2-breadcrumb').prop('style').display).to.equal('none')
      this.wrapper.find('svg').simulate('click')
      expect(this.wrapper.find('.tree-nav-container').prop('style').width).to.equal('0px')
      this.wrapper2.find('svg').simulate('click')
      expect(this.wrapper2.find('.tree-content-container').prop('style').paddingLeft).to.equal('235px')

    })
     Then('Check For click the Breadcrumbs Link', function() {
      // expect(this.wrapper.state('breadcrumbArray').length).to.equal(3) 
      this.wrapper.find('.BreadcrumbsLink1').simulate('click')
      // expect(this.wrapper.state('breadcrumbArray').length).to.equal(2)
    })
     Then('Check For click Menu Item and Sub Menu with or without link', function() {
      this.wrapper.find('.MenuItem').at(4).simulate('click')
      // expect(this.wrapper.state('selectedKey')).to.equal('8')
      this.wrapper.find('.MenuItem').at(1).simulate('click')
      // expect(this.wrapper.state('openKeys').length).to.equal(2)
      this.wrapper.find('.subMenuTitle').at(1).simulate('click')
      // expect(this.wrapper.state('selectedKey')).to.equal('2')
    })
  })
})
