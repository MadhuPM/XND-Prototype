import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import yup from 'yup'
import sinon from 'sinon'
import ReactDOM from 'react-dom'

const selectOptions=[{value:'option 1',label:'Option 1'},{value:'option 2',label:'Option 2'},{value:'option 3',label:'Option 3'}]
const selectOptions1=[{value:'option 1',label:'Option 1'},{value:'option 2',label:'Option 2'},{value:'option 3',label:'Option 3'},{value:'option 4',label:'Option 4'}]
import Sorting from '../src/components/Sorting'

const onChange=(e)=>{
  console.log(e)
}

/*global Feature, Scenario, Given, When, Then*/
Feature('Sorting Component', function() {
 
  Scenario('Sorting Component Actions', function() {
    Given('Test For Each Sorting Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    }) 
    When('Component Should Mount', function() {
      this.wrapper = mount(
          <Sorting
                      onChange={onChange}
                      options={selectOptions}
                    />
      )
      this.wrapper1 = mount(
        <Sorting
                    onChange={onChange}
                    options={selectOptions1}
                  />
      )
    })
    Then('Check Sorting select', function() {

      // this.wrapper.find('.Select-input input')
      // .simulate('focus')

      this.wrapper.find('.design2-sorting-option input').at(1)
      .simulate('change',{target:{checked:true}})
      this.wrapper1.find('VirtualizedSelect').simulate('change')
    })
  })
})
