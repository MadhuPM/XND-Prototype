import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Tooltip from '../src/components/Tooltip'

/*global Feature, Scenario, Given, When, Then*/
Feature('ToolTip Component', function() {
 
  Scenario('ToolTip Component Actions', function() {
    Given('Test For Each ToolTip Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    })
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Tooltip placement="right" id="tooltip-right" positionTop="50px" positionLeft="50px">
            ToolTip right
        </Tooltip>
      )
    })
    Then('Check tool-tip placement type', function() {
      expect(this.wrapper.find("div").at(0).hasClass('right')).to.equal(true)
    })
    Then('Check tool-tip id props', function() {
      expect(this.wrapper.find("div").at(0).prop('id')).to.equal('tooltip-right')
    })
    Then('Check tool-tip position and arrow position', function() {
        expect(this.wrapper.find("div").at(0).prop('style').left).to.equal('50px')
        expect(this.wrapper.find("div").at(0).prop('style').top).to.equal('50px')
    })
  })
})
