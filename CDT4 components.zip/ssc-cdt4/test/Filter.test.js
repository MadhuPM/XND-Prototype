import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Filter from '../src/components/Filter'


const selectOptions=[{value:'option 1',label:'option 1'},{value:'option 2',label:'option 2'},{value:'option 3',label:'option 3'},{value:'option 4',label:'option 4'}]
const onChange=(e)=>{
  console.log(e)
}
/*global Feature, Scenario, Given, When, Then*/
Feature('Filter Component', function() {
  
  Scenario('Filter Component Actions', function() {
    Given('Test For Each Filter Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    }) 
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Filter
          options={selectOptions}
        />
      )
    })
    Then('Check filter option change and focus', function() {
      // this.wrapper.find('.Select-input').simulate('click')
      // this.wrapper.find('.Select-menu-outer').simulate('click')
      this.wrapper = mount(
        <Filter style={{width:'315px'}}
                  options={selectOptions}
                  onChange={onChange}
        />
      )
      this.wrapper1 = mount(
        <Filter style={{width:'315px'}}
                  options={selectOptions}
                  onChange={onChange}
                  
        />
      )
      this.wrapper.find('.Select-input input').simulate('focus')
      this.wrapper.find('.Select-input input').simulate('change', {target: {value: '123'}})
      this.wrapper.find('.Select-input input').simulate('blur')
      
    })
    
    // Then('Check clicking an item,opened item to be close', function() {
    //   const onButtonClick = sinon.spy()
    //   const wrapper2 = mount((
    //     <Filter
    //       onChange={onButtonClick}
    //       options={selectOptions}
    //     />
    //   ))
      
    //   // expect(onButtonClick.calledOnce).to.equal(true)

    //   // this.wrapper.find('a').at(2).simulate('click')
    //   expect(this.wrapper.find(".design2-filterBy").hasClass('has-value')).to.equal(true)
    // })
  })
})
