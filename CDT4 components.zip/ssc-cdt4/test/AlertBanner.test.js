import React from 'react'
import {expect,assert} from 'chai'
import { mount } from 'enzyme'
import lolex from 'lolex'
import sinon from 'sinon'
import Button from '../src/components/Button'
import AlertBanner from '../src/components/AlertBanner'

/*global Feature, Scenario, Given, When, Then*/
Feature('AlertBanner Component', function () {

    Scenario('AlertBanner Component Actions', function () {
        Given('Test For Each AlertBanner Action', function () {
            this.handleClick = (i) => {
                // callback goes here
                AlertBanner.show('confirmation','abc',this.onClose,true)
            }
            this.onClose= () =>{
                console.log(123)
            }
        })
        When('Component Should Mount', function () {
            this.wrapper = mount(
                <AlertBanner inline type="attention" label="attention text" alertOffsetTop="360px"/>
            )
        })
        Then('Check AlertBanner type', function () {
            expect(this.wrapper.find("div").at(2).hasClass('attention')).to.equal(true)
        })
        Then('Check alert banner position top', function () {
            expect(this.wrapper.find("div").at(1).prop('style').top).to.equal("360px")
            this.wrapper.find('svg').at(1).simulate('click')
        })
        Then('Check show time', function () {
            
            let clock = lolex.install()

            this.wrapper2 = mount(
                <div className="container">
                    <AlertBanner type="confirmation" titleHidden inline />
                </div>
            )

            setTimeout(()=>{
                expect(this.wrapper2.find('.label').prop("style").width).to.equal("calc(100% - 70px)")
                expect(this.wrapper2.find('.design2-alert-banner').isEmpty()).to.equal(false)
            }, 2000)

            setTimeout(()=>{
                expect(this.wrapper2.find('.design2-alert-banner').isEmpty()).to.equal(false)
            }, 4000)

            clock.tick(4000)
            
        })
        Then('Check click close', function () {
            let clock = lolex.install()
            const onButtonClick = sinon.spy()
            this.wrapper3 = mount(
                <div>
                    <Button onClick={this.handleClick} />
                </div>
            )
    
            this.wrapper3.find('button').at(0).simulate('click')
                // expect(this.wrapper3.find('.design2-alert-banner').prop("style").display).to.equal("inline-block")
                // expect(onButtonClick.calledOnce).to.equal(true)


            // setTimeout(()=>{
            //     expect(this.wrapper3.find('.design2-alert-banner').prop("style").display).to.equal("none")
            // }, 4000)

            clock.tick(4000)
        })
    })
})
