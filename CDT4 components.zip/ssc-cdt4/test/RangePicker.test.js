import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import moment from 'moment'
import {IntlProvider} from 'react-intl'
import zhCN from '../src/components/DatePicker/locale/zh-CN.js'
import {DatePicker, RangePicker} from '../src/components/DatePicker'
import DatePickerBase from '../src/components/DatePicker/DatePicker'

const now = moment()
var rangeValue = []
rangeValue.push(now)
rangeValue.push(now)
/*global Feature, Scenario, Given, When, Then*/
Feature('RangePicker Component', function() {
  Scenario('RangePicker Component Actions', function() {
    Given('Test For Each RangePicker Action', function() {
    }) 
    When('Component Should Mount', function() {
      this.wrapper1 = mount(
        <IntlProvider locale="en">
          <RangePicker/>
        </IntlProvider>
      )      
    })
    Then('Check default RangePicker type in intl "en"', function() {
      expect(this.wrapper1.find("input").at(0).hasClass('design2-rangepicker design2-input')).to.equal(true)
    })
  })
  Scenario('RangePicker Component props', function() {
    Given('Test For Each RangePicker Action', function() {
    }) 
    When('Component Should Mount locale "zh-CN"', function() {
      this.onChange = sinon.spy()
      this.wrapper2 = mount(
        <IntlProvider locale="zh-CN">
          <RangePicker onChange={this.onChange} defaultValue={rangeValue}/>
        </IntlProvider>
      )      
    })
    Then('input value equals defaultValue', function() {
      let format = "YYYY年M月D日"
      expect(this.wrapper2.find("input").get(0).props.value).equal(now.format(format)+' - '+ now.format(format))
    })
    Then('Check input click, show popup calendar', function() {
      this.wrapper2.find("input").simulate('click')
      expect(this.wrapper2.find('.rc-calendar-selected-day>div.rc-calendar-date').get(0))
      this.wrapper2.find('.rc-calendar-selected-day').simulate('click')
      this.wrapper2.find('.rc-calendar-selected-day').simulate('click')
    })
    Then('select calendar date, call onchange function', function() {
      this.wrapper2.find('.rc-calendar-ok-btn').simulate('click')
      expect(this.onChange.calledOnce).to.equal(true)
    })
  })

  Scenario('RangePicker Component user input', function() {
    Given('Test For Each RangePicker Action', function() {
    }) 
    When('Component Should Mount', function() {
      this.wrapper3 = mount(
        <IntlProvider locale="en">
          <RangePicker locale={zhCN} value={rangeValue}/>
        </IntlProvider>
      )      
    })
    Then('RangePicker input change', function() {
      // let format = "YYYY年M月D日"
      let input = this.wrapper3.find("input.design2-input").at(0)
      input.simulate('change', {target: {value: '2011年1月1日'}})
      // expect(this.wrapper2.find("input").get(0).props.value).equal(now.format(format))
    })
  })

  Scenario('RangePicker Component click outside hidden', function() {
    Given('Test For Each RangePicker Action', function() {
    }) 
    When('Component Should Mount', function() {
      this.wrapper4 = mount(
        <IntlProvider locale="en">
          <RangePicker/>
        </IntlProvider>
      )      
    })
    Then('RangePicker click outside', function() {
      let icon = this.wrapper4.find('.design2-input-icon-right')
      icon.simulate('click')
      expect(this.wrapper4.find('.rc-calendar-selected-day>div.rc-calendar-date').get(0))
      icon.simulate('click')
      expect(this.wrapper4.find('.rc-calendar-selected-day>div.rc-calendar-date').length).equal(0)
    })
  })

})
