import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import StatusMonitor from '../src/components/StatusMonitor'

/*global Feature, Scenario, Given, When, Then*/
Feature('StatusMonitor Component', function() {
  let instance
  Scenario('StatusMonitor Component Actions', function() {
    Given('Test For Each StatusMonitor Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    }) 
    When('Component Should Mount', function() {
      const data = [{label: "Status 1"},
      {label: "Status 2"},
      {label: "Status 3"},
      {label: "Status 4"},
      {label: "Status 5"},
      {label: "Status 6"}
  ]
      this.wrapper = mount(
        <StatusMonitor data={data} />
      )
      instance = this.wrapper.instance()
    })
    Then('Check the length of all items', function() {
      expect(this.wrapper.find(".list-group").at(0).find("button")).to.have.length(6)
    })
    
    Then('Check click a status item', function() {

      const data = [{label: "Status 1", priority: 'HIGH'},
      {label: "Status 2", selected: true},
      {label: "Status 3", selected: true},
      {label: "Status 4"},
      {label: "Status 5"},
      {label: "Status 6"}
  ]
      const onClick = sinon.spy()

      const wrapper2 = mount(
        <StatusMonitor data={data}  onClick={onClick} />
      )
      expect(wrapper2.find(".list-group").at(0).find("button").at(2).hasClass('selected')).to.equal(true)
      wrapper2.find(".list-group").at(0).find("button").at(0).simulate('click')
      expect(onClick.calledOnce).to.equal(true)
    })
  })
})
