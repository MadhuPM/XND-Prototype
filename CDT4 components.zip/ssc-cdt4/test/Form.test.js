import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import yup from 'yup'
import sinon from 'sinon'
import Form,{TextInput,Textarea,Checkbox} from '../src/components/Form'
const options=[{value:'0',label:'Administative'},{value:'1',label:'User'}]
const radioOptions=[{value:'0',label:'Unselected Title'},{value:'1',label:'Selected Title'}]
const checkboxOptions=[{value:'0',label:'Checkbox label text'},{value:'1',label:'Checkbox label text'},{value:'3',label:'Checkbox label text',disabled:true},{value:'4',label:'Checkbox label text',disabled:true}]
const defaultStr = yup.string().default('')
const customerSchema = yup
.object({
  name: defaultStr 
  .required('Please enter a name'),
  password: defaultStr 
  .required('Please enter a password'),
  colorId: defaultStr
	.required('Please select a dark color'),
	truth:yup.boolean().default(true),
	colorList:yup.array().default(['1'])

})
const onClick = (e) => {
  // console.log(e)
}
const onChange=(e)=>{
  // console.log(e)
}
const onSubmit=(e)=>{
  // console.log('submit')
}
const formatMessage=(massages)=>{
  // console.log(massages)
  return 'Imcomplete Fields'

}
const onError=(e)=>{
  // console.log(e)
}
/*global Feature, Scenario, Given, When, Then*/
Feature('Form Component', function() {
 
  Scenario('Form Component Actions', function() {
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Form
        schema={customerSchema}
        defaultValue={customerSchema.default()}
        title="New User"
        style={{width:'370px'}}
        onChange={this.onChange}
        onSubmit={this.onSubmit} 
        onError={this.onError}
        formatMessage={this.formatMessage}
        ref='form'
        >
        <Form.Field
          name='name'
          placeholder='name'
          title='Input'
          required
        />
        <Form.Field
          name='password'
          placeholder='password'
          title='Password'
          required
          type="password"
        />
        <Form.Field
          name='name'
          placeholder='First name'
          title='Textarea'
          type="textarea"
          required
        />
        <Form.Field name='colorId' type='select' title="select" options={options}/>
        <Form.Field name='truth' type='checkbox' title="checkbox" 
        label="checkbox"
        />
        <Form.Field name='colorList' type='checkboxgroup' title="Checkbox Group" 
        options={options}
        inline
        />
        <Form.Field name='colorId' type='radio' title="Radio" 
        options={options}
        inline
        />
        {null}
        <Form.Button type='submit'>
          Submit
        </Form.Button>
        </Form>
      )
      this.wrapper1 = mount(
        <div className="outsidecomponent">
          <TextInput/>
          <Textarea>test</Textarea>
          
        </div>
      )
      this.wrapper2 = mount(
        <Checkbox   />
      )
    })
    Then('click button and show error message', function() {
      this.wrapper.find('button').simulate('click')
      // console.log(this.wrapper.state('valid'))
      // expect(this.wrapper.find('.design2-alert-banner').exists()).to.equal(true)
    })
    Then('Check to change checkbox', function() {
      this.wrapper.find('.design2-checkbox').at(0).simulate('click')
      this.wrapper.find('.design2-checkbox input').at(0).simulate('change',{target:{checked:true,value:'1'}})
      expect(this.wrapper.find('.design2-checkbox input').at(0).prop('checked')).to.equal(true)
      this.wrapper.find('.design2-checkbox input').at(1).simulate('change',{target:{checked:true,value:'1'}})
      this.wrapper.find('.design2-checkbox input').at(1).simulate('change',{target:{checked:false,value:'1'}})
      this.wrapper.find('.design2-radio input').at(1).simulate('change',{target:{value:'1'}})
      this.wrapper.find('.design2-checkbox input').at(1).simulate('click')
      this.wrapper.find('.Select-control input').simulate('focus')
      this.wrapper.find('.design2-checkbox').at(0).simulate('click')
      this.wrapper2.find('.design2-checkbox input').simulate('change',{target:{checked:true,value:'1'}})
    })
  })
})
