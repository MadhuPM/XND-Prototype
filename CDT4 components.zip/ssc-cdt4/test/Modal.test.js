import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Button from '../src/components/Button'
import Modal from '../src/components/Modal'

/*global Feature, Scenario, Given, When, Then*/
Feature('Modal Component', function() {
  let instance
  Scenario('Modal Component Actions', function() {
    Given('Test For Each Modal Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    }) 
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Modal
            animation={false}
              show
              onHide={this.hideModal}
            >
              <Modal.Header>
                <Modal.Title>Modal Title</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <p>Some contents...</p>
              </Modal.Body>
              <Modal.Footer>
                <Button onClick={this.hideModal}>Secondary Button</Button>
                <Button bsStyle="primary" onClick={this.submit}>Primary Button</Button>
              </Modal.Footer>
            </Modal>
      )

    })
    Then('Check modal close button', function() {
      expect(this.wrapper.find('.modal-title').text()).to.equals('Modal Title')
    })
    
  })
})
