import React, {ReactDOMServer} from 'react'
import chai, {expect,assert} from 'chai'
import sinon from 'sinon'
import {mount} from 'enzyme'
import {BrowserRouter as Router } from 'react-router-dom'
import Breadcrumbs from '../src/components/SecondaryNavigation/Breadcrumbs'
const linkData=[{
    key: '1',
    link:'#',
    title:'GrandParent'
  },
  {
    key: '2',
    title:'Parent'
  },
  {
    key: '3',
      title:'Child'
  }];
/*global Feature, Scenario, Given, When, Then*/
Feature('Breadcrumbs Component', function() {
  Scenario('Breadcrumbs Component Actions', function() {
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Router>
        <Breadcrumbs  links={linkData} autoLink={false}></Breadcrumbs>
        </Router>
      )
    })
     Then('Check For click the Breadcrumbs Link', function() {
      // expect(this.wrapper.state('breadcrumbArray').length).to.equal(3) 
      this.wrapper.find('.BreadcrumbsLink0').simulate('click')
      expect(this.wrapper.find('.design2-breadcrumb li').length).to.equal(3)
    })
    
  })
})
