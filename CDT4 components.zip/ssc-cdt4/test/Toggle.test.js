import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Toggle from '../src/components/Toggle'

describe('Toggle', () => {
  let toggle;
  beforeEach(() => {
    toggle = mount(<Toggle />);
  });

  it('works', () => {
    expect(toggle.state().checked).to.equal(false);
    toggle.simulate('click');
    expect(toggle.state().checked).to.equal(true);
  });

  it('should change from an initial checked state of true to false on click', () => {
    const wrapper = mount(<Toggle defaultChecked/>);
    expect(wrapper.state().checked).to.equal(true);
    wrapper.simulate('click');
    expect(wrapper.state().checked).to.equal(false);
  });

  it('should not toggle when clicked in a disabled state', () => {
    const onChange = sinon.spy()
    const wrapper = mount(<Toggle disabled checked onChange={onChange}/>);
    expect(wrapper.state().checked).to.equal(true);
    wrapper.simulate('click');
    expect(wrapper.state().checked).to.equal(true);
    expect(onChange.calledOnce).to.equal(false);
  });
});
