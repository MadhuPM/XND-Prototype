import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import yup from 'yup'
import sinon from 'sinon'
import ReactDOM from 'react-dom'

const searchData= [
    {label:'123',value:'a'},{label:'234',value:'b'},{label:'456',value:'c'},{label:'567',value:'d'},{label:'456r',value:'c'},{label:'567',value:'e'},{label:'456h',value:'c'},{label:'567d',value:'f'},{label:'456a',value:'g'},{label:'567s',value:'h'}
    ]
import Search from '../src/components/Search'
const options=[{value:'0',label:'Administative'},{value:'1',label:'User'}]
const radioOptions=[{value:'0',label:'Unselected Title'},{value:'1',label:'Selected Title'}]
const checkboxOptions=[{value:'0',label:'Checkbox label text'},{value:'1',label:'Checkbox label text'},{value:'3',label:'Checkbox label text',disabled:true},{value:'4',label:'Checkbox label text',disabled:true}]
const getOptions = (input, callback) => {
  setTimeout(() => {
    callback(null, {
      options: [
{label:'123',value:'a'},{label:'234',value:'b'},{label:'456',value:'c'},{label:'567',value:'d'},{label:'456r',value:'c'},{label:'567',value:'e'},{label:'456h',value:'c'},{label:'567d',value:'f'},{label:'456a',value:'g'},{label:'567s',value:'h'}
      ],
      // CAREFUL! Only set this to true when there are no more options,
      // or more specific queries will not be sent to the server.
      complete: true
    });
  }, 300);
};
const onChange=(e)=>{
  console.log(e)
}
const onSearch=(e)=>{
  console.log(e)
}

/*global Feature, Scenario, Given, When, Then*/
Feature('Search Component', function() {
 
  Scenario('Search Component Actions', function() {
    Given('Test For Each Search Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    }) 
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Search style={{width:'315px'}}
                  dataSource={searchData}
                  onSearch={this.onSearch}
                  onChange={this.onChange}
        />
      )
      this.wrapper1 = mount(
        <Search style={{width:'315px'}}
                  dataSource={getOptions}
                  onSearch={this.onSearch}
                  onChange={this.onChange}
                  async
        />
      )
    })
    Then('Check Search input and focus', function() {
      this.wrapper.find('.Select-input input').simulate('focus')
      this.wrapper.find('.Select-input input').simulate('change', {target: {value: '123'}})
      this.wrapper.find('.Select-input input').simulate('blur')
      // this.wrapper.find('.Select-input input')
      // .simulate('focus')

      // this.wrapper.find('.Select-menu-outer .VirtualizedSelectOption').at(0)
      // .simulate('click')
    })
  })
})
