import React from 'react'
import ReactDOM from 'react-dom'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import moment from 'moment'
import TimePicker from '../src/components/TimePicker'

const now = moment()
Feature('TimePicker Component', function() {
  let instance
  const showSecond = true;
  const format = ('HH:mm:ss');
  Scenario('Tile Component Actions', function() {
    Given('Test For Each Tile Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    })
    When('Component Should Mount', function() {
      this.change = sinon.spy()
      this.wrapper = mount(
        <TimePicker
          format={format}
          showSecond={showSecond}
          value={moment('08:24', format)}
          onChange={this.change}
        />
      )

      instance = this.wrapper.instance()
    })
    Then('set input value', function() {
      this.wrapper.setState({value:moment('08:25', format)});
      let input = this.wrapper.find(".rc-time-picker-input").get(0)
      expect(input.props.value).to.equal('08:24:00')
    })
    Then('click on time, onChange callback', function() {
      this.wrapper.find(".rc-time-picker-input").simulate('click')
      this.wrapper.find(".rc-time-picker-panel-select-option-selected").at(0).simulate('click')
      expect(this.change.calledOnce).to.equal(true)
    })
  })
})
