import React from 'react'
import {expect,assert} from 'chai'
import { mount } from 'enzyme'
import lolex from 'lolex'
import sinon from 'sinon'
import Button from '../src/components/Button'
import AlertCenter from '../src/components/AlertCenter'


const messages={
    alerts: [
      {title:'Alerts title1',time: 1514264860677,isRead: false,id: 1},
      {title:'Alerts title2',time: 1514363860677,isRead: true,id: 2},
      {title:'Alerts title3',time: 1514341960677,isRead: true,id: 3},
      {title:'Alerts title4',time: 1514264860677,isRead: false,id: 12},
      {title:'Alerts title5',time: 1514363860677,isRead: true,id: 13},
      {title:'Alerts title6',time: 1514341960677,isRead: true,id: 14},
      {title:'Alerts title7',time: 1514264860677,isRead: false,id: 15},
      {title:'Alerts title8',time: 1514363860677,isRead: true,id: 16}],
    notifications: [
      {title:'notifies title1',time: 1514364860677,isRead: false,id: 4},
      {title:'notifies title2',time: 1514364860676,isRead: false,id: 5},
      {title:'notifies title3',time: 1514364860675,isRead: false,id: 6},
      {title:'notifies title4',time: 1514364860674,isRead: true,id: 7},
      {title:'notifies title5',time: 1514364860673,isRead: false,id: 8},
      {title:'notifies title6',time: 1514364860672,isRead: false,id: 9},
      {title:'notifies title7',time: 1514364860671,isRead: false,id: 10},
      {title:'notifies title8',time: 1514364860670,isRead: true,id: 11}],
      ggjhjhg: [
        {title:'ggjhjhg title1',time: 1514364860677,isRead: false,id: 4},
        {title:'ggjhjhg title2',time: 1514364860676,isRead: false,id: 5},
        {title:'ggjhjhg title3',time: 1514364860675,isRead: false,id: 6},
        {title:'ggjhjhg title4',time: 1514364860674,isRead: true,id: 7},
        {title:'ggjhjhg title5',time: 1514364860673,isRead: false,id: 8},
        {title:'ggjhjhg title6',time: 1514364860672,isRead: false,id: 9},
        {title:'ggjhjhg title7',time: 1514364860671,isRead: false,id: 10},
        {title:'ggjhjhg title8',time: 1514364860670,isRead: true,id: 11}]
  }

/*global Feature, Scenario, Given, When, Then*/
Feature('AlertCenter Component', function () {

    Scenario('AlertCenter Component Actions', function () {
        Given('Test For Each AlertCenter Action', function () {
            this.handleClick = (i) => {
                // callback goes here
            }
        })
        When('Component Should Mount', function () {
            this.wrapper = mount(
                <AlertCenter data={messages}/>
            )
        })
        Then('Check click event', function () {
            // expect(this.wrapper.find("div").at(1).hasClass('attention')).to.equal(true)
            const markAsRead = sinon.spy()
            const onDelete = sinon.spy()
            const stopService = sinon.spy()
            const onClickLink = sinon.spy()

            const wrapper2 = mount((
              <AlertCenter 
                data={messages}
                  active='notifications'
                  onTitleClick={this.onClickLink}
                  onMarkAsRead={this.markAsRead}
                  style={{ width: 350 }}
                  overflowMenu={this.overflowMenu}
              />
            ))
            wrapper2.find('.listItem-radio').at(0).simulate('click')
            // expect(wrapper2.find('.design2-alertcenter-tab').at(0).text()).to.equal('alerts (4)')
            // expect(markAsRead.calledOnce).to.equal(true)

            wrapper2.find('.alertcenter-link').at(0).simulate('click')
            // expect(onClickLink.calledOnce).to.equal(true)
        })
    })
})
