// var assert = require('assert');
import React from 'react'
import assert from 'assert'
import { expect } from 'chai'
import { shallow, mount } from 'enzyme'
import { spy } from 'sinon'
import BarChart from '../src/components/Chart/BarChart'
import StackedBarChart from '../src/components/Chart/StackedBarChart'
import GroupBarChart from '../src/components/Chart/GroupBarChart'
import LineChart from '../src/components/Chart/LineChart'
import BubbleChart from '../src/components/Chart/BubbleChart'
import DonutChart from '../src/components/Chart/DonutChart'
import WhiskerChart from '../src/components/Chart/WhiskerChart'
import ColumnPercentageChart from '../src/components/Chart/ColumnPercentageChart'
import HeatMapChart from '../src/components/Chart/HeatMapChart'
import HeatBarChart from '../src/components/Chart/HeatBarChart'
import FloatingBarChart from '../src/components/Chart/FloatingChart'
import LineSliderChart from '../src/components/Chart/LineSliderChart'
import { XAxis } from '../src/components/Chart/common/axis'
import { Bar } from '../src/components/Chart/common/bar'

const testPadding = [
  {
      name: 'padding',
      props : {
          padding: 40
      },
      test: (props, wrapper) => {
          expect(wrapper.find('svg g[transform="translate(40,40)"]')).to.have.length(1)
      }
  },
  {
      name: 'paddingTop',
      props : {
          padding: 30,
          paddingTop: 60
      },
      test: (props, wrapper) => {
          expect(wrapper.find('svg g[transform="translate(30,60)"]')).to.have.length(1)
      }
  },
  {
      name: 'paddingLeft',
      props : {
          padding: 40,
          paddingLeft: 50
      },
      test: (props, wrapper) => {
          expect(wrapper.find('svg g[transform="translate(50,40)"]')).to.have.length(1)
      }
  },
  {
      name: 'paddingRight',
      props : {
          padding: 40,
          paddingLeft: 50,
          paddingRight: 30,
          width:500,
          height:500
      },
      test: (props, wrapper) => {
          assert(wrapper.find({width: props.width - props.paddingLeft - props.paddingRight}).length > 0)
      }
  },
  {
      name: 'paddingBottom',
      props : {
          padding: 40,
          paddingTop: 20,
          paddingBottom: 3,
          width:500,
          height:500
      },
      test: (props, wrapper) => {
          assert(wrapper.find({height: props.height - props.paddingTop - props.paddingBottom}).length > 0)
      }
  }
]

const testAxis = [
  {
      name: 'rotate',
      props: {
          xAxisTick: {
              rotate: 45
          }
      },
      test: (props, wrapper) => {
          assert(wrapper.find(XAxis).find('text').at(0).html().indexOf('rotate(45') > 0)
      }
  }
]

const clickBar = [
    {
        debug: false,
        name: 'click',
        props: {
            events: {
                onClick: spy()
            }
        },
        test: (props, wrapper) => {
            wrapper.find('.bar').at(0).simulate('click')
            expect(props.events.onClick.callCount).equals(1)
        }
    }
]
/**
* set debug: false to disable other cases
*/
const testCases = [
          {
              debug: false,
              component: BarChart,
              baseProps : {
                  data: getData(),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<rect','g')).length).equal(props.data.length)
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getData(1,'a','b'),
                          dataMapper: i => ({name: i.a, value: i.b})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  {
                    debug: false,
                    name: 'click',
                    props: {
                        events: {
                            onClick: spy()
                        }
                    },
                    test: (props, wrapper) => {
                        wrapper.find('.bar').at(0).simulate('click')
                        expect(props.events.onClick.callCount).equals(1)
                    }
                  },
                  ...testAxis,
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: GroupBarChart,
              baseProps : {
                  data: getData(2),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<rect','g')).length).equal(props.data.length)
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getData(2,'a','b'),
                          dataMapper: i => ({name: i.a, value: i.b})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  {
                    debug: false,
                    name: 'click',
                    props: {
                        events: {
                            onClick: spy()
                        }
                    },
                    test: (props, wrapper) => {
                        wrapper.find('.bar').at(0).simulate('click')
                        expect(props.events.onClick.callCount).equals(1)
                    }
                  },
                  ...testAxis,
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: FloatingBarChart,
              baseProps : {
                  data: getFloatingData(),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<rect class="bar"','g')).length).equal(props.data.length)
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getFloatingData('a','b','c'),
                          dataMapper: i => ({name: i.a, begin: i.b, end: i.c})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  ...clickBar,
                  ...testAxis,
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: StackedBarChart,
              baseProps : {
                  data: getData(3),
              },
              cases: [
                  {
                      debug: false,
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<rect','g')).length).equal(props.data.length)
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getData(3,'a','b'),
                          dataMapper: i => ({name: i.a, value: i.b})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  {
                    debug: false,
                    name: 'click',
                    props: {
                        events: {
                            onClick: spy()
                        }
                    },
                    test: (props, wrapper) => {
                        wrapper.find('.bar').at(0).simulate('click')
                        expect(props.events.onClick.callCount).equals(1)
                    }
                  },
                  ...testAxis,
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: ColumnPercentageChart,
              baseProps : {
                  data: getData(3),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<rect','g')).length).equal(props.data.length)
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getData(3,'a','b'),
                          dataMapper: i => ({name: i.a, value: i.b})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  {
                      name: 'rotate',
                      props: {
                          xAxisTick: {
                              rotate: 45
                          }
                      },
                      test: (props, wrapper) => {
                          assert(wrapper.find('svg text').at(0).html().indexOf('rotate(45') > 0)
                      }
                  },
                  {
                    debug: false,
                    name: 'click',
                    props: {
                        events: {
                            onClick: spy()
                        }
                    },
                    test: (props, wrapper) => {
                        wrapper.find('.bar').at(0).simulate('click')
                        expect(props.events.onClick.callCount).equals(1)
                    }
                  },
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: LineChart,
              baseProps : {
                  data: getData(),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<circle','g')).length).equal(props.data.length)
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getData(1,'a','b'),
                          dataMapper: i => ({name: i.a, value: i.b})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  {
                    debug: false,
                    name: 'click',
                    props: {
                        events: {
                            onClick: spy()
                        }
                    },
                    test: (props, wrapper) => {
                        wrapper.find('.dot').at(0).simulate('click')
                        expect(props.events.onClick.callCount).equals(1)
                    }
                  },
                  ...testAxis,
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: DonutChart,
              baseProps : {
                  data: getData(),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<path','g')).length).equal(props.data.length)
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getData(1,'a','b'),
                          dataMapper: i => ({name: i.a, value: i.b})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  {
                    debug: false,
                    name: 'click',
                    props: {
                        events: {
                            onClick: spy()
                        }
                    },
                    test: (props, wrapper) => {
                        wrapper.find('.arc').at(0).simulate('click')
                        expect(props.events.onClick.callCount).equals(1)
                    }
                  },
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: WhiskerChart,
              baseProps : {
                  data: getWhiskerData(),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<circle','g')).length - 1).equal(props.data.length)// exclude element from legend
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getWhiskerData('a','b','c','d','e'),
                          dataMapper: i => ({name: i.a, min: i.b, max: i.c, target: i.d, actual: i.e})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  {
                    name:'missing value',
                      props: {
                          data: [
                                    { name: 'A', min: 10, max: 80, target: null, actual: '' },
                                    { name: 'B', min: 20, max: 70, target: '', actual: null },
                                    { name: 'C', min: undefined, max: 80, target: 75, actual: 60 },
                                    { name: 'D', min: 40, max: 60, target: 70, actual: 60 },
                                    { name: 'E', min: 40, max: 50, actual: 60 },
                                    { name: 'F', min: 40, max: 50, target: 70 }
                                ]
                      },
                      test: (props, wrapper, cases) => {
                        let html = wrapper.html()
                        expect(html.match(new RegExp('class="target"','g')).length - 1).equal(3)// exclude element from legend
                        expect(html.match(new RegExp('class="actual"','g')).length - 1).equal(3)// exclude element from legend
                      }
                  },
                  {
                    debug: false,
                    name: 'click',
                    props: {
                        events: {
                            onClick: spy()
                        }
                    },
                    test: (props, wrapper) => {
                        wrapper.find('.event-area').at(0).simulate('click')
                        expect(props.events.onClick.callCount).equals(1)
                    }
                  },
                  ...testAxis,
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: HeatMapChart,
              baseProps : {
                  data: getHeatMapData(),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<rect','g')).length - 8 - 1 ).equal(props.data.length) // exclude elements from legend, tooltip
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getHeatMapData('a','b','c'),
                          dataMapper: i => ({x: i.a, y: i.b, value: i.c})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  {
                      name: 'rotate',
                      props: {
                          xAxisTick: {
                              rotate: 45
                          }
                      },
                      test: (props, wrapper) => {
                          assert(wrapper.find('svg text').at(0).html().indexOf('rotate(45') > 0)
                      }
                  },
                  {
                    debug: false,
                    name: 'click',
                    props: {
                        events: {
                            onClick: spy()
                        }
                    },
                    test: (props, wrapper) => {
                        wrapper.find('.plaque').at(0).simulate('click')
                        expect(props.events.onClick.callCount).equals(1)
                    }
                  },
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: BubbleChart,
              baseProps : {
                  data: getData(),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<circle','g')).length).equal(props.data.length)
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getData(1,'a','b'),
                          dataMapper: i => ({name: i.a, value: i.b})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  {
                      debug: false,
                      name: 'click',
                      props: {
                          events: {
                              onClick: spy()
                          }
                      },
                      test: (props, wrapper) => {
                          wrapper.find('.bubble').at(0).simulate('click')
                          expect(props.events.onClick.callCount).equals(1)
                      }
                  },
                  ...testAxis,
                  ...testPadding
              ]
          },
          {
              component: LineSliderChart,
              baseProps : {
                  data: getLineSliderData(),
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<path','g')).length - 3).equal(1)
                      }    
                  },
                  {
                      name: 'dataMapper',
                      props: {
                          data: getLineSliderData('a','b'),
                          dataMapper: i => ({name: i.a, value: i.b})
                      },
                      test: (props, wrapper, cases) => { 
                          cases[0].test(props, wrapper)
                      }    
                  },
                  ...testAxis,
                  ...testPadding
              ]
          },
          {
              debug: false,
              component: HeatBarChart,
              baseProps : {
                  width: 500,
                  height: 400,
                  value: 80,
                  range: [0,20,40,60,80,100]
              },
              cases: [
                  {
                      name: 'data',
                      test: (props, wrapper) => { 
                          let html = wrapper.html()
                          expect(html.match(new RegExp('<polygon','g')).length).equal(1)
                      }    
                  },
                  {
                      name: 'rotate',
                      props: {
                          xAxisTick: {
                              rotate: 45
                          }
                      },
                      test: (props, wrapper) => {
                          assert(wrapper.find('svg text').at(0).html().indexOf('rotate(45') > 0)
                      }
                  },
                  {
                    debug: false,
                    name: 'click',
                    props: {
                        events: {
                            onClick: spy()
                        }
                    },
                    test: (props, wrapper) => {
                        wrapper.find('.pointer').at(0).simulate('click')
                        expect(props.events.onClick.callCount).equals(1)
                    }
                  },
                  ...testPadding
              ]
          }
          
]

Feature('Chart Components', function() {
    getDebugItems(testCases).forEach(({ component: Component, baseProps, cases }) => {
        getDebugItems(cases).forEach(c => {
            Scenario(`${Component.name}`, function() {
                let props = Object.assign({}, baseProps, c.props)

                Given(`Props: ${getPropsNames(props)}`, function() {
                    this.props = props
                }) 
                When('Mount', function() {
                    this.wrapper = mount(<Component {...this.props} />)
                })
                Then(`test ${c.name}`, function() {
                    c.test(this.props, this.wrapper, cases)
                })
            })
        })
    })
})

function getPropsNames(props) {
    return Object.keys(props).join(' ')
}

function getDebugItems(arr) {
  let result = arr.filter(i => i.debug)
  return result.length > 0 ? result : arr
}


function getData(repeat = 1, p0 = 'name', p1 = 'value') {
  let arr = []

  for (let i = 0; i < 3; i++) {
      for (let j = 0; j < repeat; j++) {
          arr.push({
              [p0]: i.toString(),
              [p1]: 3
          })
      }
  }
  return arr
}

function getFloatingData(p0 = 'name', p1 = 'begin', p2 = 'end') {
  let arr = []

  for (let i = 0; i < 3; i++) {
      arr.push({
          [p0]: i.toString(),
          [p1]: 1,
          [p2]: 2
      })
  }
  return arr
}

function getWhiskerData(p0 = 'name', p1 = 'min', p2 = 'max', p3 = 'target', p4 = 'actual') {
  return [
      { [p0]: 'A', [p1]: 10, [p2]: 80, [p3]: 75, [p4]: 99 },
      { [p0]: 'B', [p1]: 20, [p2]: 70, [p3]: 65, [p4]: 40 },
      { [p0]: 'C', [p1]: 30, [p2]: 80, [p3]: 75, [p4]: 60 },
      { [p0]: 'D', [p1]: 40, [p2]: 60, [p3]: 70, [p4]: 70 }
  ]
}

function getHeatMapData(p0 = 'x', p1 = 'y', p2 = 'value') {
  return [
      { [p0]: "A", [p1]: "1", [p2]: 2 },
      { [p0]: "A", [p1]: "2", [p2]: 2 },
      { [p0]: "A", [p1]: "3", [p2]: 6 },
      { [p0]: "B", [p1]: "1", [p2]: 8 },
      { [p0]: "B", [p1]: "2", [p2]: 6 },
      { [p0]: "B", [p1]: "3", [p2]: 8 },
      { [p0]: "C", [p1]: "1", [p2]: 3 },
      { [p0]: "C", [p1]: "2", [p2]: 8 },
      { [p0]: "C", [p1]: "3", [p2]: 3 }
    ]
}

function getLineSliderData(p0 = 'name', p1 = 'value') {
  let start = 1970
    let arr = []

    for(let i = 0; i < 5; i ++) {
        let name = start + i + ''
        arr.push({
            [p0]: name,
            [p1]: 4
        })
    }

    return arr
}