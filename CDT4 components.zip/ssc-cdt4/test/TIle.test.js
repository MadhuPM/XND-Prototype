import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import sinon from 'sinon'
import Tile from '../src/components/Tile'
/*global Feature, Scenario, Given, When, Then*/
Feature('Tile Component', function() {
  let instance
  Scenario('Tile Component Actions', function() {
    Given('Test For Each Tile Action', function() {
      this.handleClick = (i) => {
        // callback goes here
      }
    })
    When('Component Should Mount', function() {
      this.wrapper = mount(
        <Tile name="Product Name" badge={1} onClick={this.handleClick}/>
      )

      instance = this.wrapper.instance()
    })
    Then('Check name to be a string', function() {
      expect(this.wrapper.props().name).to.be.a('String')
			expect(this.wrapper.props().name).to.equal("Product Name")
    })
    Then('Check badge to be a number', function() {
      expect(this.wrapper.props().badge).to.be.a('Number')
			expect(this.wrapper.props().badge).to.equal(1)
    })
    Then('Check onClick to be a function', function() {
      expect(this.wrapper.props().onClick).to.be.a('function')
			expect(this.wrapper.props().onClick).to.equal(this.handleClick)
    })
    Then('Check clicking on del', function() {
      const onTileClick = sinon.spy()
      const onTileDeleteClick = sinon.spy()
      this.wrapper2 = mount(
        <Tile name="Product Name" badge={1}
          onClick={onTileClick}
          deletable
          onDelete={onTileDeleteClick} />
      )
      this.wrapper2.find('.design2-tile-default').simulate('click')
      // this.wrapper2.find('.icon').simulate('click') // same as above
      this.wrapper2.find('.del').simulate('click')

      expect(onTileDeleteClick.calledOnce).to.equal(true)
      expect(onTileClick.calledOnce).to.equal(true)
      expect(this.wrapper2.find('.design2-tile-default').length).to.equal(0)
    })
  })
})

describe('badge number > 99', () => {
  it('badge show change accordingly', () => {
    const wrapper3 = mount(<Tile name="Product Name" badge={100} />)
    const wrapper4 = mount(<Tile name="Product Name" badge={98} />)
    expect(wrapper3.find('.t-badge-plus').children().find('span').html()).to.equal("<span>99</span>")
    expect(wrapper4.find('.t-badge').children().find('span').html()).to.equal("<span>98</span>")
  })
})

describe('mount', () => {
  // warning: Failed PropType: Required prop 'name' was not specified in 'Tile'
  it('tile mount with less props', () => {
    const wrapper5 = mount(<Tile name="Corporate Actions Processing" badge={100}>
                          <span style={{border:"2px solid #fff",height:"48px",width:"48px"}}>CAP</span>
                        </Tile>)
    const wrapper6 = mount(<Tile description="description me" />)
  })
})
