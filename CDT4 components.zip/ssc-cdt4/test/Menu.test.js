import React, {ReactDOMServer} from 'react'
import ReactDOM from 'react-dom'
import chai, {expect,assert} from 'chai'
import sinon from 'sinon'
import {mount} from 'enzyme'
import {contains} from '../src/components/Menu/util'
import Menu,{SubMenu,MenuItem} from '../src/components/Menu'
const log=(e)=>{
  console.log(e)
}

/*global Feature, Scenario, Given, When, Then*/
Feature('Menu Component', function() {
  Scenario('Menu Component ', function() {
    let profileMenu = new Array
    // let logo = new Object
    When('the Component is Mounted on the Virtual DOM on inline Mode', function() {
      this.wrapper = mount(
        <Menu inline defaultSelectedKeys={['1']} defaultOpenKeys={['2']} test>
							<MenuItem key="1">Parent 1</MenuItem>
              <MenuItem divider></MenuItem>
							<SubMenu key='2' title="Parent 2">
								<MenuItem key='3' disabled>Child 1</MenuItem>
								<MenuItem key='4'>Child 2</MenuItem>
								<SubMenu key='5' title="Child 3"  link="1">
									<MenuItem key='6'>GrandChild 1</MenuItem>
								</SubMenu>
								<SubMenu key='7' title="Child 4" disabled>
									<MenuItem key='8'>GrandChild 2</MenuItem>
								</SubMenu>
							</SubMenu>
						</Menu>   
      )       
    })
    Then('Check For the state of select item and open subMenu', function() {
      expect(this.wrapper.find('.selectedItem').text()).to.equal('Parent 1')
      expect(this.wrapper.find('#subList2').hasClass('openList')).to.equal(true)
    })
    Then('Click submenu and menu item, Expext the right response', function() {
      this.wrapper.find('.subMenuTitle').at(1).simulate('click')
      expect(this.wrapper.find('#subList5').hasClass('openList')).to.equal(true)
      this.wrapper.find('.subMenuTitle').at(1).simulate('click')
      expect(this.wrapper.find('#subList5').hasClass('openList')).to.equal(false)
      this.wrapper.find('.MenuItem').at(3).simulate('click')
      expect(this.wrapper.find('.MenuItem').at(3).hasClass('selectedItem')).to.equal(true)
    })
    When('the Component is Mounted on the Virtual DOM on dropdown Mode with multiple', function() {
      this.wrapper1 = mount(
        <div className="outWrapper">   
            <Menu onSelect={log} multiple test>
							<MenuItem key="1">Parent 1</MenuItem>
							<SubMenu key='2' title="Parent 2" >
								<MenuItem key='3' disabled>Child 1</MenuItem>
								<MenuItem key='4'>Child 2</MenuItem>
								<SubMenu key='5' title="Child 3">
									<MenuItem key='6'>GrandChild 1</MenuItem>
								</SubMenu>
								<SubMenu key='7' title="Child 4" disabled>
									<MenuItem key='8'>GrandChild 2</MenuItem>
								</SubMenu>
								<SubMenu key='8' title="Child 4" disabled>
								</SubMenu>
							</SubMenu>
						</Menu>  
            <div className="otherDiv" onClick={log} style={{width:'100px',height:'100px'}}>123</div> 
          </div>,{ attachTo: document.body })       
    })
    Then('Click submenu and menu item, Expext the right response', function() {
      // console.log(document.body.childNodes.find('.MenuItem'))
      // console.log(this.wrapper1.find('.MenuItem').at(1))
      this.wrapper1.find('.menu-header').simulate('click')
    //   expect(this.wrapper1.find('.MenuItem').at(1).hasClass('selectedItem')).to.equal(false)
    //   this.wrapper1.find('.MenuItem').at(4).simulate('click')
    //   expect(this.wrapper1.find('.MenuItem').at(4).hasClass('selectedItem')).to.equal(true)
    //   this.wrapper1.find('.MenuItem').at(4).simulate('click')
    //   expect(this.wrapper1.find('.MenuItem').at(4).hasClass('selectedItem')).to.equal(false)
    // })
    // Then('Mouse enter and leave', function() {
    //   expect(this.wrapper1.find('.dropdownContainer').hasClass('hideContainer')).to.equal(true)
    //   this.wrapper1.find('.menuHeader').simulate('click')
    //   expect(this.wrapper1.find('.dropdownContainer').hasClass('hideContainer')).to.equal(false)
    //   this.wrapper1.find('.subMenuTitle').at(0).simulate('mouseEnter')
    //   this.wrapper1.find('.subMenuContainer').at(0).simulate('mouseLeave')
    //   this.wrapper1.find('.menuHeader').simulate('click')
    //   expect(this.wrapper1.find('.dropdownContainer').hasClass('hideContainer')).to.equal(true)
    //   this.wrapper1.find('.menuHeader').simulate('click')
    //   this.wrapper1.find('.otherDiv').simulate('click')
    })
    When('Mounted for Manually update selectkey', function() {
      this.wrapper2 = mount(
            <Menu  multiple selectedKeys={['1']} openKeys={['2']} test>
							<MenuItem key="1">Parent 1</MenuItem>
							<SubMenu key='2' title="Parent 2" >
								<MenuItem key='3'>Child 1</MenuItem>
							</SubMenu>
						</Menu>  
      )       
    })
    Then('Manual change select key and open key', function() {
      // this.wrapper2.setProps({selectedKeys:['3']})
      // expect(this.wrapper2.find('.MenuItem').at(1).hasClass('selectedItem')).to.equal(true)
      this.wrapper2.setProps({openKey:[]})
      // expect(this.wrapper2.find('.subList').hasClass('openList')).to.equal(false)
      // this.wrapper2.node.handleDocumentClick({target:{}})
      // this.wrapper2.node.handleDocumentClick((this.wrapper2.node))
      contains('1','1')
      this.wrapper2.unmount()
    })
  })
})
