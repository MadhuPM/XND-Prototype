#!/usr/bin/env node

var inquirer = require('inquirer');
var shell = require('shelljs');
var fs = require('fs');
if (!shell.which('npm')) {
  shell.echo('Sorry, this script requires npm');
  shell.exit(1);
}
var questions = [
  {
    type: 'input',
    name: 'project_name',
    message: 'What\'s your project name',
    default: 'cdt4_demo'
  },{
    type: 'input',
    name: 'author',
    message: 'author',
    default: 'State Street Corp'
  },{
    type: 'input',
    name: 'description',
    message: 'description',
    default: ''
  },{
    type: 'list',
    name: 'framework',
    message: 'Which backend web service framework do you want?',
    choices: ['IDF web service','Spring RESTful','No framework'],
    default: 'IDF web service'
  },
  {
    type: 'list',
    name: 'install',
    message: 'Do you want to install the npm package right now automatically?',
    choices: ['Yes','No'],
    default: 'Yes'
  }
];
inquirer
  .prompt(questions)
  .then(function (answers) {
    copyFile(answers)
  });
function copyFile(answers){
  switch (answers.framework) {
    case 'IDF web service':
      shell.cp('-r',__dirname+'/template/idf',answers.project_name)
      break;
    case 'No framework':
      shell.cp('-r',__dirname+'/template/servlet',answers.project_name)
      break;
    case 'Spring RESTful':
      shell.cp('-r',__dirname+'/template/spring',answers.project_name)
      break;
  }
  shell.cd(answers.project_name)
  readInfo(answers)
}
function readInfo(info) {
  var json = {}
  shell.cd('ui')
  fs.readFile('package.json', function (err, data) {
    if (err) 
      throw err;
    json = JSON.parse(data);
    json.name=info.project_name
    json.description=info.description
    json.author=info.author
    var newData = JSON.stringify(json, null, 2);
    fs.writeFileSync('package.json', newData);
    if (info.install==='Yes') {
      console.log('finish generate a new project,start to npm install automatically, please wait')
      npmInstall()
    }else{
      console.log('finish generate a new project, please follow the readme.md to start the project')
    }
  });
  if (info.framework!='No framework') {
    fs.readFile('../.project','utf8', function (err, data) {
      if (err) 
        throw err;
      var newData=data.replace(/cdt4\-project\-(idf|servlet|spring)/g,info.project_name)
      fs.writeFileSync('../.project', newData);
    });
    fs.readFile('../build.xml','utf8', function (err, data) {
      if (err) 
        throw err;
      var newData=data.replace(/design2/g,info.project_name)
      fs.writeFileSync('../build.xml', newData);
    });
  }
  fs.readFile('../pom.xml','utf8', function (err, data) {
    if (err) 
      throw err;
    var newData=data.replace(/cdt4\-project\-(idf|servlet|spring)/g,info.project_name)
    fs.writeFileSync('../pom.xml', newData);
  });
}
function npmInstall(){
  if (!shell.which('yarn')) {
    console.log('Install yarn');
    yarnInstall()
  }else{
    shell.exec('yarn install', {
      async: true
    }, function (code, stdout, stderr) {
      if (code==0) {
        console.log('npm install finish,please follow the readme.md to start the project');
        shell.exit(1);
      }else{
        console.log('npm install failed, please tried it manually');
        shell.exit(1);
      }
    })    
  }
}
function yarnInstall(){
  shell.exec('npm install -g yarn', {
    async: true
  }, function (code, stdout, stderr) {
    if (code==0) {
      npmInstall()
    }else{
      console.log('npm install failed, please tried it manually');
      shell.exit(1);
    }
  }) 
}
