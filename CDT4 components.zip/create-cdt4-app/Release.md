# Release Notes
## v 2.0.2
Upgrade template to react router v4
Add react hot module
## v 2.0.1
Upgrade template to react16
## v 1.0.12
Fix bug (File info not change if choose auto install)
## v 1.0.11
Update default context to 'cloudservises'
## v 1.0.10
Update webpack to 3.10.0
Optimize project structure
## v 1.0.9
Add deploy cloud app doc
## v 1.0.8
Remove auto install option
## v 1.0.7
Add option project with Spring
## v 1.0.6
Rename to cdt4,it will only cotain ssc-cdt4 components
## v 1.0.5
using React.PropTypes (dev performance issus)
## v 1.0.4
add pages
change routes/index.js
## v 1.0.3
Add option project without backend framework
Update file structure
## v 1.0.2
Remove useless warning for git environment
## v 1.0.1
Add document
## v 1.0.0
### Init
Generate a maven project with IDF and ssc-cdt3 components

# Todo List
- [X] option of generate project without IDF
- [X] default generate project only contain design2(ssc-cdt4) components
- [X] option of generate project with spring
