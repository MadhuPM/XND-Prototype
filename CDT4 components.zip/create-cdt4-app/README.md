# Create an app based on cdt4
Currently, it can offer three kinds of project.
One with backend `IDF` integration,one with Spring and one has no backend framework integrated.
More detail, please check our [wiki](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki)

## Install the generator
```bash
npm install -g create-cdt4-app
```

## Execute the generator to generate a new project
Go to the folder where you want to put this project

```bash
cdt4
```
And then follow the instrution to set up a develop environment

deploy a cloud app, please see this 
[deploy doc](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/blob/Develop/create-cdt4-app/publish_cdt4_template_IDF_app.docx)

## [Release Note and Roadmap](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/blob/Develop/create-cdt4-app/Release.md)
