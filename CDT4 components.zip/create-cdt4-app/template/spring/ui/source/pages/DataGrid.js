import React from "react";
import PropTypes from 'prop-types'
import { DataGrid, connectRest, AlertBanner } from 'ssc-cdt4';
import {FormGroup, ControlLabel, FormControl, Button, Col} from 'react-bootstrap';

export const employeeConfig = [
  {
    dataKey: 'id',
    label: 'ID',
    width: 180,
    dataType: 'string'
  },
  {
    dataKey: 'name',
    label: 'Name',
    width: 180,
    dataType: 'string'
  },
  {
    dataKey: 'department',
    label: 'Department Name',
    width: 180,
    dataType: 'string'
  },
  {
    dataKey: 'onBoarding',
    label: 'OnBoarding Date',
    width: 180,
    dataType: 'date'
  },
  {
    dataKey: 'createTime',
    label: 'Create Time',
    width: 180,
    dataType: 'datetime'
  }
];

let count = 10;

@connectRest('employee', employeeConfig, 'id')
export default class Template extends React.Component {
  componentDidMount = () => {
    const { employeeActions } = this.props;

     employeeActions.list().then(res => {
      // eslint-disable-next-line
      console.log(res.payload.data)
      const type = 'confirmation'
      AlertBanner.show(
        type,
        `data load successfully`
      )

    });

  }

  add = () => {
    const { employeeActions } = this.props;
         const num = count++
         employeeActions.add({id: num, name:`mike${num}`, department: `ss${num}`, onBoarding: new Date(), createTime: new Date()}).then(res => {
          // eslint-disable-next-line
          console.log(res.payload.data)
          const type = 'confirmation'
          AlertBanner.show(
            type,
            `data added successfully`
          )
        });
  }

  
  load = () => {
    const { employeeActions } = this.props;
         employeeActions.load({id: "1"}).then(res => {
          // eslint-disable-next-line
          console.log(res.payload.data)
          const type = 'confirmation'
          AlertBanner.show(
            type,
            `the name of id:1 is ${res.payload.data.name}`
          )
    
        });
  }

  delete = () => {
    const { employeeActions } = this.props;
         employeeActions.delete({id: "3"}).then(res => {
           // eslint-disable-next-line
          console.log(res.payload.data)
          const type = 'confirmation'
          AlertBanner.show(
            type,
            `the employee of id :3 is  deleted`
          )
    
        });
  }

  update = () => {
    const { employeeActions } = this.props;
    
         employeeActions.update({id: '2', name: 'new_mike2'}).then(res => {
          // eslint-disable-next-line
          console.log(res.payload.data)
          const type = 'confirmation'
          AlertBanner.show(
            type,
            `the name of employee id: 2 is updated`
          )
        });
  }

  // loadOnce = () => {
  //   const { employeeActions } = this.props;
    
  //        employeeActions.localList({id: '1', name:'abc'});
  // }

  deleteWithException = () => {
    const { employeeActions } = this.props;
    employeeActions.delete({
      "id": "1"
    }).then(res => {
      if (res.error) {
        const type = 'warning'
        AlertBanner.show(
          type,
          res.payload.errorMsg
        )
      } else {
        const type = 'confirmation'
        AlertBanner.show(
          type,
          `data deleted successfully`
        )
      }
    });
  }

  

  render() {
    const buttonStyle = {marginRight: 8};
    return (
      <div >
        <div style={{ position: 'absolute', left: 250, top: 100, height: 300, width: '70%' }}>
          <DataGrid
            columns={employeeConfig}
            keyFieldName="id"
            data={this.props.employee.data}
            hasPriority
            hasCheckbox
            title="Basic Table"
          />
        </div>
        <div style={{ position: 'absolute', left: 250, top: 440, height: 300, width: '70%' }}>
            <Button style={buttonStyle} onClick={this.add} >add</Button>
            <Button style={buttonStyle} onClick={this.delete} >delete</Button>
            <Button style={buttonStyle} onClick={this.update} >update</Button>
            <Button style={buttonStyle} onClick={this.load} >load</Button>

            <Button bsStyle="danger" style={buttonStyle} onClick={this.deleteWithException} >exception</Button>
            {/* {<Button style={buttonStyle} onClick={this.loadOnce} >loadOnce</Button>} */}

          </div>
          
      </div>
    );
  }
}
Template.propTypes =  {
  employeeActions:PropTypes.any,
  employee:PropTypes.any
}