const path = require("path")
let express = require('express')
let fs = require('fs')
let router = express.Router()
let app = express()
const devMiddleware = require("webpack-dev-middleware")
let webpack = require('webpack')
let config = require('../config/webpack.dev.js')

let ctxRoot = process.argv[2]
if (!ctxRoot) {
  /* eslint-disable no-console */
  console.error('Error!')
  console.error('Must pass context root as second arg: node server.js <MyContextRoot>')
  process.exit()
}else if(ctxRoot.startsWith('/')){
  ctxRoot = ctxRoot.substr(1);
}

process.env.CONTEXT_ROOT = ctxRoot

let baseURL = `http://localhost:8080/${ctxRoot}/`

let url = require('url')
function getOptions(proxyUrl) {
  let options = url.parse(proxyUrl)
  options.cookieRewrite = true
  return options
}
let compiler = webpack(config)

app.use(devMiddleware(compiler, {
  publicPath: '/'+ctxRoot,
  noInfo: false,
  stats: {
    colors: true,
    chunks: false
  },
  watchOptions: {
    aggregateTimeout: 1000,
    ignored: /node_modules\/(?!(ssc-cdt3|cdt-core)\/).*/,
    poll: true
  }
}))

app.use(require('webpack-hot-middleware')(compiler))

let proxy = require('proxy-middleware')

router.use('/json', proxy(getOptions(`${baseURL}json`)))
router.use('/api', proxy(getOptions(`${baseURL}api`)))
router.use('/data', proxy(`${baseURL}data`))

app.get('/', (req, res) => {
  res.redirect(`http://localhost:8000/${ctxRoot}/`)
})

app.use(`/${ctxRoot}/`, router)

app.use("*", (req, res, next) => {
  const filename = path.join(compiler.outputPath, "index.html")
  compiler.outputFileSystem.readFile(filename, (err, result) => {
    if (err) {
      return next(err)
    }
    res.set("content-type", "text/html")
    res.send(result)
    res.end()
    return res
  })
})

app.listen(8000)
//open http://localhost:8000/cloudservices
  /* eslint-disable no-console */
console.log('Navigate to http://localhost:8000')
console.log('in your browser for development.\n')
console.log('Make sure that your tomcat server is started on port 8080.\n')
console.log('Service calls will be proxied to')
console.log(`http://localhost:8080/${ctxRoot}`)
