package com.ssc.rest.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.common.RestException;
import com.ssc.rest.entity.Employee;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value = "/employee", tags = "Employee Api")
@RequestMapping(value = "/employee")
public class EmployeeController {

	/**
	 * http://localhost:8080/cloudservices/api/employee/list
	 * 
	 * User-Agent: Fiddler
	   Host: localhost:9090
	   Content-Length: 468
	   Content-Type: application/json
	   
	   request body is mandatory {}
	 * @param bo
	 * @return
	 */
	private static List<Employee> employeeList = new ArrayList<>();
	static {
		for (int i=0; i<10; i++) {
			Employee obj = new Employee();
			obj.setName("Mike" + i);
			obj.setDepartment("SS" + i);
			obj.setId(i + "");
			obj.setOnBoarding(new Date());
			obj.setCreateTime(new Date());
			employeeList.add(obj);
		}
		
	}
	
	@RequestMapping(value = RequestAction.LIST, method = RequestMethod.POST)
	@ApiOperation(value = "loadAllEmployees", notes = "get employee list", httpMethod = "POST", response = Employee.class, responseContainer = "List")
	public List<Employee>  list(@RequestBody Employee bo) {
		return employeeList;

	}
	
	
	@RequestMapping(value = RequestAction.LOAD, method = RequestMethod.POST)
	@ApiOperation(
			value = "loadEmployee", 
			notes = "get employee by name or department", 
			httpMethod = "POST")
	public Employee getEmployee(
			@RequestBody Employee input) {
		for (Employee employee : employeeList) {
			if (employee.getId().equals(input.getId())) {
				return employee;
			}
		}
		return input;
	}
	
	
	@RequestMapping(value = RequestAction.ADD, method = RequestMethod.POST)
	@ApiOperation(value = "addEmployee", notes = "add new employee", httpMethod = "POST", response = Employee.class)
	public Employee addEmployee(@RequestBody Employee bo) {
		return bo;
	}
	
	@RequestMapping(value = RequestAction.DELETE, method = RequestMethod.POST)
	@ApiOperation(value = "deleteEmployee", notes = "delete employee", httpMethod = "POST", response = Employee.class)
	public Employee deleteEmployee(@RequestBody Employee bo) throws RestException {
		// exception test
		if ("1".equals(bo.getId())) {
			throw new RestException("the number 1 employee can not be deleted");
		}
		return bo;
	}
	
	@RequestMapping(value = RequestAction.UPDATE, method = RequestMethod.POST)
	@ApiOperation(value = "updateEmployee", notes = "update employee", httpMethod = "POST", response = Employee.class)
	public Employee updateEmployee(@RequestBody Employee bo) {
		for (Employee employee : employeeList) {
			if (employee.getId().equals(bo.getId())) {
				employee.setName(bo.getName());
				return employee;
			}
		}
		return bo;
	}
	
	
	
	
	

	 

}
