package com.ssc.data;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.google.gson.JsonObject;

public class DataServletTest {

	@Test
	public void testReadJson() throws IOException {
		JsonObject json = DataServlet.readJson();
		Assert.assertEquals(json.get("Name").getAsString(), "crunchify.com");
	}

}
