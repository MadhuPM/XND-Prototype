## project folder structures
<img src="./structures.png" />

## start demo
1. cd ui
2. npm install
3. npm start
4. run eclipse maven project (start server)
5. visit http://localhost:8000/cloudservices
## adding pages
1. add new pages to source/pages
2. add corresponding routes to source/routes/index.js
