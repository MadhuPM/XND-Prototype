const path = require("path")
const webpack = require("webpack")
const webpackMerge = require("webpack-merge")
const CleanWebpackPlugin = require("clean-webpack-plugin")
const commonConfig = require("./webpack.common.js")
const ASSET_PATH = process.env.ASSET_PATH || "./"
const OUTPUT_PATH = process.env.OUTPUT_PATH || "../../src/main/webapp"

const VERSION = commonConfig.VERSION

module.exports = webpackMerge(commonConfig, {
  entry: {
    app: [
      "babel-polyfill",
      path.resolve(__dirname, "../source/index")
    ]
  },
  output: {
    path: path.resolve(__dirname, OUTPUT_PATH),
    publicPath: ASSET_PATH,
    filename: `js/[name]_${VERSION}.bundle.js`,
    chunkFilename: `js/[id]_${VERSION}.chunk.js`
  },
  plugins: [
    new CleanWebpackPlugin(["css", "fonts", "images", "js", "index.html"], {
      root: path.resolve(__dirname, OUTPUT_PATH),
      verbose: true,
      dry: false,
      watch: false,
      exclude: []
    }),
    new webpack.DefinePlugin({
      "ENV": JSON.stringify("production")
    }),
    new webpack.LoaderOptionsPlugin({
      minimize: true,
      debug: false
    })
  ]
})
