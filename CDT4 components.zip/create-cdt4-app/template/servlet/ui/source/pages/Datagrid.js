import React from "react"
import PropTypes from 'prop-types'
import {DataGrid} from 'ssc-cdt4'

const fundColConfig = [
  {
    dataKey: 'ASSET',
    label: 'Asset',
    width: 180,
    dataType: 'string',
    locked: true,
    toolTip:'Is the UBO a PEP? If yes,'
  }, {
    dataKey: 'MANAGER',
    label: 'Manager',
    width: 140,
    dataType: 'string',
    group: true,
  }, {
    dataKey: 'FUND',
    label: 'Fund',
    width: 80,
    dataType: 'string',
    group: true,
  }, {
    dataKey: 'UNITS',
    label: 'Units',
    width: 80,
    dataType: 'number',
    align: 'right'
  }, {
    dataKey: 'PRICE',
    label: 'Price',
    width: 100,
    dataType: 'number',
    numberFormat: 'currency',
    align: 'right'
  }, {
    dataKey: 'COST',
    label: 'Total Market Value',
    width: 180,
    dataType: 'number',
    numberFormat: 'currency',
    align: 'right'
  }, {
    dataKey: 'DATE',
    label: 'Date',
    width: 100,
    dataType: 'date',
    align: 'left'
  }, {
    dataKey: 'DATE_TIME',
    label: 'Date + Time',
    width: 180,
    dataType: 'datetime',
    align: 'left'
  }, {
    dataKey: 'ID',
    label: 'ID',
    width: 60,
    dataType: 'number',
    numberFormat: 'id'
  }
]
const data = [
				{"priorityType": "low", "ID": 1, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "CLGX", "UNITS": 537.0, "PRICE": 292.0762272250006, "COST": 156844.9340198253, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1, "__errorMsg": "{\"errors\":[],\"success\":true}"},
				{"priorityType": "high", "ID": 2, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "KE", "UNITS": 521.0, "PRICE": 307.18662394261725, "COST": 160044.2310741036, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1},
				{"priorityType": "medium", "ID": 3, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "AIXG", "UNITS": 296.0, "PRICE": 164.20752344196708, "COST": 48605.42693882226, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1},
				{"priorityType": "high", "ID": 4, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "AFOP", "UNITS": 53.0, "PRICE": 351.6374260235813, "COST": 18636.78357924981, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1},
				{"priorityType": "medium", "ID": 5, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "CHKP", "UNITS": 363.0, "PRICE": 395.92090457520794, "COST": 143719.28836080048, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1},
				{"priorityType": "high", "ID": 6, "FUND": "FUND0", "MANAGER": "Buchanan", "ASSET": "SAIC", "UNITS": 757.0, "PRICE": 479.8066271555781, "COST": 363213.6167567726, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1}
]

export default class DataGridDemo extends React.Component {

	render() {
		return(
			<div style={{position: 'absolute', left: 250, top: 100,  height: '80%', width: '80%'}}>
				<DataGrid
					columns={fundColConfig}
					keyFieldName="ID"
					data={data}
				hasPriority
          hasCheckbox
          title="Table Title"
				/>
			</div>
		)
	}
}
