import React from "react"
import PropTypes from 'prop-types'
import {GlobalNavigation, SecondaryNavigation}from 'ssc-cdt4'
// import {routes} from '../routes'
import { Redirect, Route, IndexRedirect,Switch,withRouter } from 'react-router-dom';
import WelcomePage from '../pages/WelcomePage'
import AnotherPage from '../pages/AnotherPage'
import Datagrid from '../pages/Datagrid'
import classNames from 'classnames'

const ProfileMenu = [ 
    {id:0, label:'My Account'},  
    {id:1, label:'Settings'},  
    {id:2, label:'Help'},  
    {id:3, label:'Client View'},  
    {id:4, label:'Log Out'}
] 
const routes=[
    {
        key: 'WelcomePage',
        title:'WelcomePage'
    },
    {
        key: 'AnotherPage',
        title:'AnotherPage'
    },{
        key: 'Datagrid',
        title:'Datagrid'
    }
]
// let getNavData = (routes = [], rootName="Pages") => {
//     let array = routes.length?routes:[routes]
//     return array.map((r)=>{
//         let path = r.path.split('/').slice(-1)[0]
//         let navData = {key:path, title:path, link:path}
//         //give root menu a nice name
//         if(path === ''){navData = {key:path, title:rootName,link:path}}

//         if (r.childRoutes && r.childRoutes.length !== undefined){
//             let other = r.childRoutes.map((x) => getNavData(x))
//             Object.assign(
//                 navData,
//                 {children:Array.prototype.concat.apply([], other)},
//                 {link:''}
//             )
//         }
//         return navData
//     })
// }

class AppContainer extends React.Component {
    constructor(props) {
        super(props)
        
        const defaultKey = props.location.pathname.slice(1)
        this.state =  {
            navTop:false, 
            defaultKey:defaultKey?defaultKey:'WelcomePage'
        }
    }
    componentWillReceiveProps(nextProps) {
        const defaultKey = nextProps.location.pathname.slice(1)
        this.setState( {defaultKey:defaultKey?defaultKey:'WelcomePage'})
      }
    selectMenu = (e) => {
        this.props.history.push(`${e.key}`)
    }
    render() {
        const {children} = this.props 
        const {defaultKey} = this.state 
        
        return ( 
            < div style =  {{height:'100%'}} >  
                < GlobalNavigation
                    profileMenu =  {ProfileMenu}
                    userName = "Jingjing"
                    productName = "Design2.0 Showcase"
                />  
                < SecondaryNavigation 
                    data =  {routes}
                    defaultSelectedKey =  {defaultKey}
                    className = 'templateSideNav'
                    autoLink =  {false}
                    onSelect =  {this.selectMenu}
                />  
                <Switch>
                    <Route path="/" exact component={WelcomePage} />
                    <Route path="/WelcomePage" component={WelcomePage} />
                    <Route path="/AnotherPage" component={AnotherPage} />
                    <Route path="/Datagrid" component={Datagrid} />
                </Switch>
            </div > 
        )
    }
}

AppContainer.propTypes =  {
    children:PropTypes.node, 
    router:PropTypes.object, 
    location:PropTypes.object,
    history:PropTypes.any
}

AppContainer.contextTypes = {
    router: PropTypes.object
}
export default withRouter(AppContainer)