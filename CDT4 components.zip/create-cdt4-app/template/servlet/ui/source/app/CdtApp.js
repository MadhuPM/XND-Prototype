import React from "react"
import PropTypes from 'prop-types'
import { Provider } from 'react-redux'
import { createStore, applyMiddleware, combineReducers } from 'redux'
import {CloudServiceAPI, idfReducer} from 'ssc-cdt4'
import {BrowserRouter, Route } from 'react-router-dom';
import AppContainer from './AppContainer'
import {IntlProvider} from 'react-intl'
import reactIntlFormat from "./ReactIntlBaseFormats"
let store
export default class CdtApp extends React.Component {
  constructor(props) {
    super(props)
    const idfServiceReducer = {
      idfReducer
    }
    const cloudMiddleware = CloudServiceAPI(this.props.contextPath)
    const rootReducer = combineReducers({...idfServiceReducer})
    store = createStore(
      rootReducer,
      applyMiddleware(cloudMiddleware)
    )
  }

  render() {
    return (
      <IntlProvider locale={'en-US'} formats={reactIntlFormat}>
        <Provider store={store}>
        <BrowserRouter
					basename={this.props.contextPath}
        >
					<Route path={'/'} component={AppContainer}/>
					</BrowserRouter>
        </Provider>
      </IntlProvider>
    )
  }
}
