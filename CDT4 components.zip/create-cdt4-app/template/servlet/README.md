# Introduction

The application template is a Maven project which provides examples of components in `ssc-cdt4` without back-end framework. 
Applications using old `ssc-cdt3` can follow this example to upgrade to [`ssc-cdt4`](http://design.statestr.com/).
You can find online document in ['Document'](https://cloud-dev1.statestr.com/playbook/)



## Run Up UI
```Bash
cd <project name>/ui
npm install 
npm start
```

1. visit 
http://localhost:8000/cloudservices/


## FAQ:
1. If you 'met operation not permitted, rename ...' when you try 'npm install', just try using 'yarn install' to replace 'npm install' to install

2. If you want to replace the 'cloudservices' in the url, change the '"start": "node tools/server.js cloudservices",' in the package.json


