package com.ssc.cdt.data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Dummy class to hold Employee data for training.
 * <p/>
 * Populates a ConcurrentHashMap with a list of employees with randomized hire
 * dates, salaries, etc.
 * <p/>
 * Used by IDF_25990003
 * 
 * @author Lee Torrence
 */
public class EmployeeData extends ConcurrentHashMap<Integer, Employee> {
    private static final long serialVersionUID = 1L;
    private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    String[] departments = new String[] { "Human Resources", "Finance", "Sales EU", "Internal Tech Support", "PM Development", "PM Offshore", "Sales US", "Sales APAC", "Financial Development", "Human Resources APAC" };
    private double[] salaries = new double[] { 40000, 50000, 55000, 65000, 70000, 80000, 85000 };
    private Random rand = new Random();
    
    public EmployeeData() {
        super();
        String[][] empData = getEmpData();

    	for (int i = 0; i < empData.length; i++) {
            Employee e = new Employee();
            if (i > 12) {
                e.setIsRead(1);
            }
            e.setId(new Integer(i + 1));
            e.setFirstName(empData[i][0]);
            e.setLastName(empData[i][1]);
            e.setSex(empData[i][2]);
            int deptIndex = rand.nextInt(10);
            e.setDepartment(departments[deptIndex]);
            e.setSalary(salaries[rand.nextInt(7)]);
            e.setEmail(e.getFirstName().substring(0, 1).toLowerCase() + e.getLastName().toLowerCase()
                    + "@fakecompany.com");
            e.setFullTime((i % 8 != 0) ? "true" : "false");
            
            try {
                e.setStartDate(sdf.parse(empData[i][3]));
            } catch (ParseException e1) {}

            put(e.getId(), e);

        }

    }

    public static String[][] getEmpData() {
        return new String[][] { new String[] { "Amy", "Alvarez", "F", "02/12/1995" },
                new String[] { "Illiana", "Buchanan", "F", "03/25/2005" },
                new String[] { "Clementine", "Buck", "F", "11/20/2000" },
                new String[] { "Zelenia", "Buck", "F", "06/06/1999" },
                new String[] { "Brent", "Carson", "M", "10/02/2008" },
                new String[] { "Leo", "Clay", "M", "01/13/2010" },
                new String[] { "Clio", "Dempsey", "F", "11/01/2003" },
                new String[] { "Inez", "Edelstein", "F", "07/19/2009" },
                new String[] { "Jamal", "Crawford", "M", "03/21/2007" },
                new String[] { "Marah", "Ferrell", "F", "07/13/2009" },
                new String[] { "Jaime", "Gilmore", "F", "10/02/2006" },
                new String[] { "Emerson", "Gonzalez", "M", "09/22/2003" },
                new String[] { "Emmanuel", "Hanson", "M", "02/05/2005" },
                new String[] { "Len", "Holcomb", "M", "07/09/2009" },
                new String[] { "Baker", "Holt", "M", "11/30/2004" },
                new String[] { "Octavia", "House", "F", "09/13/2003" },
                new String[] { "Octavius", "Hurley", "M", "03/30/2003" },
                new String[] { "Theodore", "Jenkins", "M", "09/22/2004" },
                new String[] { "Nelle", "Jordan", "F", "02/05/2001" },
                new String[] { "Quamar", "Kane", "M", "07/19/2005" },
                new String[] { "Latifah", "Luna", "F", "11/21/2009" },
                new String[] { "Camden", "Mcconnell", "M", "03/02/2010" },
                new String[] { "Elaine", "Mcgee", "F", "09/13/2003" },
                new String[] { "Lynn", "Mcgee", "F", "09/22/2003" },
                new String[] { "Sigourney", "Mckenzie", "F", "03/05/2007" },
                new String[] { "Sarah", "Mckenzie", "F", "02/19/2006" },
                new String[] { "Fiona", "Mclean", "F", "07/22/2004" },
                new String[] { "Adam", "Mendez", "M", "09/09/2005" },
                new String[] { "Acton", "Mitchell", "M", "11/19/1998" },
                new String[] { "Jelani", "Nash", "M", "03/05/2010" },
                new String[] { "Pandora", "ONeill", "F", "07/13/2004" },
                new String[] { "Jacqueline", "Pacheco", "F", "09/09/2003" },
                new String[] { "Brian", "Parsons", "M", "09/02/2003" },
                new String[] { "Hedda", "Reed", "F", "02/19/2006" },
                new String[] { "Stuart", "Rodriquez", "M", "11/22/2003" },
                new String[] { "Martina", "Rose", "F", "10/19/2007" },
                new String[] { "Ferdinand", "Shaw", "M", "03/05/2005" },
                new String[] { "Diana", "Smith", "F", "09/21/2004" },
                new String[] { "Lenore", "Stevens", "F", "10/09/2010" },
                new String[] { "Candace", "Stevens", "F", "07/13/2003" },
                new String[] { "Porter", "Summers", "M", "09/19/2004" },
                new String[] { "Madonna", "Sweet", "F", "09/05/1998" },
                new String[] { "Demetrius", "Tran", "M", "02/22/2005" },
                new String[] { "Wang", "Valdez", "M", "10/02/2010" },
                new String[] { "Rigel", "Wade", "M", "11/13/2007" },
                new String[] { "Trevor", "Wagner", "M", "09/05/2009" },
                new String[] { "Kibo", "Watkins", "M", "03/21/2005" },
                new String[] { "Alea", "Webster", "F", "10/22/2001" },
                new String[] { "Eric", "Zelenski", "M", "02/05/2005" },
                new String[] { "Luke", "Woods", "M", "09/02/2010" },
                new String[] { "Bob", "Sanko", "M", "06/02/2004" },
                new String[] { "Dale", "Rotoski", "M", "11/10/2012" },
                new String[] { "Alicia", "Billings", "M", "09/15/2008" },
                new String[] { "Bala", "Shaik", "M", "05/22/2000" },
                new String[] { "Faried", "Sharma", "M", "01/06/2010" }, };

    }

}
