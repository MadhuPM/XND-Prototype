package com.ssc.cdt.data;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.ssc.cloud.jbio.JBIOAbstractService;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;


public class EmployeeCRUDSample extends JBIOAbstractService<Employee, Employee> {
    public static final Logger log = Logger.getLogger(EmployeeCRUDSample.class);
    private static EmployeeData empData = new EmployeeData();
    public static final String[] MANDATORY_FIELDS = { Employee.FIRST_NAME, Employee.LAST_NAME, Employee.EMAIL, Employee.SALARY, Employee.START_DATE };

    @Override
    public void load(Employee inputParams) throws GenException, JBIOMappingException,
            JBIOUnderlyingDataSourceException, SQLException {
        final Integer empId = inputParams.getId();
        final Employee e = empData.get(empId);
        // mark it as read
        e.setIsRead(1);
        mapForReturn(empData.get(e.getId()));
        outputRow();
    }

    @Override
    public void update(Employee inputParams) throws GenException, JBIOMappingException,
            JBIOUnderlyingDataSourceException, SQLException {
        mapForReturn(inputParams);
        if (!validateParams(inputParams, MANDATORY_FIELDS)) {
            outputRow();
            return;
        }
        
        Date dt = inputParams.getStartDate();
        
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(0);
        cal.set(2005, 1, 1, 0, 0, 0);
        Date begin = cal.getTime();
        
        if (dt.before(begin)) {
        	setErrorMsg(Employee.START_DATE, "Start Date can't be before 2005. Company was formed in 2005.");
        	outputRow();
        	return;
        }
        
        Double salary = inputParams.getSalary();
        
        if (salary < 39000.00) {
        	setErrorMsg(Employee.SALARY, "Salary must be greater than $40,000.");
        	outputRow();
        	return;
        }
        
        //setErrorMsg("This is the general error");
        
        final Integer empId = inputParams.getId();
        empData.put(empId, inputParams);
        outputRow();
    }

    @Override
    public void addNew(Employee inputParams) throws GenException, JBIOMappingException,
            JBIOUnderlyingDataSourceException, SQLException {
        if (!validateParams(inputParams, MANDATORY_FIELDS)) {
            outputRow();
            return;
        }
        Integer id = new Integer(empData.size() + 1);
        inputParams.setId(id);
        empData.put(id, inputParams);
        mapForReturn(inputParams);
        outputRow();
    }

    @Override
    public void delete(Employee inputParams) throws GenException, JBIOMappingException,
            JBIOUnderlyingDataSourceException, SQLException {
    	
    	List<Employee> inputs = listParams();
    	for (Employee emp : inputs) {
            final Integer empId = emp.getId();
            empData.remove(empId);
            mapForReturn(emp);
            outputRow();
    	}
    }

    @Override
    public void loadList(Employee inputParams) throws GenException, JBIOMappingException,
            JBIOUnderlyingDataSourceException, SQLException {
    	List<Employee> employees = new ArrayList<Employee>( empData.values());
    	int count = employees.size();
    	int start = inputParams.getStart() == null ? 0 : inputParams.getStart();
    	int pageSize = inputParams.getPagesize() == null ? 0 : inputParams.getPagesize();
    	int stop = (pageSize == 0) ? count : Math.min(start + pageSize, count);

    	// not handling sort here for now
    	
    	log.info("Sort String: " + inputParams.getSort());
    	
    	// set count in first bean returned
    	employees.get(start).setTotalrows(count);
    	
    	for (int i = start; i < stop; i++) {
    		mapForReturn(employees.get(i));
    		outputRow();
    	}
    		
    }

}
