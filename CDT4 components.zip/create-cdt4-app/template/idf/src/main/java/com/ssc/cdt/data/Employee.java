package com.ssc.cdt.data;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfIn;
import com.ssc.cloud.jbio.IdfInOut;

@IdfInOut(
{
    @Col(beanProp="pagesize", idfColName=Employee.PAGESIZE, idfColType=IdfColType.INT),
    @Col(beanProp="fullTime", idfColName=Employee.FULL_TIME, idfColType=IdfColType.STRING),
    @Col(beanProp="endDate", idfColName=Employee.END_DATE, idfColType=IdfColType.DATE),
    @Col(beanProp="fund", idfColName=Employee.FUND, idfColType=IdfColType.STRING),
    @Col(beanProp="lastName", idfColName=Employee.LAST_NAME, idfColType=IdfColType.STRING),
    @Col(beanProp="isRead", idfColName=Employee.IS_READ, idfColType=IdfColType.INT),
    @Col(beanProp="startDate", idfColName=Employee.START_DATE, idfColType=IdfColType.DATE),
    @Col(beanProp="sort", idfColName=Employee.SORT, idfColType=IdfColType.STRING),
    @Col(beanProp="start", idfColName=Employee.START, idfColType=IdfColType.INT),
    @Col(beanProp="salary", idfColName=Employee.SALARY, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="firstName", idfColName=Employee.FIRST_NAME, idfColType=IdfColType.STRING),
    @Col(beanProp="totalrows", idfColName=Employee.TOTALROWS, idfColType=IdfColType.INT),
    @Col(beanProp="sex", idfColName=Employee.SEX, idfColType=IdfColType.STRING),
    @Col(beanProp="id", idfColName=Employee.ID, idfColType=IdfColType.INT),
    @Col(beanProp="email", idfColName=Employee.EMAIL, idfColType=IdfColType.STRING),
    @Col(beanProp="department", idfColName=Employee.DEPARTMENT, idfColType=IdfColType.STRING),
}
)

@IdfIn({
    @Col(beanProp="editState", idfColName=Employee.EDIT_STATE, idfColType=IdfColType.INT),	
})

public class Employee
{
    public static final String PAGESIZE = "PAGESIZE";
    public static final String FULL_TIME = "FULL_TIME";
    public static final String END_DATE = "END_DATE";
    public static final String FUND = "FUND";
    public static final String LAST_NAME = "LAST_NAME";
    public static final String IS_READ = "IS_READ";
    public static final String EDIT_STATE = "EDIT_STATE";
    public static final String START_DATE = "START_DATE";
    public static final String SORT = "SORT";
    public static final String START = "START";
    public static final String SALARY = "SALARY";
    public static final String FIRST_NAME = "FIRST_NAME";
    public static final String TOTALROWS = "TOTALROWS";
    public static final String SEX = "SEX";
    public static final String ID = "ID";
    public static final String EMAIL = "EMAIL";
    public static final String DEPARTMENT = "DEPARTMENT";

    private java.lang.Integer pagesize;
    private java.lang.String fullTime;
    private java.util.Date endDate;
    private java.lang.String fund;
    private java.lang.String lastName;
    private java.lang.Integer isRead;
    private java.lang.Integer editState;
    private java.util.Date startDate;
    private java.lang.String sort;
    private java.lang.Integer start;
    private java.lang.Double salary;
    private java.lang.String firstName;
    private java.lang.Integer totalrows;
    private java.lang.String sex;
    private java.lang.Integer id;
    private java.lang.String email;
    private java.lang.String department;

    public java.lang.Integer getPagesize()
    {
        return pagesize;
    }

    public void setPagesize(java.lang.Integer pagesize)
    {
        this.pagesize = pagesize;
    }

    public java.lang.String getFullTime()
    {
        return fullTime;
    }

    public void setFullTime(java.lang.String fullTime)
    {
        this.fullTime = fullTime;
    }

    public java.util.Date getEndDate()
    {
        return endDate;
    }

    public void setEndDate(java.util.Date endDate)
    {
        this.endDate = endDate;
    }

    public java.lang.String getFund()
    {
        return fund;
    }

    public void setFund(java.lang.String fund)
    {
        this.fund = fund;
    }

    public java.lang.String getLastName()
    {
        return lastName;
    }

    public void setLastName(java.lang.String lastName)
    {
        this.lastName = lastName;
    }

    public java.lang.Integer getIsRead()
    {
        return isRead;
    }

    public void setIsRead(java.lang.Integer isRead)
    {
        this.isRead = isRead;
    }

    public java.util.Date getStartDate()
    {
        return startDate;
    }

    public void setStartDate(java.util.Date startDate)
    {
        this.startDate = startDate;
    }

    public java.lang.String getSort()
    {
        return sort;
    }

    public void setSort(java.lang.String sort)
    {
        this.sort = sort;
    }

    public java.lang.Integer getStart()
    {
        return start;
    }

    public void setStart(java.lang.Integer start)
    {
        this.start = start;
    }

    public java.lang.Double getSalary()
    {
        return salary;
    }

    public void setSalary(java.lang.Double salary)
    {
        this.salary = salary;
    }

    public java.lang.String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(java.lang.String firstName)
    {
        this.firstName = firstName;
    }

    public java.lang.Integer getTotalrows()
    {
        return totalrows;
    }

    public void setTotalrows(java.lang.Integer totalrows)
    {
        this.totalrows = totalrows;
    }

    public java.lang.String getSex()
    {
        return sex;
    }

    public void setSex(java.lang.String sex)
    {
        this.sex = sex;
    }

    public java.lang.Integer getId()
    {
        return id;
    }

    public void setId(java.lang.Integer id)
    {
        this.id = id;
    }

    public java.lang.String getEmail()
    {
        return email;
    }

    public void setEmail(java.lang.String email)
    {
        this.email = email;
    }

    public java.lang.String getDepartment()
    {
        return department;
    }

    public void setDepartment(java.lang.String department)
    {
        this.department = department;
    }

	public java.lang.Integer getEditState() {
		return editState;
	}

	public void setEditState(java.lang.Integer editState) {
		this.editState = editState;
	}

}
