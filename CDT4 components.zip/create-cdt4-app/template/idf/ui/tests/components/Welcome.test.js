import React from 'react'
import { expect} from 'chai'
import { mount } from 'enzyme'
import Welcome from '../../source/components/Welcome'

describe('Test', function() {
  describe('Welcome', function() {
    it('mounted', function() {
      let wrapper = mount(<Welcome name={'State'}/>)
      expect(wrapper.props().name).to.equal('State')
    })
  })
})
