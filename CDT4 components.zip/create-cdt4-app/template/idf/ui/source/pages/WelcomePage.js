import React from "react"
import PropTypes from 'prop-types'
import Welcome from '../components/Welcome'

export default class WelcomePage extends React.Component {
	render() {
		return(
			<Welcome name={"State Street Corp."}/>
		)
	}
}
