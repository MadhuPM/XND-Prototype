import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {DataGrid, connectCdtDataComponent, HorizontalLayout, VerticalLayout, FlexPanel} from 'ssc-cdt4';


const pageSize = 25;
const empColConfig = [{
	  dataKey: 'ID',
	  label: 'ID',
	  width: 60,
	  dataType: 'number',
	  hidden: true
	}, {
	  dataKey: 'FIRST_NAME',
	  label: 'First Name',
	  width: 120,
	  dataType: 'string',
	}, {
	  dataKey: 'LAST_NAME',
	  label: 'Last Name',
	  width: 120,
	  dataType: 'string',
	}, {
	  dataKey: 'START_DATE',
	  label: 'Start Date',
	  width: 100,
	  dataType: 'date',
	  align: 'right'
	}, {
	  dataKey: 'END_DATE',
	  label: 'End Date',
	  width: 100,
	  dataType: 'date',
	  align: 'right'
	}, {
	  dataKey: 'DEPARTMENT',
	  label: 'Department',
	  width: 200,
	  dataType: 'string',
	  group: true
	}, {
	  dataKey: 'EMAIL',
	  label: 'Email',
	  width: 240,
	  dataType: 'string',
	}, {
	  dataKey: 'SALARY',
	  label: 'Salary',
	  width: 90,
	  dataType: 'number',
	  align: 'right'
	}, {
	  dataKey: 'SEX',
	  label: 'Sex',
	  width: 50,
	  dataType: 'string',
	  group: true,
	  sort: false
	}];

@connectCdtDataComponent('scrollPaginationData', 25990003, empColConfig)
export default class ScrollPagination extends Component {
  static propTypes = {
	  scrollPaginationData: PropTypes.object,
	  scrollPaginationDataActions: PropTypes.object
  }

  constructor(props) {
    super(props);
  }

  componentDidMount() {
    // have to pass START and LIMIT in initial load
    this.props.scrollPaginationDataActions.loadList({START: 0, PAGESIZE: pageSize});
  }

  showPage = (pageNo) => {
    const {scrollPaginationData, scrollPaginationDataActions} = this.props;
    const {params = []} = scrollPaginationData;
    // params can be object or array, so we have to check
    const paramArray = (Array.isArray(params) ? params : [params]).slice();
    const startIndex = (pageNo - 1) * pageSize;
    paramArray[0] = {...paramArray[0], START: startIndex, PAGESIZE: pageSize};
    scrollPaginationDataActions.loadList(paramArray);
  }

  onSortFilter = (sortConfigArray = []) => {
    const {scrollPaginationData, scrollPaginationDataActions} = this.props;
    const {params = []} = scrollPaginationData;
    const paramArray = (Array.isArray(params) ? params : [params]).slice();

    const strSort = sortConfigArray.map((config) => {
      return config.asc ? config.sort : '-' + config.sort;
    }).join(',');

    paramArray[0] = {...paramArray[0], SORT: strSort};
    scrollPaginationDataActions.loadList(paramArray);
  }

  render() {
    const {scrollPaginationData, scrollPaginationDataActions} = this.props;
    const {data} = scrollPaginationData;

    return (
      <VerticalLayout >
       <FlexPanel >
          <DataGrid
            showPage={this.showPage}
            onSortFilter={this.onSort}
          	scrollLimit={pageSize}
            data={data}
            columns={empColConfig}
            keyFieldName="ID"
            hasCheckbox
            title="Scroll Lazyload"
            />
       </FlexPanel>
      </VerticalLayout>
    );
  }
}

