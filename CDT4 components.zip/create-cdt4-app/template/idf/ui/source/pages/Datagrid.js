import React from "react"
import PropTypes from 'prop-types'
import {DataGrid, connectCdtDataComponent, AlertBanner, VerticalLayout, FlexPanel} from 'ssc-cdt4'

const editTreeCols = [
  {
    dataKey: 'id',
    label: 'Id',
    width: 70,
    dataType: 'number',
    hidden: true
  },
  {
    dataKey: 'parentId',
    label: 'Parentid',
    width: 70,
    dataType: 'number',
    hidden: true
  },
  {
    dataKey: 'itemType',
    label: 'Itemtype',
    width: 70,
    dataType: 'number',
    hidden: true
  },
  {
    dataKey: 'name',
    label: 'Name',
    width: 200,
    dataType: 'string',
    edit: true
  },
  {
    dataKey: 'description',
    label: 'Description',
    width: 300,
    dataType: 'string',
    edit: true
  },
  {
    dataKey: 'inception',
    label: 'Inception Date',
    width: 200,
    dataType: 'date',
    edit: true
  },
  {
    dataKey: 'controls',
    label: '',
    width: 200,
    dataType: 'string',
  }]

const data = [
  { "priorityType": "low", "ID": 1, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "CLGX", "UNITS": 537.0, "PRICE": 292.0762272250006, "COST": 156844.9340198253, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1, "__errorMsg": "{\"errors\":[],\"success\":true}" },
  { "priorityType": "high", "ID": 2, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "KE", "UNITS": 521.0, "PRICE": 307.18662394261725, "COST": 160044.2310741036, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1 },
  { "priorityType": "medium", "ID": 3, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "AIXG", "UNITS": 296.0, "PRICE": 164.20752344196708, "COST": 48605.42693882226, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1 },
  { "priorityType": "high", "ID": 4, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "AFOP", "UNITS": 53.0, "PRICE": 351.6374260235813, "COST": 18636.78357924981, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1 },
  { "priorityType": "medium", "ID": 5, "FUND": "FUND0", "MANAGER": "Alvarez", "ASSET": "CHKP", "UNITS": 363.0, "PRICE": 395.92090457520794, "COST": 143719.28836080048, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1 },
  { "priorityType": "high", "ID": 6, "FUND": "FUND0", "MANAGER": "Buchanan", "ASSET": "SAIC", "UNITS": 757.0, "PRICE": 479.8066271555781, "COST": 363213.6167567726, "DATE": "20171018", "DATE_TIME": "20171018 10:23:50", "HAS_CHILDREN": 1 }
]

const treeData = [
  { "priorityType": "high", "id": 1, "appcode": "CLOTRG00259", "active": 1, "itemType": 0, "name": "Fund Category One", "description": "A category", "inception": "20161018", "__errorMsg": "{\"errors\":[],\"success\":true}" },
  { "priorityType": "low", "id": 4, "parentId": 1, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Another Child", "description": "More descriptions", "inception": "20161011" },
  { "priorityType": "high", "id": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 0, "name": "Fund Category Two", "description": "Here is description", "inception": "20161018" },
  {"priorityType": "high", "id": 12, "parentId": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Cat two Child", "description": "description", "inception": "20161011" },
  { "priorityType": "medium","id": 14, "parentId": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Category two third child", "description": "Now a description", "inception": "20161123" },
  { "priorityType": "medium","id": 15, "parentId": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Child to Fund", "description": "ddd", "inception": "20161209" },
  { "priorityType": "low","id": 16, "appcode": "CLOTRG00259", "active": 1, "itemType": 0, "name": "Top Category", "description": "Long description", "inception": "20161215" },
  { "priorityType": "low","id": 17, "parentId": 16, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "Child of top category", "description": "again a description", "inception": "20161215" },
  { "priorityType": "low","id": 18, "parentId": 11, "appcode": "CLOTRG00259", "active": 1, "itemType": 1, "name": "cdcd", "description": "cdcd", "inception": "20171025" }
]

const fundColConfig = [
  {
    dataKey: 'ASSET',
    label: 'Asset',
    width: 180,
    dataType: 'string',
    locked: true,
    toolTip: 'Is the UBO a PEP? If yes,'
  }, {
    dataKey: 'MANAGER',
    label: 'Manager',
    width: 140,
    dataType: 'string',
    group: true,
  }, {
    dataKey: 'FUND',
    label: 'Fund',
    width: 80,
    dataType: 'string',
    group: true,
  }, {
    dataKey: 'UNITS',
    label: 'Units',
    width: 80,
    dataType: 'number',
    align: 'right'
  }, {
    dataKey: 'PRICE',
    label: 'Price',
    width: 100,
    dataType: 'number',
    numberFormat: 'currency',
    align: 'right'
  }, {
    dataKey: 'COST',
    label: 'Total Market Value',
    width: 180,
    dataType: 'number',
    numberFormat: 'currency',
    align: 'right'
  }, {
    dataKey: 'DATE',
    label: 'Date',
    width: 100,
    dataType: 'date',
    align: 'left'
  }, {
    dataKey: 'DATE_TIME',
    label: 'Date + Time',
    width: 180,
    dataType: 'datetime',
    align: 'left'
  }, {
    dataKey: 'ID',
    label: 'ID',
    width: 60,
    dataType: 'number',
    numberFormat: 'id'
  }
]

@connectCdtDataComponent('fundData', 25990018, fundColConfig, 'ID')
export default class Template extends React.Component {
  static propTypes = {
    fundDataActions:PropTypes.any,
    fundData:PropTypes.any
  }
  componentDidMount = () => {
    // this.props.fundDataActions.loadList()
    const {fundDataActions} = this.props

     fundDataActions.loadList().then(res => {
      // fundDataActions.success('Success', 'Case created successfully.')
      const type = 'confirmation'
      AlertBanner.show(
        type,
        `data load successfully`
      )

    })

  }

  render() {
    return (
      // <VerticalLayout>
      //   <FlexPanel style={{margin: '50px 200px'}}>
          <DataGrid
            columns={fundColConfig}
            keyFieldName="ID"
            data={this.props.fundData.data}
            hasPriority
            hasCheckbox
            title="Basic Table"
          />
      //   </FlexPanel>
      // </VerticalLayout>
    )
  }
}
