import React from "react"
import PropTypes from 'prop-types'
import Welcome from '../components/Welcome'

export default class AnotherPage extends React.Component {
	render() {
		return(
			<Welcome name={"Another Page"}/>
		)
	}
}
