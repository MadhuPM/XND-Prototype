import React from 'react'
import {render} from 'react-dom'
import CdtApp from './app/CdtApp'
import { DragDropContext } from 'react-dnd'
import HTML5Backend from 'react-dnd-html5-backend'
import { AppContainer } from 'react-hot-loader';
const rootElement = document.getElementById('app')
const AppContainerDnD = DragDropContext(HTML5Backend)(AppContainer);
const ctx = window.contextPath;
render(<AppContainerDnD>< CdtApp contextPath={ctx}/></AppContainerDnD>, rootElement)
  if (module.hot) {
    module.hot.accept('./app/CdtApp', () => {
      const NewRoot = require('./app/CdtApp').default
      render(
        <AppContainerDnD>< NewRoot /></AppContainerDnD>,
        rootElement
      )
    })
  }