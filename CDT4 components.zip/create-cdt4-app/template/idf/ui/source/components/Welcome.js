import React from "react"
import PropTypes from 'prop-types'

export default class Welcome extends React.Component {
    static propTypes = {
        name:PropTypes.string
    }
    static defaultProps = {
        name:'State Street Corp.'
    }
    render() {
        return <h1>Welcome, {this.props.name}</h1>;
    }
}
