# Introduction

The application template is a Maven project which provides examples of components in `ssc-cdt4` and also includes backend `IDF` integration example. 
More detail to use IDF with our datagrid component can be found [here](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/How-to-use-CDT4-datagrid-table-with-a-REST-API)
Applications using old `ssc-cdt3` can follow this example to upgrade to [`ssc-cdt4`](https://gitprod.statestr.com/SSC/clo_ssccdt3ui/wiki/Migrate-CDT-3-UI-to-CDT-4-UI).
You can find online document in ['Document'](https://cloud-dev1.statestr.com/playbook/)

## Run Up Tomcat

1. import this project as a Maven project into eclipse

2. Right click project, in the menu select `Maven`-> `Update Project` to make sure the build process is correct 

3. Right click project, in the menu select `Run As` -> `Maven build...`, in the popup enter goal `tomcat7:run` and click `Run`




## Run Up UI
```Bash
cd <project name>/ui
npm install 
npm start
```

1. visit 
http://localhost:8000/cloudservices/


## FAQ:
1. If you met java.lang.UnsatisfiedLinkError: no cspminterface64 in java.library.path or 
java.lang.NoClassDefFoundError: Could not initialize class com.ssc.faw.intref2.IDF_Connection
You can try to copy the OSA\pwmatrix\cspminterface64.dll to your eclipse directory to fix it

2. If you 'met operation not permitted, rename ...' when you try 'npm install', just try using 'yarn install' to replace 'npm install' to install

3. If you want to generate the war file and manually deploy to tomcat instead of maven plugin, you can run 'ant buildMavenProject' to generate the war file, the war will be placed under '[your-project-dir]\target', then changed the file name to cloudservices.war,put to tomcat/webapp, then start tomcat, visit http://localhost:8080/cloudservices/Datagrid

4. If you want to change the default 'cloudservices' context, you should change the keyword 'cloudservices' in pom.xml, ui/config/webpack.dev.js, ui/config/webpack.prod.js, ui/package.json, ui/source/app/CdtApp.js

5. If there is no need for you to change the context locally, but your project will be deployed to pass cloud, you should keep the context of ui/source/app/CdtApp.js the same as the context of cloud profile context property.

